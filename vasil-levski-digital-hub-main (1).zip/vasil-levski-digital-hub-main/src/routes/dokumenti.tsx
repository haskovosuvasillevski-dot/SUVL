import { createFileRoute } from "@tanstack/react-router";
import { FileText } from "lucide-react";
import { DocumentsPage } from "@/components/DocumentsPage";
const hero = "/assets/dokumenti.jpg";

const title = "Документи – СУ „Васил Левски“ Хасково";
const description =
  "Правилници, стратегии, планове и други официални документи на СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/dokumenti")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <DocumentsPage
      heading="Документи"
      heroUrl={hero}
      icon={FileText}
      sheetId="1e7o31DukUaQu7vT1tP1WJOMSG3WbQdL8w_hRzp9JcLQ"
    />
  ),
});
