import { createFileRoute } from "@tanstack/react-router";
import { GraduationCap } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { AutoIframe } from "@/components/AutoIframe";
const banner = "/assets/forma-na-obuchenie.jpg";

const title = "Форма на обучение – СУ „Васил Левски“ Хасково";
const description =
  "Форми на обучение в СУ „Васил Левски“ – град Хасково: документи, срокове и информация.";

export const Route = createFileRoute("/forma-na-obuchenie")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <PageShell
      title="Форма на обучение"
      image={banner}
      icon={<GraduationCap className="h-7 w-7" />}
    >
      <section className="mx-auto max-w-7xl px-2 py-10 lg:px-8">
        <AutoIframe
          src="/forma-na-obuchenie.html"
          title="Форма на обучение"
          whiteBackground
        />
      </section>
    </PageShell>
  ),
});
