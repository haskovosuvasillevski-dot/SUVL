import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, Palette } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { fetchClubs, driveImage, type Club } from "@/lib/clubs";
const banner = "/assets/izvunklasni.jpg";

const title = "Извънкласни дейности – СУ „Васил Левски“ Хасково";
const description =
  "Клубове и извънкласни дейности в СУ „Васил Левски“ – град Хасково: изкуства, спорт, наука и технологии.";

export const Route = createFileRoute("/izvunklasni-deynosti/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ClubsPage,
});

function ClubsPage() {
  const [clubs, setClubs] = useState<Club[] | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    fetchClubs()
      .then((items) => active && setClubs(items))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, []);

  return (
    <PageShell title="Извънкласни дейности" image={banner} icon={<Palette className="h-7 w-7" />}>
      <section className="bg-secondary/40 py-12">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          {error && (
            <p className="text-center text-destructive">
              Възникна грешка при зареждане на клубовете.
            </p>
          )}
          {!error && !clubs && (
            <p className="text-center text-muted-foreground">Зареждане на клубовете...</p>
          )}
          {clubs && clubs.length === 0 && (
            <p className="text-center text-muted-foreground">Няма добавени клубове.</p>
          )}

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {clubs?.map((club, i) => (
              <div key={club.id}>
                <article
                  className="club-card club-card-in group relative h-full overflow-hidden rounded-xl border border-border bg-card shadow-[var(--shadow-soft)]"
                  style={{ animationDelay: `${i * 90}ms` }}
                >
                  <div className="relative flex h-60 w-full items-center justify-center overflow-hidden bg-card">
                    <Link
                      to="/izvunklasni-deynosti/$id"
                      params={{ id: club.id }}
                      className="block h-full w-full"
                    >
                      <img
                        src={driveImage(club.image)}
                        alt={club.title}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-contain"
                      />
                    </Link>
                    {club.time && (
                      <span className="absolute right-3 top-3 z-10 inline-flex items-center gap-1.5 rounded-md bg-accent px-2.5 py-1.5 text-sm font-medium text-accent-foreground">
                        <Clock className="h-4 w-4" />
                        {club.time}
                      </span>
                    )}
                  </div>

                  <div className="min-h-[190px] p-8">
                    <span className="inline-block rounded bg-secondary px-3 py-1.5 text-sm text-primary">
                      {club.levels || "Всички нива"}
                    </span>
                    <h2 className="mt-5 font-display text-xl font-bold leading-snug text-primary">
                      <Link to="/izvunklasni-deynosti/$id" params={{ id: club.id }}>
                        {club.title}
                      </Link>
                    </h2>
                    <div className="mt-4 text-base font-medium text-foreground">{club.price}</div>
                  </div>

                  <div className="pointer-events-none absolute inset-x-0 bottom-0 top-60 z-20 flex flex-col justify-center bg-primary p-8 text-primary-foreground opacity-0 transition-opacity duration-300 group-hover:pointer-events-auto group-hover:opacity-100">
                    <span className="inline-block w-fit rounded bg-primary-foreground px-3 py-1.5 text-sm text-primary">
                      {club.levels || "Всички нива"}
                    </span>
                    <h3 className="mt-4 font-display text-xl font-bold leading-snug">
                      {club.title}
                    </h3>
                    <div className="mt-2 text-base">{club.price}</div>
                    <p className="mt-3 line-clamp-3 text-base opacity-90">{club.description}</p>
                    <Link
                      to="/izvunklasni-deynosti/$id"
                      params={{ id: club.id }}
                      className="mt-5 inline-flex w-fit items-center gap-3 font-semibold no-underline hover:no-underline"
                    >
                      Виж повече{" "}
                      <span aria-hidden className="club-arrow inline-block text-2xl leading-none">
                        →
                      </span>
                    </Link>
                  </div>
                </article>
              </div>
            ))}
          </div>
        </div>
      </section>
    </PageShell>
  );
}