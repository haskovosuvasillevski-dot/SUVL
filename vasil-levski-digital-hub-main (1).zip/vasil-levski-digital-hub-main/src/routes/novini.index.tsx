import { useEffect, useMemo, useState } from "react";
import { Newspaper } from "lucide-react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, Pagination } from "@/components/PageShell";
import { Reveal } from "@/components/Reveal";
import { fetchNews, type NewsItem } from "@/lib/news";
import { driveImgProps } from "@/lib/imgProps";
const newsHero = "/assets/news-banner.jpg";

const title = "Новини – СУ „Васил Левски“ Хасково";
const description =
  "Всички новини, събития и постижения на СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/novini/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: newsHero },
      { name: "twitter:image", content: newsHero },
    ],
  }),
  component: NewsPage,
});

const MONTHS = ["яну", "фев", "март", "апр", "май", "юни", "юли", "авг", "сеп", "окт", "ное", "дек"];
const PER_PAGE = 18;

function NewsPage() {
  const [news, setNews] = useState<NewsItem[] | null>(null);
  const [error, setError] = useState(false);
  const [page, setPage] = useState(1);

  useEffect(() => {
    let active = true;
    fetchNews()
      .then((items) => active && setNews(items))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, []);

  const totalPages = news ? Math.ceil(news.length / PER_PAGE) : 0;
  const items = useMemo(
    () => (news ?? []).slice((page - 1) * PER_PAGE, page * PER_PAGE),
    [news, page],
  );

  return (
    <PageShell title="Новини" image={newsHero} icon={<Newspaper className="h-7 w-7" />}>
      <section className="bg-secondary/40 py-12">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          {error && (
            <p className="text-center text-destructive">
              Възникна грешка при зареждане на новините.
            </p>
          )}
          {!error && !news && (
            <p className="text-center text-muted-foreground">Зареждане на новини...</p>
          )}

          <div className="grid grid-cols-1 gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((item, i) => (
              <Reveal key={item.id} delay={i * 60}>
                <Link
                  to="/novini/$id"
                  params={{ id: String(item.id) }}
                  className="group block h-full overflow-hidden rounded-xl border border-border bg-card shadow-[var(--shadow-soft)] transition-all duration-500 hover:-translate-y-1"
                >
                  <div className="relative h-56 overflow-hidden bg-muted">
                    <div className="absolute left-4 top-4 z-10 rounded-md bg-primary px-3 py-2 text-center text-primary-foreground">
                      <span className="block text-xl font-bold leading-none">
                        {String(item.date.getDate()).padStart(2, "0")}
                      </span>
                      <span className="block text-xs uppercase">
                        {MONTHS[item.date.getMonth()]}
                      </span>
                    </div>
                    <img
                      {...driveImgProps(
                        item.imageUrl,
                        "(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw",
                      )}
                      alt={item.title}
                      loading="lazy"
                      decoding="async"
                      className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-110"
                    />
                  </div>
                  <div className="p-5">
                    <h2 className="font-display text-lg font-bold leading-snug text-primary transition-colors duration-500 group-hover:text-brand-green">
                      {item.title}
                    </h2>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>

          <Pagination
            page={page}
            totalPages={totalPages}
            onChange={(p) => {
              setPage(p);
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </div>
      </section>
    </PageShell>
  );
}
