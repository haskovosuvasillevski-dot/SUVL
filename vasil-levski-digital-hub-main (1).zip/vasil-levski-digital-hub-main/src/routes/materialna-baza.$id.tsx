import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { Lightbox } from "@/components/Lightbox";
import { driveId, youtubeId } from "@/lib/clubs";
import { fetchFacilities, type Facility } from "@/lib/facilities";

export const Route = createFileRoute("/materialna-baza/$id")({
  head: () => ({
    meta: [
      { title: "Материална база | СУ „Васил Левски“ – Хасково" },
      {
        name: "description",
        content: "Кабинети, зали и оборудване в СУ „Васил Левски“, град Хасково.",
      },
      { property: "og:title", content: "Материална база | СУ „Васил Левски“ – Хасково" },
      {
        property: "og:description",
        content: "Кабинети, зали и оборудване в СУ „Васил Левски“, град Хасково.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FacilityDetail,
});

function VideoBlock({ url }: { url: string }) {
  const yid = youtubeId(url);
  const did = url.includes("drive.google.com") ? driveId(url) : "";
  if (yid || did) {
    return (
      <iframe
        src={
          yid
            ? `https://www.youtube.com/embed/${yid}`
            : `https://drive.google.com/file/d/${did}/preview`
        }
        title="Видео"
        allow="autoplay; fullscreen"
        allowFullScreen
        className="aspect-video w-full rounded-xl border-0 bg-black"
      />
    );
  }
  return <video src={url} controls className="aspect-video w-full rounded-xl bg-black" />;
}

function FacilityDetail() {
  const { id } = Route.useParams();
  const [item, setItem] = useState<Facility | null | undefined>(undefined);
  const [lightbox, setLightbox] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    fetchFacilities()
      .then((items) => {
        if (!active) return;
        setItem(items.find((f) => f.id === id.trim()) ?? null);
      })
      .catch(() => active && setItem(null));
    return () => {
      active = false;
    };
  }, [id]);

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content" className="mx-auto max-w-5xl px-4 py-10 lg:px-8">
        <Link
          to="/materialna-baza"
          className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm text-primary no-underline"
        >
          <ArrowLeft className="h-4 w-4" />
          Материална база
        </Link>

        {item === undefined && (
          <p className="py-20 text-center text-muted-foreground">Зареждане...</p>
        )}
        {item === null && (
          <p className="py-20 text-center text-muted-foreground">Страницата не е намерена.</p>
        )}

        {item && (
          <article className="mt-8">
            <Reveal>
              <h1 className="text-center font-display text-3xl font-bold text-primary sm:text-4xl">
                {item.title}
              </h1>
            </Reveal>

            {item.image && (
              <Reveal delay={150} className="mt-8">
                <img
              loading="lazy"
              decoding="async"
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="mx-auto w-full rounded-xl shadow-[var(--shadow-soft)]"
                />
              </Reveal>
            )}

            {item.content && (
              <Reveal delay={100} className="mt-8">
                <p className="whitespace-pre-line text-[1.05rem] leading-8 text-muted-foreground">
                  {item.content}
                </p>
              </Reveal>
            )}

            {item.images.length > 0 && (
              <Reveal delay={150} className="mt-14">
                <h2 className="mb-6 text-center font-display text-2xl font-bold text-primary">
                  Галерия
                </h2>
                <div className="grid grid-cols-3 gap-3 md:grid-cols-5">
                  {item.images.map((img, i) => (
                    <button
                      key={img + i}
                      type="button"
                      onClick={() => setLightbox(i)}
                      className="flex aspect-square items-center justify-center overflow-hidden rounded-lg border border-border bg-white p-1"
                    >
                      <img
                        src={img}
                        alt={`${item.title} – изображение ${i + 1}`}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-contain"
                      />
                    </button>
                  ))}
                </div>
              </Reveal>
            )}

            {item.videos.length > 0 && (
              <Reveal delay={150} className="mt-14 space-y-6">
                <h2 className="mb-6 text-center font-display text-2xl font-bold text-primary">
                  Видео
                </h2>
                {item.videos.map((v) => (
                  <VideoBlock key={v} url={v} />
                ))}
              </Reveal>
            )}
          </article>
        )}
      </main>
      <SiteFooter />

      {item && lightbox !== null && (
        <Lightbox
          images={item.images}
          index={lightbox}
          onClose={() => setLightbox(null)}
          onChange={setLightbox}
        />
      )}
    </div>
  );
}
