import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { Lightbox } from "@/components/Lightbox";
import { driveId, youtubeId } from "@/lib/clubs";
import { fetchProjects, type Project } from "@/lib/projects";

export const Route = createFileRoute("/proekti/$id")({
  head: () => ({
    meta: [
      { title: "Проект | СУ „Васил Левски“ – Хасково" },
      {
        name: "description",
        content: "Проекти и национални програми на СУ „Васил Левски“, град Хасково.",
      },
      { property: "og:title", content: "Проект | СУ „Васил Левски“ – Хасково" },
      {
        property: "og:description",
        content: "Проекти и национални програми на СУ „Васил Левски“, град Хасково.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProjectDetail,
});

function VideoBlock({ url }: { url: string }) {
  const yid = youtubeId(url);
  const did = url.includes("drive.google.com") ? driveId(url) : "";
  if (yid || did) {
    return (
      <iframe
        src={
          yid
            ? `https://www.youtube.com/embed/${yid}`
            : `https://drive.google.com/file/d/${did}/preview`
        }
        title="Видео от проекта"
        allow="autoplay; fullscreen"
        allowFullScreen
        className="aspect-video w-full rounded-xl border-0 bg-black"
      />
    );
  }
  return <video src={url} controls className="aspect-video w-full rounded-xl bg-black" />;
}

function docPreviewUrl(url: string): string {
  const id = driveId(url);
  if (id) return `https://drive.google.com/file/d/${id}/preview`;
  return `https://docs.google.com/gview?embedded=1&url=${encodeURIComponent(url)}`;
}

function docDownloadUrl(url: string): string {
  const id = driveId(url);
  return id ? `https://drive.google.com/uc?export=download&id=${id}` : url;
}

function isDocLink(url: string): boolean {
  return /drive\.google\.com|docs\.google\.com|\.pdf(\?|#|$)/i.test(url);
}

/** Текст със запазени редове; линковете към документи стават вграден преглед. */
function RichText({ text }: { text: string }) {
  const parts = String(text || "").split(/(https?:\/\/\S+)/g);
  const docs = parts.filter((p) => /^https?:\/\//.test(p) && isDocLink(p));
  return (
    <div className="space-y-5">
      <p className="whitespace-pre-line text-[1.05rem] leading-8 text-muted-foreground">
        {parts.map((part, i) =>
          /^https?:\/\//.test(part) ? (
            isDocLink(part) ? null : (
              <a
                key={i}
                href={part}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary underline"
              >
                {part}
              </a>
            )
          ) : (
            <span key={i}>{part}</span>
          ),
        )}
      </p>
      {docs.map((url, i) => (
        <div key={url + i} className="overflow-hidden rounded-xl border border-border">
          <div className="flex items-center justify-between gap-3 bg-primary px-4 py-2">
            <span className="text-sm font-semibold text-primary-foreground">Документ</span>
            <a
              href={docDownloadUrl(url)}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded bg-white px-3 py-1.5 text-sm font-semibold text-primary no-underline"
            >
              Изтегляне
            </a>
          </div>
          <iframe
            src={docPreviewUrl(url)}
            title="Преглед на документа"
            className="h-[70vh] w-full border-0 bg-muted"
          />
        </div>
      ))}
    </div>
  );
}

/** Разделя текста на части, за да се редува със снимките. */
function splitContent(content: string, parts: number): string[] {
  const text = String(content || "").trim();
  if (parts <= 1 || !text) return [text];

  const bySection = (sep: RegExp, joiner: string) =>
    text
      .split(sep)
      .map((p) => p.trim())
      .filter(Boolean)
      .map((p) => ({ p, joiner }));

  let units = bySection(/\n\s*\n/, "\n\n");
  if (units.length < parts) units = bySection(/\n+/, "\n");
  if (units.length < parts) {
    // разделяне по изречения, за да има текст до всяка снимка
    const sentences = text.split(/(?<=[.!?…])\s+(?=[А-ЯA-Z„])/).filter(Boolean);
    if (sentences.length > units.length) units = sentences.map((p) => ({ p: p.trim(), joiner: " " }));
  }
  if (units.length <= 1) return [text];

  const n = Math.min(parts, units.length);
  const chunks: string[] = [];
  const per = units.length / n;
  for (let i = 0; i < n; i++) {
    const slice = units.slice(Math.round(i * per), Math.round((i + 1) * per));
    chunks.push(slice.map((u) => u.p).join(slice[0]?.joiner ?? "\n\n"));
  }
  return chunks.filter(Boolean);
}

function ProjectDetail() {
  const { id } = Route.useParams();
  const [project, setProject] = useState<Project | null | undefined>(undefined);
  const [lightbox, setLightbox] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    fetchProjects()
      .then((items) => {
        if (!active) return;
        setProject(items.find((p) => p.id.trim() === id.trim()) ?? null);
      })
      .catch(() => active && setProject(null));
    return () => {
      active = false;
    };
  }, [id]);

  const blocks = useMemo(() => {
    if (!project) return [];
    const imgs = project.inlineImages;
    const chunks = splitContent(project.content, Math.max(1, imgs.length));
    const max = Math.max(chunks.length, imgs.length);
    return Array.from({ length: max }, (_, i) => ({
      text: chunks[i] ?? "",
      image: imgs[i] ?? "",
    }));
  }, [project]);

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content" className="mx-auto max-w-5xl px-4 py-10 lg:px-8">
        <Link
          to="/proekti"
          className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm text-primary no-underline"
        >
          <ArrowLeft className="h-4 w-4" />
          Всички проекти
        </Link>

        {project === undefined && (
          <p className="py-20 text-center text-muted-foreground">Зареждане...</p>
        )}
        {project === null && (
          <p className="py-20 text-center text-muted-foreground">Проектът не е намерен.</p>
        )}

        {project && (
          <article className="mt-8">
            <Reveal>
              <h1 className="text-center font-display text-3xl font-bold text-primary sm:text-4xl">
                {project.title}
              </h1>
              {project.rawDate && (
                <div className="mt-4 text-center">
                  <span className="inline-block rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground">
                    {project.rawDate}
                  </span>
                </div>
              )}
            </Reveal>

            {project.image && (
              <Reveal delay={150} className="mt-8">
                <img
              loading="lazy"
              decoding="async"
                  src={project.image}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  className="mx-auto w-full rounded-xl shadow-[var(--shadow-soft)]"
                />
              </Reveal>
            )}

            <div className="mt-10 space-y-10">
              {blocks.map((block, i) =>
                block.image ? (
                  <Reveal key={i} delay={100}>
                    <div
                      className={`grid items-center gap-8 md:grid-cols-2 ${
                        i % 2 === 1 ? "md:[&>*:first-child]:order-2" : ""
                      }`}
                    >
                      <RichText text={block.text} />
                      <img
                        src={block.image}
                        alt={`${project.title} – снимка ${i + 1}`}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="max-h-[520px] w-full rounded-xl border border-border bg-muted object-contain"
                      />
                    </div>
                  </Reveal>
                ) : (
                  block.text && (
                    <Reveal key={i}>
                      <RichText text={block.text} />
                    </Reveal>
                  )
                ),
              )}
            </div>

            {project.galleryImages.length > 0 && (
              <Reveal delay={150} className="mt-14">
                <h2 className="mb-6 text-center font-display text-2xl font-bold text-primary">
                  Галерия
                </h2>
                <div className="grid grid-cols-3 gap-3 md:grid-cols-5">
                  {project.galleryImages.map((img, i) => (
                    <button
                      key={img + i}
                      type="button"
                      onClick={() => setLightbox(i)}
                      className="flex aspect-square items-center justify-center overflow-hidden rounded-lg border border-border bg-white p-1"
                    >
                      <img
                        src={img}
                        alt={`${project.title} – изображение ${i + 1}`}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-contain transition-transform duration-700 hover:scale-105"
                      />
                    </button>
                  ))}
                </div>
              </Reveal>
            )}

            {project.videos.length > 0 && (
              <Reveal delay={150} className="mt-14">
                <h2 className="mb-6 text-center font-display text-2xl font-bold text-primary">
                  Видеа
                </h2>
                <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                  {project.videos.map((v, i) => (
                    <VideoBlock key={v + i} url={v} />
                  ))}
                </div>
              </Reveal>
            )}
          </article>
        )}
      </main>
      <SiteFooter />

      {lightbox !== null && project && project.galleryImages.length > 0 && (
        <Lightbox
          images={project.galleryImages}
          index={lightbox}
          onClose={() => setLightbox(null)}
          onChange={setLightbox}
        />
      )}
    </div>
  );
}
