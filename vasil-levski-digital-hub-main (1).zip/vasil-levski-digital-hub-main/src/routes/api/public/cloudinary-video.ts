import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/cloudinary-video")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const requestUrl = new URL(request.url);
        const cloud = requestUrl.searchParams.get("cloud")?.trim() ?? "";
        const publicId = requestUrl.searchParams.get("id")?.trim() ?? "";

        if (!/^[a-zA-Z0-9_-]+$/.test(cloud) || !publicId || publicId.length > 500) {
          return new Response("Invalid video", { status: 400 });
        }

        const encodedId = publicId.split("/").map(encodeURIComponent).join("/");
        const upstreamUrl = `https://res.cloudinary.com/${encodeURIComponent(cloud)}/video/upload/${encodedId}.mp4`;
        const range = request.headers.get("range");
        const upstreamHeaders = new Headers();
        if (range) upstreamHeaders.set("range", range);
        const upstream = await fetch(upstreamUrl, {
          headers: upstreamHeaders,
          redirect: "follow",
        });
        const contentType = upstream.headers.get("content-type") ?? "";

        if (!upstream.ok || !contentType.startsWith("video/")) {
          return new Response("Video not found", { status: 404 });
        }

        const headers = new Headers({
          "content-type": contentType,
          "cache-control": "public, max-age=604800, immutable",
          "accept-ranges": upstream.headers.get("accept-ranges") ?? "bytes",
        });
        const contentLength = upstream.headers.get("content-length");
        const contentRange = upstream.headers.get("content-range");
        if (contentLength) headers.set("content-length", contentLength);
        if (contentRange) headers.set("content-range", contentRange);

        return new Response(upstream.body, {
          status: upstream.status,
          headers,
        });
      },
    },
  },
});