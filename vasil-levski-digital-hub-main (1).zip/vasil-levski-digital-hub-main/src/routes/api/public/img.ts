import { createFileRoute } from "@tanstack/react-router";

/**
 * Прокси за изображения от Google Drive.
 * lh3.googleusercontent.com/d/... се блокира от ORB в браузъра,
 * затова изображението се сваля сървърно и се сервира от нашия домейн.
 */
export const Route = createFileRoute("/api/public/img")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const id = url.searchParams.get("id");
        if (!id || !/^[\w-]+$/.test(id)) {
          return new Response("Invalid id", { status: 400 });
        }

        // Незадължителна ширина за responsive srcset (100–2000px).
        const rawW = parseInt(url.searchParams.get("w") ?? "", 10);
        const w = Number.isFinite(rawW) ? Math.min(Math.max(rawW, 100), 2000) : 1600;

        const upstream = await fetch(
          `https://drive.google.com/thumbnail?id=${encodeURIComponent(id)}&sz=w${w}`,
          { redirect: "follow" },
        );
        const contentType = upstream.headers.get("content-type") ?? "";
        if (!upstream.ok || !contentType.startsWith("image/")) {
          return new Response("Image not found", { status: 404 });
        }

        return new Response(upstream.body, {
          headers: {
            "content-type": contentType,
            "cache-control": "public, max-age=604800, immutable",
          },
        });
      },
    },
  },
});
