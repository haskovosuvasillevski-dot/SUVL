import { createFileRoute } from "@tanstack/react-router";
import { Landmark } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { ContentSections } from "@/components/ContentSections";
import { HISTORY_SHEET_ID } from "@/lib/history";
const hero = "/assets/istoriya-banner.jpg";

const title = "История – СУ „Васил Левски“ Хасково";
const description =
  "Историята на СУ „Васил Левски“, град Хасково – наследник на първото новобългарско училище в Хасково от 1846 година.";

export const Route = createFileRoute("/istoriya")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HistoryPage,
});

function HistoryPage() {
  return (
    <PageShell title="История" image={hero} icon={<Landmark className="h-7 w-7" />}>
      <div className="mx-auto max-w-5xl px-4 py-12 lg:px-8 lg:py-16">
        <ContentSections sheetId={HISTORY_SHEET_ID} />
      </div>
    </PageShell>
  );
}
