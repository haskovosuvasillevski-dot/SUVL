import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Building2 } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { Reveal } from "@/components/Reveal";
import { fetchFacilities, type Facility } from "@/lib/facilities";
const banner = "/assets/materialna-baza-banner.jpg";
const iconArt = "/assets/fac-a1.png";
const iconLang = "/assets/fac-a2.png";
const iconComputer = "/assets/fac-a3.png";
const iconClass = "/assets/fac-a4.png";
const iconLockers = "/assets/fac-a5.png";
const iconSport = "/assets/fac-a6.png";
const iconLibrary = "/assets/fac-a7.png";
const iconFood = "/assets/fac-a8.png";
const iconMedical = "/assets/fac-a9.png";

const title = "Материална база – СУ „Васил Левски“ Хасково";
const description =
  "Кабинети, зали и съвременно оборудване в материалната база на СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/materialna-baza/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: banner },
      { name: "twitter:image", content: banner },
    ],
  }),
  component: FacilitiesPage,
});

/** Кратък преглед на материалната база с иконки. */
const HIGHLIGHTS: { strong: string; rest: string; icon: string }[] = [
  { strong: "Ремонтирани и модерно обзаведени", rest: "учебни кабинети", icon: iconArt },
  { strong: "Интерактивни дъски", rest: "и проектори", icon: iconLang },
  { strong: "Компютърни", rest: "кабинети", icon: iconComputer },
  { strong: "Конферентна", rest: "зала", icon: iconClass },
  { strong: "Индивидуални шкафчета", rest: "за учениците", icon: iconLockers },
  { strong: "Физкултурен салон", rest: "и спортна зала", icon: iconSport },
  { strong: "Богата библиотека", rest: "с малък копирен център", icon: iconLibrary },
  { strong: "Столово", rest: "хранене", icon: iconFood },
  { strong: "Медицински", rest: "кабинет", icon: iconMedical },
];

function HighlightCell({ item }: { item: (typeof HIGHLIGHTS)[number] }) {
  return (
    <div className="flex h-full flex-col items-center justify-start gap-4 px-4 py-8 text-center">
      <img
        src={item.icon}
        alt={`${item.strong} ${item.rest}`}
        loading="lazy"
        className="h-16 w-16 object-contain sm:h-20 sm:w-20"
      />
      <p className="font-montserrat text-sm leading-snug text-muted-foreground">
        <span className="font-bold text-primary">{item.strong}</span>{" "}
        <span>{item.rest}</span>
      </p>

    </div>
  );
}

function HighlightsGrid() {
  const firstRow = HIGHLIGHTS.slice(0, 5);
  const secondRow = HIGHLIGHTS.slice(5);
  return (
    <section className="bg-secondary/30 py-14">
      <div className="mx-auto max-w-6xl px-4 lg:px-8">
        <h2 className="text-center font-montserrat text-2xl font-extrabold uppercase tracking-wide text-primary sm:text-4xl">
          Вашите деца са в добри ръце
        </h2>

        <div className="mt-4 flex justify-center">
          <svg viewBox="0 0 220 16" className="h-4 w-52 text-destructive" fill="none">
            <path d="M4 11C60 3 150 3 216 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M8 6C70 12 160 12 212 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </div>

        <div className="mt-10 overflow-hidden rounded-3xl bg-card shadow-[var(--shadow-soft)]">
          {/* Мобилно/таблет: 3 колони */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:hidden">
            {HIGHLIGHTS.map((h, i) => (
              <Reveal key={h.strong} delay={i * 60}>
                <div className="h-full border-b border-r border-border/60">
                  <HighlightCell item={h} />
                </div>
              </Reveal>
            ))}
          </div>

          {/* Голям екран: 5 + 4 центрирани */}
          <div className="hidden lg:block">
            <div className="grid grid-cols-5 border-b border-border/60">
              {firstRow.map((h, i) => (
                <Reveal key={h.strong} delay={i * 60}>
                  <div className="h-full border-r border-border/60 last:border-r-0">
                    <HighlightCell item={h} />
                  </div>
                </Reveal>
              ))}
            </div>
            <div className="mx-auto grid w-4/5 grid-cols-4">
              {secondRow.map((h, i) => (
                <Reveal key={h.strong} delay={(i + 5) * 60}>
                  <div className="h-full border-r border-border/60 last:border-r-0">
                    <HighlightCell item={h} />
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}


function FacilitiesPage() {
  const [items, setItems] = useState<Facility[] | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    fetchFacilities()
      .then((data) => active && setItems(data))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, []);

  return (
    <PageShell
      title="Материална база"
      image={banner}
      icon={<Building2 className="h-7 w-7" />}
    >
      <HighlightsGrid />
      <section className="bg-secondary/40 py-12">
        <div className="mx-auto max-w-6xl px-4 lg:px-8">
          {error && (
            <p className="text-center text-destructive">
              Възникна грешка при зареждане на материалната база.
            </p>
          )}
          {!error && !items && (
            <p className="text-center text-muted-foreground">Зареждане...</p>
          )}
          {items && items.length === 0 && (
            <p className="text-center text-muted-foreground">Няма добавено съдържание.</p>
          )}

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {(items ?? []).map((f, i) => (
              <Reveal key={f.id} delay={i * 60}>
                <Link
                  to="/materialna-baza/$id"
                  params={{ id: f.id }}
                  className="group block overflow-hidden rounded-xl border border-border bg-card no-underline shadow-[var(--shadow-soft)]"
                >
                  <div className="aspect-square overflow-hidden bg-muted">
                    {f.image ? (
                      <img
                        src={f.image}
                        alt={f.title}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                    ) : null}
                  </div>
                  <h2 className="px-4 py-4 text-center font-display text-lg font-bold leading-snug text-primary transition-colors group-hover:text-brand-green">
                    {f.title}
                  </h2>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </PageShell>
  );
}
