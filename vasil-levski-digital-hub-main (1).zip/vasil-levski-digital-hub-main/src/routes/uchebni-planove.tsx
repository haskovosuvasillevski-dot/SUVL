import { ClipboardList } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { AutoIframe } from "@/components/AutoIframe";
const banner = "/assets/uchebni-planove-hero.jpg";

const title = "Учебни планове – СУ „Васил Левски“ Хасково";
const description =
  "Учебни планове по класове и профили в СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/uchebni-planove")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PlansPage,
});

function PlansPage() {
  return (
    <PageShell title="Учебни планове" image={banner} icon={<ClipboardList className="h-7 w-7" />}>
      <section className="mx-auto max-w-7xl px-2 py-10 lg:px-8">
        <AutoIframe src="/uchebni-planove.html" title="Учебни планове" />
      </section>
    </PageShell>
  );
}
