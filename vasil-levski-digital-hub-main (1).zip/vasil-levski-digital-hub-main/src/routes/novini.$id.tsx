import { useEffect, useState, useCallback } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, X, ChevronLeft, ChevronRight } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { fetchNews, type NewsItem } from "@/lib/news";
import { driveImgProps } from "@/lib/imgProps";

export const Route = createFileRoute("/novini/$id")({
  head: () => ({
    meta: [
      { title: "Новина | СУ „Васил Левски“ – Хасково" },
      {
        name: "description",
        content: "Новини и събития от СУ „Васил Левски“, град Хасково.",
      },
      { property: "og:title", content: "Новина | СУ „Васил Левски“ – Хасково" },
      {
        property: "og:description",
        content: "Новини и събития от СУ „Васил Левски“, град Хасково.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NewsDetail,
});

function NewsDetail() {
  const { id } = Route.useParams();
  const [item, setItem] = useState<NewsItem | null | undefined>(undefined);
  const [lightbox, setLightbox] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    fetchNews()
      .then((items) => {
        if (!active) return;
        setItem(items.find((n) => n.id === Number(id)) ?? null);
      })
      .catch(() => active && setItem(null));
    return () => {
      active = false;
    };
  }, [id]);

  const images = item ? [item.imageUrl, ...item.gallery].filter(Boolean) : [];

  const move = useCallback(
    (dir: number) => {
      setLightbox((cur) =>
        cur === null ? cur : (cur + dir + images.length) % images.length,
      );
    },
    [images.length],
  );

  useEffect(() => {
    if (lightbox === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLightbox(null);
      if (e.key === "ArrowRight") move(1);
      if (e.key === "ArrowLeft") move(-1);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [lightbox, move]);

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content" className="mx-auto max-w-5xl px-4 py-10 lg:px-8">
        <Link
          to="/"
          className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm text-primary transition-colors duration-500 hover:bg-secondary"
        >
          <ArrowLeft className="h-4 w-4" /> Назад към началната страница
        </Link>

        {item === undefined && (
          <p className="py-16 text-center text-muted-foreground">Зареждане...</p>
        )}

        {item === null && (
          <p className="py-16 text-center text-muted-foreground">
            Новината не е намерена.
          </p>
        )}

        {item && (
          <article className="mt-8">
            <Reveal>
              <h1 className="text-center font-display text-3xl font-bold text-primary sm:text-4xl">
                {item.title}
              </h1>
              <div className="mt-4 text-center">
                <span className="inline-block rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground">
                  {item.rawDate}
                </span>
              </div>
            </Reveal>

            {item.imageUrl && (
              <Reveal delay={150} className="mt-8">
                <img
                  {...driveImgProps(item.imageUrl, "(min-width:768px) 768px, 100vw")}
                  alt={item.title}
                  loading="lazy"
                  decoding="async"
                  className="mx-auto w-full cursor-pointer rounded-xl shadow-[var(--shadow-soft)] transition-transform duration-500 hover:scale-[1.01]"
                  onClick={() => setLightbox(0)}
                />
              </Reveal>
            )}

            <Reveal delay={200} className="mx-auto mt-10 max-w-3xl">
              <div className="whitespace-pre-line text-[1.05rem] leading-8 text-muted-foreground">
                {item.content}
              </div>
              {item.author && (
                <p className="mt-8 border-b border-border pb-6 italic text-muted-foreground">
                  Автор: {item.author}
                </p>
              )}
            </Reveal>

            {item.gallery.length > 0 && (
              <Reveal delay={250} className="mx-auto mt-12 max-w-4xl">
                <h2 className="mb-6 text-center font-display text-2xl font-bold text-primary">
                  Галерия
                </h2>
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                  {item.gallery.map((img, i) => (
                    <button
                      key={img + i}
                      type="button"
                      onClick={() => setLightbox(item.imageUrl ? i + 1 : i)}
                      className="aspect-[4/3] overflow-hidden rounded-lg border border-border"
                    >
                      <img
                        {...driveImgProps(
                          img,
                          "(min-width:640px) 260px, 50vw",
                          400,
                        )}
                        alt={`${item.title} – снимка ${i + 1}`}
                        loading="lazy"
                        decoding="async"
                        className="h-full w-full object-cover transition-transform duration-700 hover:scale-110"
                      />
                    </button>
                  ))}
                </div>
              </Reveal>
            )}
          </article>
        )}
      </main>
      <SiteFooter />

      {lightbox !== null && images[lightbox] && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-foreground/95">
          <button
            type="button"
            aria-label="Затвори"
            onClick={() => setLightbox(null)}
            className="absolute right-5 top-5 text-background"
          >
            <X className="h-8 w-8" />
          </button>
          {images.length > 1 && (
            <button
              type="button"
              aria-label="Предишна"
              onClick={() => move(-1)}
              className="absolute left-4 text-background"
            >
              <ChevronLeft className="h-10 w-10" />
            </button>
          )}
          <img
              loading="lazy"
              decoding="async"
            src={images[lightbox]}
            alt="Увеличена снимка"
            className="max-h-[85vh] max-w-[90%] object-contain"
          />
          {images.length > 1 && (
            <button
              type="button"
              aria-label="Следваща"
              onClick={() => move(1)}
              className="absolute right-4 text-background"
            >
              <ChevronRight className="h-10 w-10" />
            </button>
          )}
          <div className="absolute bottom-6 text-sm text-background">
            {lightbox + 1} / {images.length}
          </div>
        </div>
      )}
    </div>
  );
}
