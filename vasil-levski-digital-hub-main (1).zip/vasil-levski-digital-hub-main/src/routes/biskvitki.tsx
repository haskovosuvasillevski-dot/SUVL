import { createFileRoute } from "@tanstack/react-router";
import { Cookie } from "lucide-react";
import { PageShell } from "@/components/PageShell";
const hero = "/assets/news-banner.jpg";

const title = "Политика за бисквитки – СУ „Васил Левски“ Хасково";
const description =
  "Политика за използване на бисквитки на официалния сайт на СУ „Васил Левски“, град Хасково.";

export const Route = createFileRoute("/biskvitki")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CookiesPage,
});

function Section({ heading, children }: { heading: string; children: React.ReactNode }) {
  return (
    <section className="space-y-3">
      <h2 className="font-display text-xl font-bold text-primary sm:text-2xl">{heading}</h2>
      <div className="space-y-3 text-[15px] leading-relaxed text-foreground/90">{children}</div>
    </section>
  );
}

function CookiesPage() {
  return (
    <PageShell title="Бисквитки" image={hero} icon={<Cookie className="h-7 w-7" />}>
      <div className="mx-auto max-w-4xl space-y-8 px-4 py-12 lg:px-8 lg:py-16">
        <p className="text-[15px] leading-relaxed text-muted-foreground">
          Настоящата политика е изготвена в съответствие с Регламент (ЕС) 2016/679 (GDPR),
          Закона за защита на личните данни и чл. 4б от Закона за електронната търговия и
          обяснява какви бисквитки използва официалният сайт на СУ „Васил Левски“ – град
          Хасково.
        </p>

        <Section heading="1. Какво представляват бисквитките">
          <p>
            „Бисквитките“ (cookies) са малки текстови файлове, които се съхраняват във
            Вашето крайно устройство (компютър, таблет, смартфон) при посещение на сайта.
            Те позволяват сайтът да запомни определени действия и предпочитания за
            определен период от време.
          </p>
        </Section>

        <Section heading="2. Какви бисквитки използваме">
          <ul className="list-disc space-y-2 pl-5">
            <li>
              <strong>Строго необходими бисквитки</strong> – осигуряват основната
              функционалност на сайта (навигация, зареждане на съдържание, сигурност). Те
              не изискват съгласие съгласно чл. 4б, ал. 3 от ЗЕТ.
            </li>
            <li>
              <strong>Функционални бисквитки</strong> – запомнят Вашия избор (например
              затворено съобщение или предпочитан изглед).
            </li>
            <li>
              <strong>Бисквитки на трети страни</strong> – при вграждане на съдържание от
              Google (Google Sheets, Google Drive, Google Maps), YouTube и Cloudinary тези
              доставчици могат да поставят собствени бисквитки. Използването им се урежда
              от техните политики за поверителност.
            </li>
          </ul>
          <p>
            Сайтът <strong>не използва</strong> бисквитки за профилиране, поведенческа
            реклама или проследяване на ученици.
          </p>
        </Section>

        <Section heading="3. Срок на съхранение">
          <p>
            Сесийните бисквитки се изтриват при затваряне на браузъра. Постоянните
            бисквитки се съхраняват за срок не по-дълъг от 12 месеца, освен ако не бъдат
            изтрити по-рано от Вас.
          </p>
        </Section>

        <Section heading="4. Управление и отказ от бисквитки">
          <p>
            Можете по всяко време да изтриете или блокирате бисквитките от настройките на
            своя браузър (Chrome, Firefox, Edge, Safari и др.). Блокирането на строго
            необходимите бисквитки може да ограничи функционалността на сайта.
          </p>
        </Section>

        <Section heading="5. Контакти">
          <p>
            Въпроси относно тази политика можете да отправите на{" "}
            <a className="font-semibold text-primary underline" href="mailto:info-2601025@edu.mon.bg">
              info-2601025@edu.mon.bg
            </a>{" "}
            или на телефон 038 / 66 43 16.
          </p>
        </Section>
      </div>
    </PageShell>
  );
}
