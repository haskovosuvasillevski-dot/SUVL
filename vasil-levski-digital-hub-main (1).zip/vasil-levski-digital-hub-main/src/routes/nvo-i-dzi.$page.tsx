import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, FileText, X } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { fetchExamPage, type ExamPage } from "@/lib/exams";

export const Route = createFileRoute("/nvo-i-dzi/$page")({
  head: ({ params }) => {
    const title = `${params.page} – СУ „Васил Левски“ Хасково`;
    const description = `Материали и информация за ${params.page} в СУ „Васил Левски“ – град Хасково.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: ExamDetailPage,
});

type Modal = { type: "image" | "file"; view: string; download: string } | null;

function ExamDetailPage() {
  const { page } = Route.useParams();
  const [data, setData] = useState<ExamPage | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "empty" | "error">("loading");
  const [modal, setModal] = useState<Modal>(null);

  useEffect(() => {
    let alive = true;
    setState("loading");
    fetchExamPage(page)
      .then((res) => {
        if (!alive) return;
        setData(res);
        setState(res ? "ready" : "empty");
      })
      .catch(() => alive && setState("error"));
    return () => {
      alive = false;
    };
  }, [page]);

  useEffect(() => {
    if (!modal) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setModal(null);
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [modal]);

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content" className="mx-auto w-full max-w-4xl px-5 py-14 sm:px-8">
        <Reveal>
          <Link
            to="/nvo-i-dzi"
            className="mb-6 inline-block text-sm font-semibold text-primary underline underline-offset-4"
          >
            ← Обратно към НВО и ДЗИ
          </Link>
          <h1 className="text-center font-display text-3xl font-bold text-primary sm:text-4xl">
            {state === "loading" ? "Зареждане..." : (data?.title ?? page)}
          </h1>
        </Reveal>

        {state === "empty" && (
          <p className="mt-10 text-center text-muted-foreground">Няма данни.</p>
        )}
        {state === "error" && (
          <p className="mt-10 text-center text-destructive">Грешка при зареждане.</p>
        )}

        {data?.description && (
          <Reveal delay={120}>
            <p className="mx-auto mt-8 max-w-3xl whitespace-pre-line text-justify text-[17px] leading-relaxed text-foreground">
              {data.description}
            </p>
          </Reveal>
        )}

        {data && data.images.length > 0 && (
          <div className="mt-10 flex flex-wrap justify-center gap-5">
            {data.images.map((img, i) => (
              <Reveal key={img.view} delay={Math.min(i * 100, 400)} className="w-full sm:w-[calc(50%-10px)]">
                <button
                  type="button"
                  onClick={() => setModal({ type: "image", ...img })}
                  className="block w-full rounded-lg border border-border bg-card p-2.5 transition duration-300 hover:scale-[1.02] hover:shadow-[var(--shadow-soft)]"
                >
                  <img src={img.view} alt="" loading="lazy" className="w-full rounded" />
                </button>
              </Reveal>
            ))}
          </div>
        )}

        {data && data.files.length > 0 && (
          <div className="mt-10 flex flex-wrap justify-center gap-5">
            {data.files.map((file, i) => (
              <button
                key={`${file.preview}-${i}`}
                type="button"
                aria-label="Отвори файла"
                onClick={() => setModal({ type: "file", view: file.preview, download: file.download })}
                className="flex h-16 w-16 items-center justify-center rounded-full bg-[#3498db] text-white transition duration-300 hover:scale-110 hover:bg-[#2980b9]"
              >
                <FileText className="h-7 w-7" />
              </button>
            ))}
          </div>
        )}
      </main>

      {modal && (
        <div
          className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/85 p-4"
          onClick={(e) => e.target === e.currentTarget && setModal(null)}
        >
          <div className="relative w-full max-w-2xl rounded-xl bg-white p-6 text-center">
            <button
              type="button"
              aria-label="Затвори"
              onClick={() => setModal(null)}
              className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
            >
              <X className="h-6 w-6" />
            </button>
            {modal.type === "image" ? (
              <img
              loading="lazy"
              decoding="async" src={modal.view} alt="" className="mx-auto max-h-[70vh] max-w-full rounded" />
            ) : (
              <iframe title="Преглед" src={modal.view} className="h-[420px] w-full border-0" />
            )}
            <a
              href={modal.download}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex items-center gap-2 font-bold text-[#3498db]"
            >
              <Download className="h-5 w-5" /> Изтегли файла
            </a>
          </div>
        </div>
      )}
      <SiteFooter />
    </div>
  );
}
