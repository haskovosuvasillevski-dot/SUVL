import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download, Eye, X, CalendarClock } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import {
  fetchSchedules,
  getDownloadUrl,
  getPreviewUrl,
  type ScheduleItem,
} from "@/lib/schedules";
const grafik = "/assets/grafik.jpg";

const title = "Графици – СУ „Васил Левски“ Хасково";
const description =
  "Графици за учебната година на СУ „Васил Левски“ – Хасково: консултации, контролни и класни работи.";

export const Route = createFileRoute("/grafitsi")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: grafik },
      { name: "twitter:image", content: grafik },
    ],
  }),
  component: SchedulesPage,
});

function SchedulesPage() {
  const [items, setItems] = useState<ScheduleItem[] | null>(null);
  const [error, setError] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetchSchedules()
      .then((data) => active && setItems(data))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = preview ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [preview]);

  const OTHER = "Други графици";
  const termOf = (raw: string) => {
    const t = (raw || "").trim();
    if (!t) return OTHER;
    if (/\b1\b|първи|i\s*срок/i.test(t) || /^I\s/i.test(t)) return t;
    if (/\b2\b|втори|ii\s*срок/i.test(t)) return t;
    return OTHER;
  };
  const rank = (t: string) => (t === OTHER ? 2 : /\b1\b|първи/i.test(t) ? 0 : 1);
  const terms = Array.from(new Set((items ?? []).map((i) => termOf(i.term)))).sort(
    (a, b) => rank(a) - rank(b),
  );

  return (
    <PageShell title="Графици" image={grafik} icon={<CalendarClock className="h-7 w-7" />}>
      <section className="bg-secondary/40 py-12">
        <div className="mx-auto max-w-5xl px-4 lg:px-8">
          {error && (
            <p className="text-center text-destructive">
              Възникна грешка при зареждане на графиците.
            </p>
          )}
          {!error && !items && (
            <p className="text-center text-muted-foreground">Зареждане на графиците...</p>
          )}

          {terms.map((term) => (
            <div key={term} className="mb-10">
              <h2 className="mb-5 text-center font-display text-2xl font-bold text-primary sm:text-3xl">
                {term}
              </h2>
              <div className="space-y-3">
                {(items ?? [])
                  .filter((i) => termOf(i.term) === term)
                  .map((item, i) => (
                    <div
                      key={`${term}-${i}`}
                      className="flex flex-col gap-4 rounded-lg border border-border bg-card p-5 transition hover:shadow-[var(--shadow-soft)] sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0">
                        <h3 className="font-display text-lg font-bold text-primary">
                          {item.title}
                        </h3>
                        {item.classes && (
                          <p className="mt-1 text-sm text-muted-foreground">{item.classes}</p>
                        )}
                      </div>
                      <div className="flex shrink-0 gap-3">
                        <button
                          type="button"
                          onClick={() => setPreview(getPreviewUrl(item.link))}
                          className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
                        >
                          <Eye className="h-4 w-4" /> Преглед
                        </button>
                        <a
                          href={getDownloadUrl(item.link)}
                          target="_blank"
                          rel="noopener"
                          className="inline-flex items-center gap-2 rounded-md border border-border px-4 py-2 text-sm font-semibold text-primary transition hover:bg-secondary"
                        >
                          <Download className="h-4 w-4" /> Изтегли
                        </a>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {preview && (
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/80 p-4"
          onClick={(e) => e.target === e.currentTarget && setPreview(null)}
        >
          <div className="relative h-full max-h-[88vh] w-full max-w-4xl overflow-hidden rounded-lg bg-background">
            <button
              type="button"
              aria-label="Затвори"
              onClick={() => setPreview(null)}
              className="absolute right-3 top-3 z-10 rounded-full bg-primary p-2 text-primary-foreground"
            >
              <X className="h-5 w-5" />
            </button>
            <iframe src={preview} title="Преглед на документа" className="h-full w-full border-0" />
          </div>
        </div>
      )}
    </PageShell>
  );
}
