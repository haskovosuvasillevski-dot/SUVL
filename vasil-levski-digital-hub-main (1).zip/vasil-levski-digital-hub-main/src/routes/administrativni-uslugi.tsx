import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download, X, FileSignature } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { PageHero } from "@/components/PageShell";
import {
  fetchAdminServices,
  getDownloadUrl,
  getPreviewUrl,
  type AdminService,
} from "@/lib/adminServices";
const hero = "/assets/handing-papers.jpg";

const title = "Административни услуги – СУ „Васил Левски“ Хасково";
const description =
  "Административни услуги, бланки и документи на СУ „Васил Левски“ – град Хасково, с възможност за преглед и изтегляне.";

export const Route = createFileRoute("/administrativni-uslugi")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: AdminServicesPage,
});

function PdfModal({
  service,
  onClose,
}: {
  service: AdminService | null;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!service) return;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      document.removeEventListener("keydown", onKey);
    };
  }, [service, onClose]);

  if (!service) return null;

  return (
    <div
      className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/78 p-0 sm:p-6"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-white shadow-2xl sm:h-[92vh] sm:w-[95vw] sm:max-w-5xl sm:rounded">
        <div className="flex min-h-[58px] items-center justify-between gap-4 bg-primary px-3 py-2 text-primary-foreground sm:min-h-[64px] sm:px-5">
          <div className="min-w-0 flex-1 truncate text-sm font-medium sm:text-lg">
            {service.title}
          </div>
          <div className="flex items-center gap-2">
            <a
              href={getDownloadUrl(service.file)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-9 items-center justify-center gap-2 rounded-sm bg-white px-3 text-xs font-semibold text-primary hover:bg-secondary sm:h-10 sm:px-4 sm:text-sm"
            >
              <Download className="h-4 w-4" />
              Изтегляне
            </a>
            <button
              type="button"
              aria-label="Затвори"
              onClick={onClose}
              className="flex h-9 w-9 items-center justify-center rounded-sm bg-white/10 text-2xl hover:bg-white/25 sm:h-10 sm:w-10"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        <iframe
          title="Преглед на PDF"
          src={getPreviewUrl(service.file)}
          className="min-h-0 w-full flex-1 border-0 bg-secondary"
        />
      </div>
    </div>
  );
}

function ServiceItem({
  service,
  onOpen,
  delay,
}: {
  service: AdminService;
  onOpen: (s: AdminService) => void;
  delay: number;
}) {
  const hasFile = Boolean(service.file);
  return (
    <Reveal delay={delay}>
      <article className="mb-10 flex w-full items-start">
        <div
          role={hasFile ? "button" : undefined}
          tabIndex={hasFile ? 0 : -1}
          onClick={() => hasFile && onOpen(service)}
          onKeyDown={(e) => {
            if (hasFile && (e.key === "Enter" || e.key === " ")) onOpen(service);
          }}
          title={hasFile ? "Преглед и изтегляне" : undefined}
          className={`mr-6 flex h-[76px] w-[76px] flex-none items-center justify-center rounded-full bg-primary sm:mr-10 ${
            hasFile
              ? "cursor-pointer transition-transform duration-200 hover:scale-[1.06] hover:bg-primary/90"
              : ""
          }`}
        >
          <Download className="h-8 w-8 text-primary-foreground" />
        </div>
        <div className="min-w-0 flex-1 pt-4 sm:pt-5">
          {hasFile ? (
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onOpen(service);
              }}
              className="inline-block text-lg font-medium leading-relaxed text-primary underline decoration-1 underline-offset-4 transition-colors hover:text-primary/80 sm:text-xl"
            >
              {service.title}
            </a>
          ) : (
            <span className="inline-block text-lg font-medium leading-relaxed text-primary sm:text-xl">
              {service.title}
            </span>
          )}
          {service.information && (
            <div className="mt-2.5 max-w-3xl text-sm leading-relaxed text-muted-foreground sm:text-base">
              {service.information}
            </div>
          )}
        </div>
      </article>
    </Reveal>
  );
}

function AdminServicesPage() {
  const [services, setServices] = useState<AdminService[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [active, setActive] = useState<AdminService | null>(null);

  useEffect(() => {
    let alive = true;
    fetchAdminServices()
      .then((data) => alive && setServices(data))
      .catch((err) => alive && setError(err?.message || "Неуспешно зареждане."));
    return () => {
      alive = false;
    };
  }, []);

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <PageHero
          title="Административни услуги"
          image={hero}
          icon={<FileSignature />}
        />

        <div className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-20">
          {!services && !error && (
            <p className="w-full py-11 text-center text-base text-muted-foreground">
              Зареждане...
            </p>
          )}

          {error && (
            <Reveal>
              <div className="mx-auto max-w-2xl rounded border border-border bg-secondary/40 p-6 text-center leading-relaxed text-muted-foreground">
                <strong className="text-primary">
                  Неуспешно зареждане на административните услуги.
                </strong>
                <br />
                <br />
                {error}
                <br />
                <br />
                <small>Провери дали Google Sheets е публикуван за четене.</small>
              </div>
            </Reveal>
          )}

          {services && services.length === 0 && !error && (
            <p className="w-full py-11 text-center text-base text-muted-foreground">
              Няма налични административни услуги.
            </p>
          )}

          {services && services.length > 0 && (
            <div>
              {services.map((service, i) => (
                <ServiceItem
                  key={service.id || service.title}
                  service={service}
                  onOpen={setActive}
                  delay={Math.min(i * 60, 400)}
                />
              ))}
            </div>
          )}
        </div>
      </main>
      <SiteFooter />

      <PdfModal service={active} onClose={() => setActive(null)} />
    </div>
  );
}
