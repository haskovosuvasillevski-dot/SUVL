import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { AdmissionGallery } from "@/components/AdmissionGallery";
import { ProfileCards } from "@/components/ProfileCards";
import {
  fetchProfileRows,
  findSection,
  getValue,
  imageSrc,
  isEmpty,
  resolveSpecialty,
  splitDescription,
  type SheetRow,
} from "@/lib/priem8";

const title = "Профилиращи предмети – СУ „Васил Левски“ Хасково";
const description =
  "Подробна информация за профилиращите предмети и модулите при приема в VIII клас в СУ „Васил Левски“ – Хасково.";

export const Route = createFileRoute("/priem-8-klas-pr")({
  validateSearch: (search: Record<string, unknown>) => ({
    specialnost:
      typeof search['specialnost'] === "string" ? search['specialnost'] : "Природни науки",
  }),
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProfilePage,
});

function RichText({ value, className = "" }: { value: string; className?: string }) {
  if (isEmpty(value)) return null;
  if (/<\/?[a-z][\s\S]*>/i.test(value)) {
    return <div className={className} dangerouslySetInnerHTML={{ __html: value }} />;
  }
  return <div className={`whitespace-pre-line ${className}`}>{value}</div>;
}

function Modules({ row, prefix }: { row: SheetRow | null; prefix: string }) {
  const titles = ["J", "L", "N", "P"];
  const images = ["K", "M", "O", "Q"];
  const cards = titles.map((col, i) => ({
    title: getValue(row, col, `Модул ${i + 1} - Заглавие`),
    image: imageSrc(getValue(row, images[i] ?? "", `Модул ${i + 1} - Изображение`)),
    index: i + 1,
  }));
  const visible = cards.filter((c) => !isEmpty(c.title) || c.image);
  if (visible.length === 0) return null;
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      {visible.map((card, i) => (
        <Reveal key={`${prefix}-${card.index}`} delay={i * 120}>
          <article className="flex aspect-square flex-col items-center justify-center gap-3 rounded-xl border border-[#eee] bg-white p-6 text-center shadow-[0_7px_25px_rgba(0,0,0,0.10)]">
            {card.image && (
              <img src={card.image} alt={card.title} loading="lazy" className="h-16 w-auto" />
            )}
            <span className="text-sm font-semibold uppercase tracking-wide text-accent">
              Модул {card.index}
            </span>
            <span className="text-base font-bold leading-snug text-primary">{card.title}</span>
          </article>
        </Reveal>
      ))}
    </div>
  );
}

function ProfilePage() {
  const { specialnost } = Route.useSearch();
  const specialty = resolveSpecialty(specialnost);
  const [rows, setRows] = useState<SheetRow[] | null>(null);

  useEffect(() => {
    let active = true;
    fetchProfileRows()
      .then((data) => active && setRows(data))
      .catch(() => active && setRows([]));
    return () => {
      active = false;
    };
  }, []);

  const section = (n: number) => (rows ? findSection(rows, specialty, n) : null);

  const s1 = section(1);
  const s2 = section(2);
  const s3 = section(3);
  const s4 = section(4);
  const s5 = section(5);
  const s6 = section(6);
  const s7 = section(7);
  const s8 = section(8);

  const [text2a, text2b] = splitDescription(getValue(s2, "D", "Описание"));
  const bg2 = imageSrc(getValue(s2, "E", "Изображение"));
  const title4 = getValue(s4, "C", "Заглавие").split("||").map((p) => p.trim());
  const image4 = imageSrc(getValue(s4, "E", "Изображение"));
  const title6 = getValue(s6, "C", "Заглавие").split("||").map((p) => p.trim());
  const image6 = imageSrc(getValue(s6, "E", "Изображение"));
  const optional5 = getValue(s5, "R", "Избираем модул", "Избираем предмет");
  const optional7 = getValue(s7, "R", "Избираем модул", "Избираем предмет");
  const cards = [
    { title: getValue(s3, "F", "Карта 1 - Заглавие"), body: getValue(s3, "G", "Карта 1 - Съдържание") },
    { title: getValue(s3, "H", "Карта 2 - Заглавие"), body: getValue(s3, "I", "Карта 2 - Съдържание") },
  ].filter((c) => !isEmpty(c.title) || !isEmpty(c.body));

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <header className="bg-white px-5 py-16 text-center">
          <div className="mx-auto w-[min(1250px,92%)]">
            <Reveal>
              <h1 className="font-display text-3xl font-bold leading-tight text-primary sm:text-5xl">
                {getValue(s1, "C", "Заглавие") || (rows ? specialty : "Зареждане...")}
              </h1>
            </Reveal>
            <Reveal delay={120}>
              <RichText
                value={getValue(s1, "D", "Описание")}
                className="mx-auto mt-5 max-w-3xl text-[17px] leading-8 text-muted-foreground"
              />
              <div className="mt-8 flex flex-wrap justify-center gap-4">
                <a
                  href="#blue-section"
                  className="inline-flex min-w-40 items-center justify-center rounded-full border-[1.5px] border-[#333] bg-white px-7 py-3.5 font-semibold text-[#333] transition hover:bg-secondary"
                >
                  Научете повече
                </a>
                <a
                  href="https://infopriem.mon.bg/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-w-40 items-center justify-center rounded-full border-[1.5px] border-[#ef633f] bg-[#ef633f] px-7 py-3.5 font-semibold text-white transition hover:opacity-90"
                >
                  Кандидатстване
                </a>
              </div>
            </Reveal>
          </div>
        </header>

        {(!isEmpty(getValue(s2, "C", "Заглавие")) || text2a || bg2) && (
          <section
            id="blue-section"
            className="relative bg-[#042253] bg-cover bg-center px-5 py-20"
            style={bg2 ? { backgroundImage: `linear-gradient(rgba(4,34,83,.72),rgba(4,34,83,.72)), url(${bg2})` } : undefined}
          >
            <div className="mx-auto w-[min(1500px,92%)]">
              <Reveal>
                <h2 className="text-center font-display text-3xl font-bold text-white sm:text-4xl">
                  {getValue(s2, "C", "Заглавие")}
                </h2>
              </Reveal>
              <div className="mt-10 grid gap-8 lg:grid-cols-2">
                <Reveal>
                  <RichText value={text2a} className="text-[17px] leading-8 text-white/90" />
                </Reveal>
                <Reveal delay={150}>
                  <RichText value={text2b} className="text-[17px] leading-8 text-white/90" />
                </Reveal>
              </div>
            </div>
          </section>
        )}

        {cards.length > 0 && (
          <section className="px-5 py-16">
            <ProfileCards
              cards={cards}
              renderBody={(value) => <RichText value={value} />}
            />
          </section>
        )}

        {title4[0] && (
          <section className="bg-[#73147f] px-5 py-10 text-center">
            <h2 className="font-display text-[clamp(27px,3.5vw,45px)] font-bold leading-tight text-white">
              <span className="block">{title4[0]}</span>
              {title4[1] && <span className="block">{title4[1]}</span>}
            </h2>
          </section>
        )}

        {(!isEmpty(getValue(s4, "D", "Описание")) || image4) && (
          <section className="px-5 py-16">
            <div className="mx-auto grid w-[min(1500px,92%)] items-center gap-10 lg:grid-cols-2">
              <Reveal>
                <RichText
                  value={getValue(s4, "D", "Описание")}
                  className="text-[17px] leading-8 text-muted-foreground"
                />
              </Reveal>
              {image4 && (
                <Reveal delay={150}>
                  <img
                    src={image4}
                    alt={title4.join(" ")}
                    loading="lazy"
                    className="w-full rounded-2xl object-cover shadow-[var(--shadow-soft)]"
                  />
                </Reveal>
              )}
            </div>
          </section>
        )}

        <section className="bg-secondary/50 px-5 py-16">
          <div className="mx-auto w-[min(1500px,92%)]">
            {!isEmpty(getValue(s5, "C", "Заглавие")) && (
              <Reveal>
                <h2 className="mb-4 text-center font-display text-3xl font-bold text-primary">
                  {getValue(s5, "C", "Заглавие")}
                </h2>
              </Reveal>
            )}
            <Reveal delay={100}>
              <RichText
                value={getValue(s5, "D", "Описание")}
                className="mx-auto mb-10 max-w-4xl text-center text-[17px] leading-8 text-muted-foreground"
              />
            </Reveal>
            <Modules row={s5} prefix="bio" />
            {!isEmpty(optional5) && (
              <Reveal className="mt-12 text-center">
                <p className="mb-4 text-2xl font-medium uppercase text-[#17335b]">Избираем модул</p>
                <p className="text-[17px] leading-8 text-muted-foreground">{optional5}</p>
              </Reveal>
            )}
          </div>
        </section>

        {title6[0] && (
          <section className="bg-[#73147f] px-5 py-10 text-center">
            <h2 className="font-display text-[clamp(27px,3.5vw,45px)] font-bold leading-tight text-white">
              <span className="block">{title6[0]}</span>
              {title6[1] && <span className="block">{title6[1]}</span>}
            </h2>
          </section>
        )}

        {(!isEmpty(getValue(s6, "D", "Описание")) || image6) && (
          <section className="px-5 py-16">
            <div className="mx-auto grid w-[min(1500px,92%)] items-center gap-10 lg:grid-cols-2">
              {image6 && (
                <Reveal>
                  <img
                    src={image6}
                    alt={title6.join(" ")}
                    loading="lazy"
                    className="w-full rounded-2xl object-cover shadow-[var(--shadow-soft)]"
                  />
                </Reveal>
              )}
              <Reveal delay={150}>
                <RichText
                  value={getValue(s6, "D", "Описание")}
                  className="text-[17px] leading-8 text-muted-foreground"
                />
              </Reveal>
            </div>
          </section>
        )}

        <section className="bg-secondary/50 px-5 py-16">
          <div className="mx-auto w-[min(1500px,92%)]">
            {!isEmpty(getValue(s7, "C", "Заглавие")) && (
              <Reveal>
                <h2 className="mb-4 text-center font-display text-3xl font-bold leading-tight text-primary">
                  {getValue(s7, "C", "Заглавие")
                    .split("||")
                    .map((part) => (
                      <span key={part} className="block">
                        {part.trim()}
                      </span>
                    ))}
                </h2>
              </Reveal>
            )}
            <Reveal>
              <RichText
                value={getValue(s7, "D", "Описание")}
                className="mx-auto mb-10 max-w-4xl text-center text-[17px] leading-8 text-muted-foreground"
              />
            </Reveal>
            <Modules row={s7} prefix="chem" />
            {!isEmpty(optional7) && (
              <Reveal className="mt-12 text-center">
                <p className="mb-4 text-2xl font-medium uppercase text-[#17335b]">Избираем модул</p>
                <p className="text-[17px] leading-8 text-muted-foreground">{optional7}</p>
              </Reveal>
            )}
          </div>
        </section>

        {(!isEmpty(getValue(s8, "C", "Заглавие")) || !isEmpty(getValue(s8, "D", "Описание"))) && (
          <section className="px-5 py-20">
            <div className="mx-auto w-[min(1500px,92%)]">
              <Reveal>
                <h2 className="font-display text-[clamp(34px,4vw,58px)] font-bold leading-tight text-foreground">
                  {getValue(s8, "C", "Заглавие").replace(/\|\|/g, " ")}
                </h2>
              </Reveal>
              <Reveal delay={120}>
                <RichText
                  value={getValue(s8, "D", "Описание")}
                  className="mt-6 text-[17px] leading-8 text-muted-foreground"
                />
              </Reveal>
            </div>
          </section>
        )}

        <AdmissionGallery page="Прием 8 клас" />
      </main>
      <SiteFooter />
    </div>
  );
}