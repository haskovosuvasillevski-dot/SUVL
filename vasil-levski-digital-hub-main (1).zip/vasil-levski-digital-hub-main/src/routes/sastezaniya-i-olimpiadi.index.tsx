import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Trophy, X, Link2, FileText, CalendarDays, MapPin } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { Reveal, SectionHeading } from "@/components/Reveal";
import {
  fetchOlympiads,
  fetchSchoolCompetitions,
  docUrl,
  type Olympiad,
  type SchoolCompetition,
} from "@/lib/competitions";
const hero = "/assets/sastezaniya-hero.jpg";

const title = "Състезания и олимпиади – СУ „Васил Левски“ Хасково";
const description =
  "Олимпиади, национални и училищни състезания в СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/sastezaniya-i-olimpiadi/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CompetitionsPage,
});

function CompetitionsPage() {
  const [olympiads, setOlympiads] = useState<Olympiad[] | null>(null);
  const [school, setSchool] = useState<SchoolCompetition[] | null>(null);
  const [active, setActive] = useState<Olympiad | null>(null);

  useEffect(() => {
    let alive = true;
    fetchOlympiads()
      .then((d) => alive && setOlympiads(d))
      .catch(() => alive && setOlympiads([]));
    fetchSchoolCompetitions()
      .then((d) => alive && setSchool(d))
      .catch(() => alive && setSchool([]));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (!active) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setActive(null);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [active]);

  return (
    <PageShell
      title="Състезания и олимпиади"
      image={hero}
      icon={<Trophy className="h-7 w-7" />}
    >
      <section className="bg-background py-14">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <SectionHeading
            title="Олимпиади и национални състезания"
            subtitle="Разгледайте графиците и информацията за предстоящите олимпиади."
            icon={<Trophy className="h-6 w-6" />}
          />

          {!olympiads && (
            <p className="text-center text-muted-foreground">Зареждане...</p>
          )}

          <div className="grid grid-cols-3 gap-4 sm:grid-cols-4 lg:grid-cols-6">
            {olympiads?.map((item, i) => (
              <Reveal key={item.id} delay={i * 60}>
                <button
                  type="button"
                  onClick={() => setActive(item)}
                  className="group relative block w-full overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-soft)] transition-all duration-500 hover:-translate-y-1 hover:border-brand-green/50"
                >
                  <div className="aspect-square w-full overflow-hidden bg-muted">
                    <img
                      src={item.image}
                      alt={item.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  <span className="absolute inset-x-0 bottom-0 translate-y-full bg-primary/90 px-3 py-3 text-sm font-semibold text-primary-foreground transition-transform duration-500 group-hover:translate-y-0 group-focus-visible:translate-y-0">
                    {item.title}
                  </span>
                </button>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-secondary/40 py-14">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <SectionHeading
            title="Училищни състезания"
            subtitle="Постижения и събития от състезанията в нашето училище."
            icon={<Trophy className="h-6 w-6" />}
          />

          {!school && <p className="text-center text-muted-foreground">Зареждане...</p>}

          <div className="grid grid-cols-1 gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {school?.map((item, i) => (
              <Reveal key={item.id} delay={i * 60}>
                <Link
                  to="/sastezaniya-i-olimpiadi/$id"
                  params={{ id: String(item.id) }}
                  className="group block h-full overflow-hidden rounded-xl border border-border bg-card shadow-[var(--shadow-soft)] transition-all duration-500 hover:-translate-y-1"
                >
                  <div className="h-56 overflow-hidden bg-muted">
                    <img
                      src={item.image}
                      alt={item.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                  </div>
                  <div className="p-5">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      {item.rawDate}
                    </p>
                    <h3 className="mt-2 font-display text-lg font-bold leading-snug text-primary transition-colors duration-500 group-hover:text-brand-green">
                      {item.title}
                    </h3>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {active && (
        <div
          className="fixed inset-0 z-[9999] flex items-start justify-center overflow-y-auto bg-black/70 p-4 py-10"
          onClick={() => setActive(null)}
        >
          <div
            className="relative w-full max-w-2xl rounded-2xl bg-card p-6 shadow-xl sm:p-8"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              aria-label="Затвори"
              onClick={() => setActive(null)}
              className="absolute right-4 top-4 rounded-md p-1 text-muted-foreground hover:text-primary"
            >
              <X className="h-6 w-6" />
            </button>

            <h3 className="pr-10 font-display text-2xl font-bold text-primary">
              {active.title}
            </h3>

            <div className="mt-4 space-y-2 text-sm text-muted-foreground">
              {active.rawDate && (
                <p className="flex items-center gap-2">
                  <CalendarDays className="h-4 w-4 text-brand-green" />
                  <span>Дата на провеждане: {active.rawDate}</span>
                </p>
              )}
              {active.place && (
                <p className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-brand-green" />
                  <span>Място на провеждане: {active.place}</span>
                </p>
              )}
            </div>

            {active.content && (
              <p className="mt-5 whitespace-pre-line text-base leading-relaxed text-foreground">
                {active.content}
              </p>
            )}

            {(active.link || active.doc) && (
              <div className="mt-6 flex items-center gap-3">
                {active.link && (
                  <a
                    href={active.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Отвори връзката"
                    title="Отвори връзката"
                    className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground transition-transform hover:scale-105"
                  >
                    <Link2 className="h-5 w-5" />
                  </a>
                )}
                {active.doc && (
                  <a
                    href={docUrl(active.doc)}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Отвори документа"
                    title="Отвори документа"
                    className="flex h-12 w-12 items-center justify-center rounded-full bg-accent text-accent-foreground transition-transform hover:scale-105"
                  >
                    <FileText className="h-5 w-5" />
                  </a>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </PageShell>
  );
}
