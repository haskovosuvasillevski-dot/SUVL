import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { AdmissionProgress } from "@/components/AdmissionProgress";
import { AdmissionGallery } from "@/components/AdmissionGallery";
import { AutoIframe } from "@/components/AutoIframe";
const humanitarni = "/assets/humanitarni.gif";
const prirodni = "/assets/prirodni.gif";

const title = "Прием в VIII клас – СУ „Васил Левски“ Хасково";
const description =
  "Профилиращи предмети при приема в VIII клас в СУ „Васил Левски“ – град Хасково: хуманитарни и природни науки.";

export const Route = createFileRoute("/priem-8-klas")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Priem8Page,
});

const CARDS = [
  {
    gif: humanitarni,
    name: "Хуманитарни науки",
    text: "За обичащите литературата и историята, езика и фактологията, философските заключения и културните различия.",
    button: "bg-[#1abc9c]",
    to: "/priem-8-klas-pr" as const,
  },
  {
    gif: prirodni,
    name: "Природни науки",
    text: "За обичащите химия и биология, за смелите бъдещи медици и научни изследователи, за инженерните умове и екоактивистите.",
    button: "bg-[#3b1443]",
    to: "/priem-8-klas-pr-2" as const,
  },
];

function Priem8Page() {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <AdmissionProgress id={3} />

        <section className="bg-[#f9f9f9] px-5 py-12">
          <h2 className="mb-10 text-center font-display text-3xl font-bold text-primary">
            Варианти на профилиращи предмети
          </h2>
          <div className="mx-auto flex max-w-4xl flex-wrap justify-center gap-6">
            {CARDS.map((card, i) => (
              <Reveal key={card.name} delay={i * 150} className="w-full max-w-[420px] sm:w-[340px]">
                <article className="group flex h-full flex-col items-center rounded border border-[#eaeaea] bg-white px-6 py-10 text-center shadow-[0_4px_15px_rgba(0,0,0,0.05)] transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_10px_25px_rgba(0,0,0,0.15)]">
                  <div className="mb-6 flex h-[90px] w-full items-center justify-center">
                    <img
                      src={card.gif}
                      alt={card.name}
                      loading="lazy"
                      className="h-full w-auto object-contain grayscale transition duration-500 group-hover:grayscale-0"
                    />
                  </div>
                  <h3 className="mb-5 text-xl font-bold uppercase leading-snug text-[#4a154b]">
                    {card.name}
                  </h3>
                  <p className="mb-8 flex-1 text-sm leading-relaxed text-[#666]">{card.text}</p>
                  {card.to === "/priem-8-klas-pr" ? (
                    <Link
                      to="/priem-8-klas-pr"
                      search={{ specialnost: card.name }}
                      className={`inline-block w-full rounded px-4 py-3 text-[15px] font-semibold text-white transition hover:opacity-90 ${card.button}`}
                    >
                      Научи повече
                    </Link>
                  ) : (
                    <Link
                      to="/priem-8-klas-pr-2"
                      className={`inline-block w-full rounded px-4 py-3 text-[15px] font-semibold text-white transition hover:opacity-90 ${card.button}`}
                    >
                      Научи повече
                    </Link>
                  )}
                </article>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="bg-white">
          <AutoIframe src="/dopalnenie.html" title="Етапи на обучение" whiteBackground minHeight={400} />
        </section>

        <AdmissionGallery page="Прием 8 клас" />
      </main>
      <SiteFooter />
    </div>
  );
}