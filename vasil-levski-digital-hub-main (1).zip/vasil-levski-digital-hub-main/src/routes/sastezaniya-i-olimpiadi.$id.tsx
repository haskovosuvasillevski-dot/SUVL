import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Lightbox } from "@/components/Lightbox";
import {
  fetchSchoolCompetitions,
  type SchoolCompetition,
} from "@/lib/competitions";

export const Route = createFileRoute("/sastezaniya-i-olimpiadi/$id")({
  head: () => ({
    meta: [
      { title: "Училищно състезание | СУ „Васил Левски“ – Хасково" },
      {
        name: "description",
        content: "Училищни състезания и постижения в СУ „Васил Левски“, Хасково.",
      },
      {
        property: "og:title",
        content: "Училищно състезание | СУ „Васил Левски“ – Хасково",
      },
      {
        property: "og:description",
        content: "Училищни състезания и постижения в СУ „Васил Левски“, Хасково.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CompetitionDetail,
});

function CompetitionDetail() {
  const { id } = Route.useParams();
  const [item, setItem] = useState<SchoolCompetition | null | undefined>(undefined);
  const [lightbox, setLightbox] = useState<number | null>(null);

  useEffect(() => {
    let alive = true;
    fetchSchoolCompetitions()
      .then((items) => {
        if (!alive) return;
        setItem(items.find((c) => c.id === Number(id)) ?? null);
      })
      .catch(() => alive && setItem(null));
    return () => {
      alive = false;
    };
  }, [id]);

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content" className="mx-auto max-w-5xl px-4 py-10 lg:px-8">
        <Link
          to="/sastezaniya-i-olimpiadi"
          className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm text-primary transition-colors duration-500 hover:bg-secondary"
        >
          <ArrowLeft className="h-4 w-4" /> Назад към състезанията
        </Link>

        {item === undefined && (
          <p className="py-10 text-center text-muted-foreground">Зареждане...</p>
        )}
        {item === null && (
          <p className="py-10 text-center text-destructive">Състезанието не е намерено.</p>
        )}

        {item && (
          <article className="mt-8">
            <h1 className="text-center font-display text-3xl font-bold text-primary sm:text-4xl">
              {item.title}
            </h1>
            <div className="mt-4 text-center">
              <span className="inline-block rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground">
                {item.rawDate}
              </span>
            </div>

            {item.image && (
              <img
              loading="lazy"
              decoding="async"
                src={item.image}
                alt={item.title}
                className="mx-auto mt-8 w-full rounded-xl shadow-[var(--shadow-soft)]"
              />
            )}

            <div className="mx-auto mt-10 max-w-3xl">
              <div className="whitespace-pre-line text-[1.05rem] leading-8 text-muted-foreground">
                {item.content}
              </div>
              {item.author && (
                <p className="mt-8 border-b border-border pb-6 italic text-muted-foreground">
                  Автор: {item.author}
                </p>
              )}
            </div>

            {item.gallery.length > 0 && (
              <div className="mt-10">
                <h2 className="mb-4 font-display text-2xl font-bold text-primary">
                  Галерия
                </h2>
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                  {item.gallery.map((src, i) => (
                    <button
                      key={src}
                      type="button"
                      onClick={() => setLightbox(i)}
                      className="overflow-hidden rounded-xl bg-muted"
                    >
                      <img
                        src={src}
                        alt={`${item.title} – снимка ${i + 1}`}
                        loading="lazy"
                        className="h-44 w-full object-cover transition-transform duration-700 hover:scale-105"
                      />
                    </button>
                  ))}
                </div>
                {lightbox !== null && (
                  <Lightbox
                    images={item.gallery}
                    index={lightbox}
                    onClose={() => setLightbox(null)}
                    onChange={setLightbox}
                  />
                )}
              </div>
            )}
          </article>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
