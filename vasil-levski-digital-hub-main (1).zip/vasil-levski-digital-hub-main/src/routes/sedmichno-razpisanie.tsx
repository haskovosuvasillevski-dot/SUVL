import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

const title = "Седмично разписание – СУ „Васил Левски“ Хасково";
const description =
  "Седмично разписание на часовете по класове в СУ „Васил Левски“ – Хасково с изгледи Мрежа, Фокус + контекст и Дни като колони.";

export const Route = createFileRoute("/sedmichno-razpisanie")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SchedulePage,
});

function SchedulePage() {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <iframe
          src="/sedmichno-razpisanie.html"
          title="Седмично разписание"
          className="h-[calc(100vh-5.5rem)] w-full border-0"
        />
      </main>
      <SiteFooter />
    </div>
  );
}