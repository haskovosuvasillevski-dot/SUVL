import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";

const title = "Полезни връзки – СУ „Васил Левски“ Хасково";
const description =
  "Полезни връзки към институции, издателства, образователни платформи и учебни материали от България и чужбина.";

export const Route = createFileRoute("/elektronni-resursi")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ElektronniResursiPage,
});

type LinkItem = {
  name: string;
  href: string;
  label: string;
  description: string;
};

const SECTIONS: { title: string; links: LinkItem[] }[] = [
  {
    title: "Институции",
    links: [
      {
        name: "Министерство на образованието и науката",
        href: "http://mon.bg",
        label: "http://mon.bg",
        description: "Официален сайт на Министерството на образованието и науката.",
      },
      {
        name: "Регионално управление на образованието – Хасково",
        href: "http://www.ruobg.com",
        label: "http://www.ruobg.com",
        description:
          "Информация и ресурси от Регионалното управление на образованието – Хасково.",
      },
      {
        name: "Регионален център за подкрепа на процеса на приобщаващото образование – Хасково",
        href: "https://rchaskovo.com/",
        label: "https://rchaskovo.com/",
        description:
          "Ресурси и информация за подкрепа на приобщаващото образование в област Хасково.",
      },
      {
        name: "Приобщи се",
        href: "https://priobshti.se/",
        label: "https://priobshti.se/",
        description: "Материали и ресурси, свързани с приобщаващото образование.",
      },
    ],
  },
  {
    title: "Издателства и образователни платформи",
    links: [
      {
        name: "Електронен дневник – Shkolo",
        href: "https://www.shkolo.bg/",
        label: "https://www.shkolo.bg/",
        description: "Електронен дневник и платформа за управление на учебния процес.",
      },
      {
        name: "e-prosveta",
        href: "https://www.e-prosveta.bg/",
        label: "https://www.e-prosveta.bg/",
        description: "Дигитални учебници и образователни ресурси.",
      },
      {
        name: "IZZI",
        href: "https://bg.izzi.digital/#/",
        label: "https://bg.izzi.digital/",
        description: "Дигитална образователна платформа с учебно съдържание.",
      },
    ],
  },
  {
    title: "Български учебни материали и сайтове",
    links: [
      {
        name: "Уча.се",
        href: "https://ucha.se/",
        label: "https://ucha.se/",
        description: "Бързо. Лесно. Интересно.",
      },
      {
        name: "Дечица",
        href: "http://www.dechica.com",
        label: "http://www.dechica.com",
        description:
          "Образователни и забавни материали за децата от предучилищна и начална училищна възраст.",
      },
      {
        name: "Math10",
        href: "http://www.math10.com/bg/",
        label: "http://www.math10.com/bg/",
        description: "Задачи и тестове по математика.",
      },
      {
        name: "Матури",
        href: "https://maturite.bg/",
        label: "https://maturite.bg/",
        description: "Ресурси за подготовка за матури.",
      },
      {
        name: "За матура",
        href: "https://zamatura.eu/",
        label: "https://zamatura.eu/",
        description: "Учебни материали и ресурси за подготовка за матури.",
      },
      {
        name: "Дигитална раница",
        href: "https://edu.mon.bg/",
        label: "https://edu.mon.bg/",
        description: "Дигитална образователна среда и ресурси.",
      },
    ],
  },
  {
    title: "Учебни материали и сайтове от чужбина",
    links: [
      {
        name: "Canva",
        href: "https://www.canva.com/",
        label: "https://www.canva.com/",
        description:
          "Инструмент за създаване на презентации, учебни материали, плакати и графики.",
      },
      {
        name: "Kahoot!",
        href: "https://kahoot.com/",
        label: "https://kahoot.com/",
        description: "Интерактивни викторини и занимания за обучение.",
      },
      {
        name: "Scratch",
        href: "https://scratch.mit.edu/",
        label: "https://scratch.mit.edu/",
        description: "Визуално програмиране и творчески проекти за деца и ученици.",
      },
      {
        name: "Zigazoo Kids",
        href: "https://www.zigazoo.com/",
        label: "https://www.zigazoo.com/",
        description: "Образователна платформа с творчески и интерактивни занимания за деца.",
      },
      {
        name: "Khan Academy",
        href: "https://bg.khanacademy.org/",
        label: "https://bg.khanacademy.org/",
        description: "Безплатни видео уроци, упражнения и учебни материали.",
      },
      {
        name: "Google for Education / Google Classroom",
        href: "https://classroom.google.com",
        label: "https://classroom.google.com",
        description: "Инструменти за организация и провеждане на учебния процес.",
      },
      {
        name: "Microsoft 365 Education / Teams",
        href: "https://www.microsoft.com/education",
        label: "https://www.microsoft.com/education",
        description:
          "Образователни инструменти и среда за онлайн обучение и сътрудничество.",
      },
      {
        name: "National Geographic Education",
        href: "https://education.nationalgeographic.org",
        label: "https://education.nationalgeographic.org",
        description: "Образователни материали и ресурси по география, наука и околен свят.",
      },
      {
        name: "Code.org",
        href: "https://code.org",
        label: "https://code.org",
        description: "Уроци и занимания за изучаване на програмиране и компютърни науки.",
      },
    ],
  },
];

function ElektronniResursiPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#eef5ff] to-[#f8fbff] font-body">
      <SiteHeader />
      <main id="main-content">
        <div className="mx-auto w-[92%] max-w-4xl py-12 sm:py-16">
          <Reveal>
            <h1 className="mb-10 text-center font-display text-4xl font-bold text-[#17365d] sm:text-6xl">
              Полезни връзки
            </h1>
          </Reveal>

          {SECTIONS.map((section, sIdx) => (
            <section key={section.title} className="my-9">
              <Reveal delay={sIdx * 100}>
                <h2 className="mb-6 text-center text-2xl font-bold text-[#24527a]">
                  {section.title}
                </h2>
              </Reveal>
              <div className="space-y-4">
                {section.links.map((link, lIdx) => (
                  <Reveal key={link.name} delay={sIdx * 100 + lIdx * 60}>
                    <div className="rounded-2xl bg-white px-6 py-6 text-center shadow-[0_4px_14px_rgba(0,0,0,0.08)]">
                      <h3 className="mb-2 text-xl font-bold text-[#222]">{link.name}</h3>
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mb-2 inline-block break-words text-lg font-bold text-[#0066cc] hover:underline"
                      >
                        {link.label}
                      </a>
                      <p className="m-0 text-base leading-relaxed text-[#555]">
                        {link.description}
                      </p>
                    </div>
                  </Reveal>
                ))}
              </div>
            </section>
          ))}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
