import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ChevronRight, BookMarked } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import {
  fetchTextbooks,
  matches,
  normalizeLink,
  type TextbookItem,
} from "@/lib/textbooks";
const hero = "/assets/uchebnici-hero.jpg";

const title = "Учебници – СУ „Васил Левски“ Хасково";
const description =
  "Учебници и допълнителни учебни материали, както и препоръчителна литература по класове в СУ „Васил Левски“ – Хасково.";

export const Route = createFileRoute("/uchebnitsi")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: TextbooksPage,
});

const CLASSES = Array.from({ length: 12 }, (_, i) => `${i + 1}. клас`);

function Accordion({
  items,
  category,
}: {
  items: TextbookItem[];
  category: string;
}) {
  const [open, setOpen] = useState<string | null>(null);

  return (
    <div className="space-y-3">
      {CLASSES.map((cls) => {
        const rows = items.filter((i) => matches(i, cls, category));
        const subjects = Array.from(new Set(rows.map((r) => r.subject)));
        const isOpen = open === cls;
        return (
          <div key={cls} className="rounded-lg border border-border bg-card">
            <button
              type="button"
              onClick={() => setOpen(isOpen ? null : cls)}
              className="flex w-full items-center gap-3 px-5 py-4 text-left font-display text-lg font-bold text-primary"
            >
              <ChevronRight
                className={`h-5 w-5 shrink-0 transition-transform duration-300 ${
                  isOpen ? "rotate-90" : ""
                }`}
              />
              {cls}
            </button>
            {isOpen && (
              <div className="border-l-4 border-accent px-5 pb-5 pt-1">
                {rows.length === 0 ? (
                  <p className="italic text-muted-foreground">
                    Скоро ще бъдат добавени материали.
                  </p>
                ) : (
                  subjects.map((subj) => (
                    <div key={subj} className="mb-5 last:mb-0">
                      <h3 className="mb-2 text-base font-bold uppercase text-primary">
                        {subj}:
                      </h3>
                      <ol className="list-decimal space-y-2 pl-5 text-foreground">
                        {rows
                          .filter((r) => r.subject === subj)
                          .sort((a, b) => a.number - b.number)
                          .map((r, i) => {
                            const url = normalizeLink(r.link);
                            return (
                              <li key={`${subj}-${i}`} className="leading-relaxed">
                                {url ? (
                                  <a
                                    href={url}
                                    target="_blank"
                                    rel="noopener"
                                    className="hover:underline"
                                  >
                                    {r.title}
                                  </a>
                                ) : (
                                  r.title
                                )}
                              </li>
                            );
                          })}
                      </ol>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function TextbooksPage() {
  const [items, setItems] = useState<TextbookItem[] | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    fetchTextbooks()
      .then((data) => active && setItems(data))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, []);

  const data = useMemo(() => items ?? [], [items]);

  /* Категориите се изграждат динамично от базата данни —
     нова категория се появява автоматично, а празна такава не се показва. */
  const categories = useMemo(() => {
    const seen = new Map<string, string>();
    for (const item of data) {
      if (!item.category) continue;
      const key = item.category.toLowerCase();
      if (!seen.has(key)) seen.set(key, item.category);
    }
    return Array.from(seen.values()).filter((cat) =>
      data.some((i) =>
        CLASSES.some((cls) => matches(i, cls, cat)),
      ),
    );
  }, [data]);

  return (
    <PageShell title="Учебници" image={hero} icon={<BookMarked className="h-7 w-7" />}>
      <section className="bg-secondary/40 py-12">
        <div className="mx-auto max-w-4xl px-4 lg:px-8">
          {error && (
            <p className="text-center text-destructive">
              Грешка при връзката с базата данни.
            </p>
          )}
          {!error && !items && (
            <p className="text-center text-muted-foreground">Зареждане на данни...</p>
          )}

          {categories.map((category, i) => (
            <div key={category}>
              <h2
                className={`mb-6 font-display text-2xl font-bold text-primary sm:text-3xl ${
                  i > 0 ? "mt-12 border-b-2 border-border pb-2" : ""
                }`}
              >
                {category}
              </h2>
              <Accordion items={data} category={category} />
            </div>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
