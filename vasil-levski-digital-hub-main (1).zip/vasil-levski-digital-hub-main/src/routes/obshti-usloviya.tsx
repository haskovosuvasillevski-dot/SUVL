import { createFileRoute } from "@tanstack/react-router";
import { ScrollText } from "lucide-react";
import { PageShell } from "@/components/PageShell";
const hero = "/assets/news-banner.jpg";

const title = "Общи условия – СУ „Васил Левски“ Хасково";
const description =
  "Общи условия за ползване на официалния сайт на СУ „Васил Левски“, град Хасково.";

export const Route = createFileRoute("/obshti-usloviya")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TermsPage,
});

function Section({ heading, children }: { heading: string; children: React.ReactNode }) {
  return (
    <section className="space-y-3">
      <h2 className="font-display text-xl font-bold text-primary sm:text-2xl">{heading}</h2>
      <div className="space-y-3 text-[15px] leading-relaxed text-foreground/90">{children}</div>
    </section>
  );
}

function TermsPage() {
  return (
    <PageShell
      title="Общи условия"
      image={hero}
      icon={<ScrollText className="h-7 w-7" />}
    >
      <div className="mx-auto max-w-4xl space-y-8 px-4 py-12 lg:px-8 lg:py-16">
        <p className="text-[15px] leading-relaxed text-muted-foreground">
          Настоящите общи условия уреждат ползването на официалния сайт на СУ „Васил Левски“
          – град Хасково. С достъпа до сайта потребителят приема тези условия.
        </p>

        <Section heading="1. Доставчик на информационното общество">
          <p>
            СУ „Васил Левски“, ул. „Стара планина“ № 2, гр. Хасково, тел. 038 / 66 43 16,
            е-поща info-2601025@edu.mon.bg. Сайтът има информационен характер и се поддържа
            в изпълнение на изискванията за публичност на институциите в системата на
            предучилищното и училищното образование.
          </p>
        </Section>

        <Section heading="2. Съдържание и авторски права">
          <p>
            Всички текстове, изображения, документи и други материали са собственост на
            училището или се използват с разрешение на правоносителите и са защитени от
            Закона за авторското право и сродните му права. Разрешава се използване с
            нетърговска, образователна или информационна цел при изрично посочване на
            източника.
          </p>
        </Section>

        <Section heading="3. Задължения на потребителите">
          <ul className="list-disc space-y-2 pl-5">
            <li>да не нарушават работата и сигурността на сайта;</li>
            <li>да не публикуват и изпращат съдържание, което е противозаконно, обидно,
              дискриминационно или накърнява права на трети лица;</li>
            <li>да не използват данни от сайта за нежелани търговски съобщения.</li>
          </ul>
        </Section>

        <Section heading="4. Ограничаване на отговорността">
          <p>
            Училището полага грижи информацията да бъде вярна и актуална, но не носи
            отговорност за евентуални неточности, както и за съдържанието на външни сайтове,
            към които има препратки (Google, YouTube, Cloudinary, институционални портали и др.).
          </p>
        </Section>

        <Section heading="5. Лични данни и бисквитки">
          <p>
            Обработването на лични данни е описано в Политиката за поверителност, а
            използваните бисквитки – в Политиката за бисквитки, които са неразделна част от
            настоящите общи условия.
          </p>
        </Section>

        <Section heading="6. Изменения">
          <p>
            Училището си запазва правото да променя тези общи условия. Актуалната версия е
            винаги публикувана на тази страница.
          </p>
        </Section>
      </div>
    </PageShell>
  );
}
