import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { HeroCarousel } from "@/components/HeroCarousel";
import { CountUpSection } from "@/components/CountUpSection";
import { QuoteSection } from "@/components/QuoteSection";
import { AdmissionSection } from "@/components/AdmissionSection";
import { NewsAndAnnouncements } from "@/components/NewsAndAnnouncements";
import { UsefulInfoSection } from "@/components/UsefulInfoSection";
import { RiverSection } from "@/components/RiverSection";
import { SiteFooter } from "@/components/SiteFooter";


const title = "СУ „Васил Левски“ – Хасково | Официален сайт";
const description =
  "Официален сайт на СУ „Васил Левски“, град Хасково – новини, прием, документи, галерия и контакти.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <HeroCarousel />
        <CountUpSection />
        <QuoteSection />
        <RiverSection />
        <NewsAndAnnouncements />
        <AdmissionSection />
        <UsefulInfoSection />

      </main>
      <SiteFooter />
    </div>
  );
}
