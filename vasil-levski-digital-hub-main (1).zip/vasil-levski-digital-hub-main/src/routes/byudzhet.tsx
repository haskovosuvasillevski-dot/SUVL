import { createFileRoute } from "@tanstack/react-router";
import { PiggyBank } from "lucide-react";
import { DocumentsPage } from "@/components/DocumentsPage";
const hero = "/assets/byudzhet.jpg";

const title = "Бюджет – СУ „Васил Левски“ Хасково";
const description =
  "Бюджет и касови отчети на СУ „Васил Левски“ – град Хасково, подредени по години.";

export const Route = createFileRoute("/byudzhet")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <DocumentsPage
      heading="Бюджет"
      heroUrl={hero}
      icon={PiggyBank}
      sheetId="1rC4a28U3PHAVbitZkSN5UCYgRDOr8nJ4ZzNBeFVLZOE"
      groupYears
    />
  ),
});
