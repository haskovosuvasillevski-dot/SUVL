import { useEffect, useState } from "react";
import { Scale } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { fetchRights, type RightsData } from "@/lib/rights";
const hero = "/assets/prava-hero.jpg";

const title = "Права и задължения – СУ „Васил Левски“ Хасково";
const description =
  "Права и задължения на учениците и родителите в СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/prava-i-zadalzheniya")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: RightsPage,
});

function RightsPage() {
  const [data, setData] = useState<RightsData | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    const load = () =>
      fetchRights()
        .then((d) => active && setData(d))
        .catch(() => active && setError(true));
    void load();
    const id = setInterval(load, 60 * 1000);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, []);

  return (
    <PageShell title="Права и задължения" image={hero} icon={<Scale className="h-7 w-7" />}>
      <section className="bg-secondary/40 py-12">
        <div className="mx-auto max-w-4xl px-4 lg:px-8">
          <h2 className="text-center font-display text-2xl font-bold text-primary sm:text-3xl">
            {error
              ? "Грешка при зареждане на базата данни"
              : data?.schoolName || "Зареждане на базата данни..."}
          </h2>
          <div className="mx-auto my-4 h-[3px] w-24 rounded-full bg-accent" />
          {data?.academicYear && (
            <p className="text-center text-muted-foreground">
              за учебната {data.academicYear} година
            </p>
          )}

          <article className="mt-10 rounded-lg border border-border bg-card p-6 sm:p-8">
            <h3 className="mb-4 font-display text-xl font-bold text-primary sm:text-2xl">
              Права и задължения на учениците
            </h3>
            <p className="whitespace-pre-line leading-relaxed text-foreground">
              {data?.studentRights || (error ? "" : "Зареждане на съдържанието...")}
            </p>
          </article>

          <article className="mt-8 rounded-lg border border-border bg-card p-6 sm:p-8">
            <h3 className="mb-4 font-display text-xl font-bold text-primary sm:text-2xl">
              Права и задължения на родителите
            </h3>
            <p className="whitespace-pre-line leading-relaxed text-foreground">
              {data?.parentRights || (error ? "" : "Зареждане на съдържанието...")}
            </p>
          </article>
        </div>
      </section>
    </PageShell>
  );
}
