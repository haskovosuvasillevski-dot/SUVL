import { createFileRoute } from "@tanstack/react-router";
import { Award } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { Reveal } from "@/components/Reveal";
import { ContentSections } from "@/components/ContentSections";
import { PATRON_SHEET_ID } from "@/lib/history";
const hero = "/assets/patrona-bust.png";
const portret = "/assets/levski-portret.jpg";

const title = "Патронът – Васил Иванов Кунчев | СУ „Васил Левски“ Хасково";
const description =
  "Васил Иванов Кунчев – Левски (1837–1873), патрон на СУ „Васил Левски“, град Хасково: живот, дело и памет.";

const NICKNAMES = [
  "Дяконът,",
  "Апостолът,",
  "Главният книжар,",
  "Тропчо,",
  "Ефенди Аслан Дервишооглу,",
  "В. Лъвский,",
  "Аслан Дервишооглу Кърджалъ,",
  "Драгойчо,",
  "Дякон Игнатий",
];

export const Route = createFileRoute("/patrona")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PatronPage,
});

function PatronPage() {
  return (
    <PageShell title="Патрона" image={hero} imagePosition="center 30%" icon={<Award className="h-7 w-7" />}>
      <div className="mx-auto max-w-5xl px-4 py-12 lg:px-8 lg:py-16">
        <Reveal>
          <section className="mb-14 grid grid-cols-1 items-center gap-8 lg:grid-cols-2">
            <div>
              <h2 className="font-display text-2xl font-bold uppercase tracking-wide text-primary sm:text-3xl">
                Васил Иванов Кунчев
              </h2>
              <div className="mt-3 mb-6 h-[3px] w-24 rounded-full bg-gold" />
              <img
              loading="lazy"
              decoding="async"
                src={portret}
                alt="Портрет на Васил Левски"
                className="w-full rounded-xl border border-border/60 object-cover"
              />
            </div>
            <div className="space-y-3 text-center text-base text-foreground/90 sm:text-lg">
              <p className="font-semibold">(18.07.1837 – 19.02.1873 г.)</p>
              {NICKNAMES.map((n) => (
                <p key={n}>{n}</p>
              ))}
            </div>
          </section>
        </Reveal>

        <ContentSections sheetId={PATRON_SHEET_ID} />
      </div>
    </PageShell>
  );
}
