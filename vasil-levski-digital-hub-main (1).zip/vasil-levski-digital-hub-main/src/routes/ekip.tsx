import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { AutoIframe } from "@/components/AutoIframe";

const title = "Екип – СУ „Васил Левски“ Хасково";
const description =
  "Ръководство, учители и служители на СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/ekip")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TeamPage,
});

function TeamPage() {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <AutoIframe src="/ekip.html" title="Екип" minHeight={800} />
      </main>
      <SiteFooter />
    </div>
  );
}
