import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { AutoIframe } from "@/components/AutoIframe";

const title = "Алманах и летопис – СУ „Васил Левски“ Хасково";
const description =
  "Алманах и летопис на СУ „Васил Левски“ – град Хасково: история, випуски и значими моменти през годините.";

export const Route = createFileRoute("/almanah-i-letopis")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AlmanahPage,
});

function AlmanahPage() {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <AutoIframe
          src="/almanah-i-letopis.html"
          title="Алманах и летопис"
          minHeight={700}
        />
      </main>
      <SiteFooter />
    </div>
  );
}