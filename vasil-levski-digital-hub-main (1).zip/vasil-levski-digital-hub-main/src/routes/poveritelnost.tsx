import { createFileRoute } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";
import { PageShell } from "@/components/PageShell";
const hero = "/assets/news-banner.jpg";

const title = "Политика за поверителност – СУ „Васил Левски“ Хасково";
const description =
  "Политика за поверителност и защита на личните данни на СУ „Васил Левски“, град Хасково – съгласно GDPR и ЗЗЛД.";

export const Route = createFileRoute("/poveritelnost")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PrivacyPage,
});

function Section({ heading, children }: { heading: string; children: React.ReactNode }) {
  return (
    <section className="space-y-3">
      <h2 className="font-display text-xl font-bold text-primary sm:text-2xl">{heading}</h2>
      <div className="space-y-3 text-[15px] leading-relaxed text-foreground/90">{children}</div>
    </section>
  );
}

function PrivacyPage() {
  return (
    <PageShell
      title="Поверителност"
      image={hero}
      icon={<ShieldCheck className="h-7 w-7" />}
    >
      <div className="mx-auto max-w-4xl space-y-8 px-4 py-12 lg:px-8 lg:py-16">
        <p className="text-[15px] leading-relaxed text-muted-foreground">
          СУ „Васил Левски“ – град Хасково обработва лични данни в съответствие с Регламент
          (ЕС) 2016/679 (GDPR), Закона за защита на личните данни, Закона за предучилищното
          и училищното образование и указанията на Министерството на образованието и науката.
        </p>

        <Section heading="1. Администратор на лични данни">
          <p>
            СУ „Васил Левски“, ул. „Стара планина“ № 2, гр. Хасково; тел. 038 / 66 43 16;
            е-поща{" "}
            <a className="font-semibold text-primary underline" href="mailto:info-2601025@edu.mon.bg">
              info-2601025@edu.mon.bg
            </a>
            . Училището има определено длъжностно лице по защита на данните, с което можете
            да се свържете на същия адрес.
          </p>
        </Section>

        <Section heading="2. Какви данни обработваме и на какво основание">
          <ul className="list-disc space-y-2 pl-5">
            <li>
              данни на ученици и родители (имена, ЕГН, адрес, контакти, оценки, отсъствия) –
              за изпълнение на законово задължение по ЗПУО и подзаконовите актове;
            </li>
            <li>
              данни на служители и кандидати за работа – за изпълнение на трудови и
              осигурителни задължения;
            </li>
            <li>
              данни, изпратени доброволно чрез формата за контакт или по е-поща – на
              основание Ваше съгласие/легитимен интерес за отговор на запитването;
            </li>
            <li>
              снимки и видео от училищни събития – само при получено изрично съгласие.
            </li>
          </ul>
        </Section>

        <Section heading="3. Срок на съхранение">
          <p>
            Данните се съхраняват за сроковете, определени в Закона за Националния архивен
            фонд, Наредба № 8/2016 г. за информацията и документите в системата на
            предучилищното и училищното образование и другите приложими нормативни актове.
          </p>
        </Section>

        <Section heading="4. Получатели на данните">
          <p>
            Лични данни могат да бъдат предоставяни само на компетентни държавни органи
            (МОН, РУО – Хасково, НАП, НОИ и др.) и на обработващи данни, с които училището
            има сключен договор, при спазване на изискванията за сигурност. Не се извършва
            предаване на данни към трети държави извън ЕС.
          </p>
        </Section>

        <Section heading="5. Вашите права">
          <ul className="list-disc space-y-2 pl-5">
            <li>достъп до данните и получаване на копие;</li>
            <li>коригиране на неточни данни;</li>
            <li>изтриване („право да бъдеш забравен“) при наличие на основание;</li>
            <li>ограничаване на обработването и възражение срещу него;</li>
            <li>преносимост на данните;</li>
            <li>оттегляне на съгласието по всяко време;</li>
            <li>
              жалба до Комисията за защита на личните данни – гр. София, бул. „Проф. Цветан
              Лазаров“ № 2, kzld.bg.
            </li>
          </ul>
        </Section>

        <Section heading="6. Сигурност">
          <p>
            Училището прилага подходящи технически и организационни мерки за защита на
            данните срещу неоторизиран достъп, загуба или разкриване.
          </p>
        </Section>
      </div>
    </PageShell>
  );
}
