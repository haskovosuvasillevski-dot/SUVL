import { createFileRoute } from "@tanstack/react-router";
import { Laptop } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { AutoIframe } from "@/components/AutoIframe";
const banner = "/assets/onlain-obuchenie.jpg";

const title = "Онлайн обучение – СУ „Васил Левски“ Хасково";
const description =
  "Информация, ресурси и документи за онлайн обучението в СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/onlain-obuchenie")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <PageShell
      title="Онлайн обучение"
      image={banner}
      icon={<Laptop className="h-7 w-7" />}
    >
      <section className="mx-auto max-w-7xl px-2 py-10 lg:px-8">
        <AutoIframe
          src="/onlain-obuchenie.html"
          title="Онлайн обучение"
          whiteBackground
        />
      </section>
    </PageShell>
  ),
});
