import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { FileText, Lightbulb } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { Reveal } from "@/components/Reveal";
import { fetchProjects, type Project } from "@/lib/projects";
const banner = "/assets/proekti-banner.jpg";

const title = "Проекти – СУ „Васил Левски“ Хасково";
const description =
  "Проекти и национални програми, в които участва СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/proekti/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: banner },
      { name: "twitter:image", content: banner },
    ],
  }),
  component: ProjectsPage,
});

function excerpt(text: string, max = 260) {
  const clean = String(text || "").replace(/\s+/g, " ").trim();
  return clean.length > max ? `${clean.slice(0, max)} […]` : clean;
}

function ProjectsPage() {
  const [projects, setProjects] = useState<Project[] | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    fetchProjects()
      .then((items) => active && setProjects(items))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, []);

  const groups = useMemo(() => {
    const map = new Map<number, Project[]>();
    (projects ?? []).forEach((p) => {
      const year = p.date.getFullYear() || 0;
      const list = map.get(year) ?? [];
      list.push(p);
      map.set(year, list);
    });
    return [...map.entries()].sort((a, b) => b[0] - a[0]);
  }, [projects]);

  return (
    <PageShell title="Проекти" image={banner} icon={<Lightbulb className="h-7 w-7" />}>
      <section className="bg-secondary/40 py-12">
        <div className="mx-auto max-w-6xl px-4 lg:px-8">
          {error && (
            <p className="text-center text-destructive">
              Възникна грешка при зареждане на проектите.
            </p>
          )}
          {!error && !projects && (
            <p className="text-center text-muted-foreground">Зареждане на проектите...</p>
          )}
          {projects && projects.length === 0 && (
            <p className="text-center text-muted-foreground">Няма добавени проекти.</p>
          )}

          {groups.map(([year, items]) => (
            <div key={year} className="mb-12">
              {year > 0 && (
                <h2 className="mb-6 font-display text-2xl font-bold text-primary">{year}</h2>
              )}
              <div className="space-y-8">
                {items.map((p, i) => (
                  <Reveal key={p.id} delay={i * 60}>
                    <article className="overflow-hidden rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-soft)] sm:p-7">
                      <div className="grid gap-4 sm:grid-cols-[minmax(0,300px)_1fr] sm:items-stretch">
                        {p.image && (
                          <Link
                            to="/proekti/$id"
                            params={{ id: p.id }}
                            className="block aspect-square overflow-hidden rounded-lg border border-border bg-muted"
                          >
                            <img
                              src={p.image}
                              alt={p.title}
                              loading="lazy"
                              referrerPolicy="no-referrer"
                              className="h-full w-full object-cover transition-transform duration-700 hover:scale-105"
                            />
                          </Link>
                        )}
                        <div className="flex min-w-0 flex-col">
                          <h3 className="font-display text-2xl font-bold leading-snug text-primary">
                            <Link
                              to="/proekti/$id"
                              params={{ id: p.id }}
                              className="no-underline hover:text-brand-green"
                            >
                              {p.title}
                            </Link>
                          </h3>
                          {p.rawDate && (
                            <div className="mt-2 text-sm text-muted-foreground">{p.rawDate}</div>
                          )}
                          <p className="mt-4 line-clamp-[8] leading-7 text-muted-foreground">
                            {excerpt(p.content)}
                          </p>
                          <div className="mt-auto flex justify-end border-t border-border pt-3">
                            <Link
                              to="/proekti/$id"
                              params={{ id: p.id }}
                              className="inline-flex items-center gap-2 font-medium text-primary no-underline hover:text-brand-green"
                            >
                              <FileText className="h-4 w-4" />
                              Прочети повече
                            </Link>
                          </div>
                        </div>
                      </div>
                    </article>
                  </Reveal>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
