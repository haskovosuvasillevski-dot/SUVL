import { useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";

const title = "Контакти – СУ „Васил Левски“ Хасково";
const description = "Контакти на СУ „Васил Левски“ – Хасково: адрес, телефони, e-mail и карта.";

export const Route = createFileRoute("/kontakti")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: KontaktiPage,
});

function Ornament() {
  return (
    <div className="my-8 flex items-center justify-center gap-2.5 text-current" aria-hidden="true">
      <span className="h-px max-w-[28%] flex-1 bg-current opacity-70" />
      <span className="relative h-[23px] w-4 -skew-y-[28deg] rounded-sm border-2 border-current opacity-95" />
      <span className="h-px max-w-[28%] flex-1 bg-current opacity-70" />
    </div>
  );
}

function KontaktiPage() {
  const [status, setStatus] = useState<"idle" | "success">("idle");
  const [submitting, setSubmitting] = useState(false);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setStatus("success");
      form.reset();
    }, 500);
  }

  return (
    <div className="min-h-screen bg-[#f5f6f8] font-body">
      <SiteHeader />
      <main id="main-content">
        <div className="mx-auto grid w-[min(1180px,calc(100%-32px))] grid-cols-1 overflow-hidden bg-white shadow-[0_12px_35px_rgba(30,45,70,0.10)] md:my-10 md:grid-cols-2">
          {/* Лява кутия — информация */}
          <Reveal className="order-1 bg-white px-6 py-10 sm:px-10 md:px-12 md:py-12">
            <section aria-labelledby="contact-title">
              <h1
                id="contact-title"
                className="text-center text-3xl font-normal tracking-tight text-[#17233a] sm:text-4xl"
              >
                Къде да ни намерите
              </h1>

              <Ornament />

              <h2 className="mb-4 text-xl font-semibold text-[#17233a]">
                Средно училище „Васил Левски“ – Хасково
              </h2>

              <p className="mb-2 mt-5 text-base font-bold text-[#17233a]">Адрес:</p>
              <p className="m-0 text-base leading-relaxed text-[#385275]">
                6300 Хасково, България
                <br />
                ул. „Стара планина“ № 2
              </p>

              <a
                className="mt-3 inline-flex items-center gap-2 font-semibold text-[#31558f] hover:underline"
                href="https://www.google.com/maps/search/?api=1&query=СУ%20Васил%20Левски%2C%20Хасково"
                target="_blank"
                rel="noopener noreferrer"
              >
                📍 Покажи в Google Maps
              </a>

              <p className="mb-2 mt-5 text-base font-bold text-[#17233a]">Телефон:</p>
              <p className="m-0 text-base leading-relaxed text-[#385275]">
                Технически секретар / счетоводство:{" "}
                <a href="tel:+35938664316" className="hover:underline">
                  038 / 66 43 16
                </a>
                <br />
                Заместник-директори:{" "}
                <a href="tel:+35938664318" className="hover:underline">
                  038 / 66 43 18
                </a>
                <br />
                Директор:{" "}
                <a href="tel:+35938662993" className="hover:underline">
                  038 / 66 29 93
                </a>
              </p>

              <p className="mb-2 mt-5 text-base font-bold text-[#17233a]">E-mail:</p>
              <p className="m-0 text-base leading-relaxed text-[#385275]">
                <a href="mailto:info-2601025@edu.mon.bg" className="hover:underline">
                  info-2601025@edu.mon.bg
                </a>
              </p>

              <p className="mb-2 mt-5 text-base font-bold text-[#17233a]">GPS координати:</p>
              <p className="m-0 inline-block text-base leading-relaxed text-[#385275]">
                41.936324, 25.5532883
              </p>

              <div className="mt-12">
                <p className="mb-4 text-lg font-semibold text-[#17233a]">Последвайте ни</p>
                <a
                  className="inline-flex h-[62px] w-[62px] items-center justify-center rounded-full bg-[#4267a9] text-3xl font-bold text-white transition hover:-translate-y-0.5 hover:shadow-[0_8px_18px_rgba(66,103,169,0.28)]"
                  href="https://www.facebook.com/soulevski/?locale=bg_BG"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook на СУ „Васил Левски“ – Хасково"
                  title="Facebook"
                >
                  f
                </a>
              </div>
            </section>
          </Reveal>

          {/* Дясна кутия — форма */}
          <Reveal delay={150} className="order-2 bg-[#2d4166] px-6 py-10 text-white sm:px-10 md:px-12 md:py-12">
            <section aria-labelledby="form-title">
              <div className="mx-auto max-w-[620px]">
                <h2
                  id="form-title"
                  className="text-center text-3xl font-normal tracking-tight sm:text-4xl"
                >
                  Свържете се с нас
                </h2>

                <Ornament />

                <form onSubmit={handleSubmit} noValidate>
                  <div className="mb-5">
                    <label htmlFor="name" className="mb-2 block text-sm font-bold">
                      Вашето име<span className="text-white">*</span>
                    </label>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      autoComplete="name"
                      required
                      className="min-h-[52px] w-full border border-transparent bg-[#f7f7f7] px-4 py-4 text-base text-[#17233a] outline-none focus:border-[#8aa5cf] focus:shadow-[0_0_0_3px_rgba(138,165,207,0.18)]"
                    />
                  </div>

                  <div className="mb-5">
                    <label htmlFor="email" className="mb-2 block text-sm font-bold">
                      Вашият имейл<span className="text-white">*</span>
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      required
                      className="min-h-[52px] w-full border border-transparent bg-[#f7f7f7] px-4 py-4 text-base text-[#17233a] outline-none focus:border-[#8aa5cf] focus:shadow-[0_0_0_3px_rgba(138,165,207,0.18)]"
                    />
                  </div>

                  <div className="mb-5">
                    <label htmlFor="subject" className="mb-2 block text-sm font-bold">
                      Тема<span className="text-white">*</span>
                    </label>
                    <input
                      id="subject"
                      name="subject"
                      type="text"
                      required
                      className="min-h-[52px] w-full border border-transparent bg-[#f7f7f7] px-4 py-4 text-base text-[#17233a] outline-none focus:border-[#8aa5cf] focus:shadow-[0_0_0_3px_rgba(138,165,207,0.18)]"
                    />
                  </div>

                  <div className="mb-5">
                    <label htmlFor="message" className="mb-2 block text-sm font-bold">
                      Вашето съобщение<span className="text-white">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      className="min-h-[230px] w-full resize-y border border-transparent bg-[#f7f7f7] px-4 py-4 text-base text-[#17233a] outline-none focus:border-[#8aa5cf] focus:shadow-[0_0_0_3px_rgba(138,165,207,0.18)]"
                    />
                  </div>

                  <label htmlFor="consent" className="mb-4 mt-5 flex items-start gap-2.5 text-sm leading-relaxed text-[#f0f3f8]">
                    <input
                      id="consent"
                      name="consent"
                      type="checkbox"
                      required
                      className="mt-0.5 h-[17px] w-[17px] min-w-[17px] accent-[#f0c400]"
                    />
                    <span>
                      Използвайки този формуляр, вие се съгласявате с обработката и съхраняването на
                      предоставените данни за целите на отговора на вашето запитване.
                    </span>
                  </label>

                  {status === "success" && (
                    <div
                      role="status"
                      aria-live="polite"
                      className="mb-4 rounded-md border border-[#a9dfb9] bg-[#dff4e5] px-4 py-3 text-sm font-semibold text-[#176b35]"
                    >
                      Съобщението беше изпратено успешно. Благодарим Ви за запитването!
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={submitting}
                    className="min-h-[48px] rounded-[5px] bg-[#263957] px-6 py-3 text-sm font-bold text-white transition hover:-translate-y-px hover:bg-[#1f304d] disabled:cursor-wait disabled:opacity-65"
                  >
                    {submitting ? "Изпращане..." : "Изпращане"}
                  </button>

                  <p className="mt-3.5 text-xs leading-relaxed text-white/70">
                    Полетата със * са задължителни.
                  </p>
                </form>
              </div>
            </section>
          </Reveal>

          {/* Карта */}
          <Reveal delay={250} className="order-3 col-span-1 border-t border-[#dfe4eb] bg-white px-6 py-10 sm:px-10 md:col-span-2 md:px-12 md:py-12">
            <section aria-labelledby="map-title">
              <h2
                id="map-title"
                className="text-center text-2xl font-normal tracking-tight text-[#17233a] sm:text-4xl"
              >
                Къде се намира училището
              </h2>

              <div className="my-7 flex items-center justify-center gap-2.5 text-[#31558f]" aria-hidden="true">
                <span className="h-px max-w-[28%] flex-1 bg-current opacity-70" />
                <span className="relative h-[23px] w-4 -skew-y-[28deg] rounded-sm border-2 border-current" />
                <span className="h-px max-w-[28%] flex-1 bg-current opacity-70" />
              </div>

              <div className="mx-auto max-w-[1080px] overflow-hidden rounded shadow-[0_8px_24px_rgba(30,45,70,0.12)]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d370.9972506283123!2d25.5532883!3d41.936324!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14ad50c4be88bc8f%3A0xa065937099df3dff!2z0KHQoyAi0JLQsNGB0LjQuyDQm9C10LLRgdC60Lgi!5e0!3m2!1sbg!2sbg!4v1786505522988!5m2!1sbg!2sbg"
                  width="600"
                  height="450"
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="strict-origin-when-cross-origin"
                  title="Карта на СУ „Васил Левски“ – Хасково"
                  className="block h-[450px] w-full border-0 sm:h-[420px]"
                />
              </div>
            </section>
          </Reveal>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
