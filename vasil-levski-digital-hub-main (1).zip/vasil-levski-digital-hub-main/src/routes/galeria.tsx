import { useEffect, useMemo, useState } from "react";
import { Images } from "lucide-react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, Pagination } from "@/components/PageShell";
import { Lightbox } from "@/components/Lightbox";
import { fetchNews, type NewsItem } from "@/lib/news";
import { driveImgProps } from "@/lib/imgProps";
const galleryHero = "/assets/gallery-hero.jpg";
const divider = "/assets/divider.png";

const title = "Фотогалерия – СУ „Васил Левски“ Хасково";
const description =
  "Албуми със снимки от събития, празници и постижения на СУ „Васил Левски“ – Хасково.";

export const Route = createFileRoute("/galeria")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: galleryHero },
      { name: "twitter:image", content: galleryHero },
    ],
  }),
  component: GalleryPage,
});

const MONTHS = ["яну", "фев", "март", "апр", "май", "юни", "юли", "авг", "сеп", "окт", "ное", "дек"];
const PER_PAGE = 10;

function Album({ item }: { item: NewsItem }) {
  const images = useMemo(
    () => Array.from(new Set([item.imageUrl, ...item.gallery].filter(Boolean))),
    [item],
  );
  const [current, setCurrent] = useState(images[0] ?? "");
  const [lightbox, setLightbox] = useState<number | null>(null);

  return (
    <div className="mb-16">
      <h2 className="text-center font-display text-2xl font-bold text-primary sm:text-3xl">
        <Link
          to="/novini/$id"
          params={{ id: String(item.id) }}
          className="transition-colors duration-500 hover:text-accent"
        >
          {item.title}
        </Link>
      </h2>
      <img
              loading="lazy"
              decoding="async" src={divider} alt="" className="mx-auto my-5 w-64 max-w-full" />

      <div className="relative overflow-hidden rounded-xl bg-muted shadow-[var(--shadow-soft)]">
        <div className="absolute left-4 top-4 z-10 rounded-md bg-primary px-3 py-2 text-center text-primary-foreground">
          <span className="block text-xl font-bold leading-none">
            {String(item.date.getDate()).padStart(2, "0")}
          </span>
          <span className="block text-xs uppercase">{MONTHS[item.date.getMonth()]}</span>
        </div>
        <button
          type="button"
          onClick={() => setLightbox(Math.max(0, images.indexOf(current)))}
          className="block w-full"
          aria-label={`Отвори снимка от „${item.title}“`}
        >
          <img
            {...driveImgProps(current, "(min-width:1024px) 1024px, 100vw")}
            alt={item.title}
            loading="lazy"
            decoding="async"
            className="h-[280px] w-full cursor-zoom-in object-cover object-center transition-transform duration-700 hover:scale-[1.02] sm:h-[460px]"
          />
        </button>
      </div>

      {images.length > 1 && (
        <div className="mt-4 grid grid-cols-4 gap-3 sm:grid-cols-6">
          {images.map((src) => (
            <button
              key={src}
              type="button"
              onClick={() => setCurrent(src)}
              className={`aspect-square overflow-hidden rounded-md border-2 transition ${
                src === current ? "border-accent" : "border-transparent opacity-80 hover:opacity-100"
              }`}
            >
              <img {...driveImgProps(src, "(min-width:640px) 16vw, 25vw", 400)} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover object-center" />
            </button>
          ))}
        </div>
      )}

      {lightbox !== null && (
        <Lightbox
          images={images}
          index={lightbox}
          onChange={setLightbox}
          onClose={() => setLightbox(null)}
        />
      )}
    </div>
  );
}

function GalleryPage() {
  const [albums, setAlbums] = useState<NewsItem[] | null>(null);
  const [error, setError] = useState(false);
  const [page, setPage] = useState(1);

  useEffect(() => {
    let active = true;
    fetchNews()
      .then((items) => active && setAlbums(items.filter((i) => i.imageUrl)))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, []);

  const totalPages = albums ? Math.ceil(albums.length / PER_PAGE) : 0;
  const items = (albums ?? []).slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <PageShell title="Галерия" image={galleryHero} icon={<Images className="h-7 w-7" />}>
      <section className="bg-secondary/40 py-12">
        <div className="mx-auto max-w-4xl px-4 lg:px-8">
          {error && (
            <p className="text-center text-destructive">Възникна грешка при зареждане.</p>
          )}
          {!error && !albums && (
            <p className="text-center text-muted-foreground">Зареждане на албумите...</p>
          )}
          {items.map((item) => (
            <Album key={item.id} item={item} />
          ))}
          <Pagination
            page={page}
            totalPages={totalPages}
            onChange={(p) => {
              setPage(p);
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </div>
      </section>
    </PageShell>
  );
}
