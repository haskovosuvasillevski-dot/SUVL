import { createFileRoute } from "@tanstack/react-router";
import { ShoppingCart } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { AutoIframe } from "@/components/AutoIframe";
const banner = "/assets/profil-na-kupuvacha.png";

const title = "Профил на купувача – СУ „Васил Левски“ Хасково";
const description =
  "Обществени поръчки, документация и договори на СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/profil-na-kupuvacha")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <PageShell
      title="Профил на купувача"
      image={banner}
      icon={<ShoppingCart className="h-7 w-7" />}
    >
      <section className="mx-auto max-w-7xl px-2 py-10 lg:px-8">
        <AutoIframe
          src="/profil-na-kupuvacha.html"
          title="Профил на купувача"
          whiteBackground
        />
      </section>
    </PageShell>
  ),
});
