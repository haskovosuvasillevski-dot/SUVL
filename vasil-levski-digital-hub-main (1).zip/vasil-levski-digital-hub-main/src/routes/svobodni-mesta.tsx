import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { AdmissionTitle } from "@/components/AdmissionTitle";
import { AdmissionProgress } from "@/components/AdmissionProgress";
import { AdmissionGallery } from "@/components/AdmissionGallery";
import { fetchAdmission, directDriveUrl, type AdmissionRecord } from "@/lib/admission";
const illustration = "/assets/svobodni-mesta.png";

const SHEET_ID = "1I6JUYmsqzk7yi3q-U13vZJWUsCFFYTBG-m0r3IG3lJI";

const title = "Свободни места – СУ „Васил Левски“ Хасково";
const description =
  "Актуална информация за свободните места в СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/svobodni-mesta")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SvobodniMestaPage,
});

function SvobodniMestaPage() {
  const [record, setRecord] = useState<AdmissionRecord | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "empty" | "error">("loading");

  useEffect(() => {
    let active = true;
    fetchAdmission(SHEET_ID)
      .then((r) => {
        if (!active) return;
        setRecord(r);
        setState(r ? "ready" : "empty");
      })
      .catch(() => active && setState("error"));
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <AdmissionProgress id={4} />
        <section className="py-14">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 lg:grid-cols-2 lg:px-8">
          <div className="lg:order-1">
            <AdmissionTitle
              title={record?.title ?? (state === "loading" ? "Зареждане..." : "Свободни места")}
              highlightWord={record?.highlightWord ?? ""}
              academicYear={record?.academicYear ?? ""}
            />
            <img
              src={illustration}
              alt="Свободни места в СУ „Васил Левски“"
              loading="lazy"
              className="mx-auto block w-full max-w-[520px] rounded-lg shadow-[0_10px_25px_rgba(0,0,0,0.15)]"
            />
          </div>

          <div className="lg:order-2">
            {state === "loading" && <p className="text-muted-foreground">Зареждане на информацията...</p>}
            {state === "empty" && (
              <p className="rounded-md border-l-4 border-destructive bg-destructive/10 p-5 text-destructive">
                Няма активен запис в базата данни.
              </p>
            )}
            {state === "error" && (
              <p className="rounded-md border-l-4 border-destructive bg-destructive/10 p-5 text-destructive">
                Грешка при зареждане на данните.
              </p>
            )}
            {record?.content && (
              <div className="space-y-4 text-[17px] font-extrabold leading-[1.7] text-primary">
                {record.content.split(/\r?\n+/).map((p, i) => (
                  <p key={i}>{p.trim()}</p>
                ))}
              </div>
            )}
            {record?.pdfUrl && (
              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href={record.pdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-12 items-center rounded-md bg-primary px-6 py-3 font-bold text-primary-foreground transition hover:-translate-y-0.5"
                >
                  {record.buttonText || "Отвори документа"}
                </a>
                <a
                  href={directDriveUrl(record.pdfUrl)}
                  className="inline-flex min-h-12 items-center rounded-md bg-foreground px-6 py-3 font-bold text-background transition hover:-translate-y-0.5"
                >
                  Изтегли PDF
                </a>
              </div>
            )}
          </div>
        </div>
        </section>
        <AdmissionGallery page="Свободни места" />
      </main>
      <SiteFooter />
    </div>
  );
}
