import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { AdmissionGallery } from "@/components/AdmissionGallery";
import { AutoIframe } from "@/components/AutoIframe";

const title = "Профил „Природни науки“ – СУ „Васил Левски“ Хасково";
const description =
  "Профил „Природни науки“ при приема в VIII клас в СУ „Васил Левски“ – Хасково: профилиращи предмети, модули и възможности за учениците.";

export const Route = createFileRoute("/priem-8-klas-pr-2")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Profile2Page,
});

function Profile2Page() {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <AutoIframe
          src="/priem-8-klas-pr-2.html"
          title="Профил „Природни науки“"
          whiteBackground
          minHeight={1200}
        />
        <AdmissionGallery page="Прием 8 клас" />
      </main>
      <SiteFooter />
    </div>
  );
}
