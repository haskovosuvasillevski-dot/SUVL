import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { PageHero } from "@/components/PageShell";
const hero = "/assets/nvo-dzi-hero.jpg";
const nvo4 = "/assets/nvo4.png";
const nvo7 = "/assets/nvo7.png";
const nvo10 = "/assets/nvo10.jpg";
const dzi12 = "/assets/dzi12.jpg";

const title = "НВО и ДЗИ – СУ „Васил Левски“ Хасково";
const description =
  "Информация и материали за НВО в 4., 7. и 10. клас и ДЗИ в 12. клас в СУ „Васил Левски“ – град Хасково.";

const CARDS = [
  { label: "НВО 4 КЛАС", image: nvo4 },
  { label: "НВО 7 КЛАС", image: nvo7 },
  { label: "НВО 10 КЛАС", image: nvo10 },
  { label: "ДЗИ 12 КЛАС", image: dzi12 },
];

export const Route = createFileRoute("/nvo-i-dzi/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: hero },
      { name: "twitter:image", content: hero },
    ],
  }),
  component: NvoDziPage,
});

function NvoDziPage() {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <PageHero title="НВО и ДЗИ" image={hero} icon={<BookOpen />} />

        <div className="mx-auto grid w-full max-w-6xl grid-cols-1 gap-6 px-5 py-14 sm:grid-cols-2 sm:px-8 lg:grid-cols-4">
          {CARDS.map((card, i) => (
            <Reveal key={card.label} delay={Math.min(i * 120, 400)}>
              <Link
                to="/nvo-i-dzi/$page"
                params={{ page: card.label }}
                className="group relative block h-[220px] overflow-hidden rounded-xl shadow-[0_10px_20px_rgba(0,0,0,0.15)] transition-transform duration-500 hover:scale-[1.04]"
              >
                <img
                  src={card.image}
                  alt={card.label}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
                <span className="absolute inset-x-3 bottom-5 rounded bg-accent/90 px-3 py-3 text-center text-lg font-bold text-white">
                  {card.label}
                </span>
              </Link>
            </Reveal>
          ))}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
