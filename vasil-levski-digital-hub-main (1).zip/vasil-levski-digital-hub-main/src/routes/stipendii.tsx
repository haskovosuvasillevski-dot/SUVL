import { Coins } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { AutoIframe } from "@/components/AutoIframe";
const banner = "/assets/stipendii-hero.jpg";

const title = "Стипендии – СУ „Васил Левски“ Хасково";
const description =
  "Условия, критерии, срокове и документи за ученическите стипендии в СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/stipendii")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ScholarshipsPage,
});

function ScholarshipsPage() {
  return (
    <PageShell title="Стипендии" image={banner} icon={<Coins className="h-7 w-7" />}>
      <section className="mx-auto max-w-7xl px-2 py-10 lg:px-8">
        <AutoIframe src="/stipendii.html" title="Стипендии" />
      </section>
    </PageShell>
  );
}
