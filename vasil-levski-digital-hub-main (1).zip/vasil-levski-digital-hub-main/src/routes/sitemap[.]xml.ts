import { createFileRoute } from "@tanstack/react-router";

// TODO: replace with your project URL once a project name or custom domain is set.
const BASE_URL = "";

interface SitemapEntry {
  path: string;
  changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  priority?: string;
}

const STATIC_ROUTES: SitemapEntry[] = [
  { path: "/", changefreq: "weekly", priority: "1.0" },
  { path: "/novini", changefreq: "daily", priority: "0.9" },
  { path: "/galeria", changefreq: "weekly", priority: "0.7" },
  { path: "/istoriya", changefreq: "monthly", priority: "0.6" },
  { path: "/patrona", changefreq: "monthly", priority: "0.6" },
  { path: "/ekip", changefreq: "monthly", priority: "0.6" },
  { path: "/materialna-baza", changefreq: "monthly", priority: "0.6" },
  { path: "/izvunklasni-deynosti", changefreq: "weekly", priority: "0.7" },
  { path: "/proekti", changefreq: "weekly", priority: "0.7" },
  { path: "/sastezaniya-i-olimpiadi", changefreq: "weekly", priority: "0.7" },
  { path: "/nvo-i-dzi", changefreq: "monthly", priority: "0.6" },
  { path: "/priem-1-klas", changefreq: "monthly", priority: "0.7" },
  { path: "/priem-5-klas", changefreq: "monthly", priority: "0.7" },
  { path: "/priem-8-klas", changefreq: "monthly", priority: "0.7" },
  { path: "/priem-8-klas-pr", changefreq: "monthly", priority: "0.6" },
  { path: "/priem-8-klas-pr-2", changefreq: "monthly", priority: "0.6" },
  { path: "/svobodni-mesta", changefreq: "weekly", priority: "0.6" },
  { path: "/dokumenti", changefreq: "monthly", priority: "0.6" },
  { path: "/byudzhet", changefreq: "monthly", priority: "0.5" },
  { path: "/administrativni-uslugi", changefreq: "monthly", priority: "0.5" },
  { path: "/profil-na-kupuvacha", changefreq: "monthly", priority: "0.5" },
  { path: "/prava-i-zadalzheniya", changefreq: "yearly", priority: "0.4" },
  { path: "/forma-na-obuchenie", changefreq: "monthly", priority: "0.5" },
  { path: "/onlain-obuchenie", changefreq: "monthly", priority: "0.5" },
  { path: "/uchebni-planove", changefreq: "monthly", priority: "0.6" },
  { path: "/uchebnitsi", changefreq: "monthly", priority: "0.6" },
  { path: "/sedmichno-razpisanie", changefreq: "weekly", priority: "0.6" },
  { path: "/grafitsi", changefreq: "weekly", priority: "0.5" },
  { path: "/obedno-menyu", changefreq: "weekly", priority: "0.5" },
  { path: "/stipendii", changefreq: "monthly", priority: "0.5" },
  { path: "/elektronni-resursi", changefreq: "monthly", priority: "0.5" },
  { path: "/almanah-i-letopis", changefreq: "monthly", priority: "0.5" },
  { path: "/kontakti", changefreq: "yearly", priority: "0.6" },
  { path: "/biskvitki", changefreq: "yearly", priority: "0.3" },
  { path: "/poveritelnost", changefreq: "yearly", priority: "0.3" },
  { path: "/obshti-usloviya", changefreq: "yearly", priority: "0.3" },
];

const NVO_PAGES = ["НВО 4 КЛАС", "НВО 7 КЛАС", "НВО 10 КЛАС", "ДЗИ 12 КЛАС"];

/** Динамичните страници идват от Google Sheets — при грешка sitemap-ът
 *  връща поне статичните маршрути. */
async function dynamicEntries(): Promise<SitemapEntry[]> {
  const entries: SitemapEntry[] = [];
  const safe = async (fn: () => Promise<SitemapEntry[]>) => {
    try {
      entries.push(...(await fn()));
    } catch {
      /* пропускаме при недостъпна таблица */
    }
  };

  await safe(async () => {
    const { fetchNews } = await import("@/lib/news");
    const news = await fetchNews();
    return news.map((n) => ({
      path: `/novini/${n.id}`,
      changefreq: "monthly" as const,
      priority: "0.6",
    }));
  });

  await safe(async () => {
    const { fetchClubs } = await import("@/lib/clubs");
    const clubs = await fetchClubs();
    return clubs
      .filter((c) => c.id)
      .map((c) => ({
        path: `/izvunklasni-deynosti/${encodeURIComponent(c.id)}`,
        changefreq: "monthly" as const,
        priority: "0.5",
      }));
  });

  await safe(async () => {
    const { fetchFacilities } = await import("@/lib/facilities");
    const facilities = await fetchFacilities();
    return facilities.map((f) => ({
      path: `/materialna-baza/${encodeURIComponent(f.id)}`,
      changefreq: "monthly" as const,
      priority: "0.5",
    }));
  });

  await safe(async () => {
    const { fetchProjects } = await import("@/lib/projects");
    const projects = await fetchProjects();
    return projects.map((p) => ({
      path: `/proekti/${encodeURIComponent(p.id)}`,
      changefreq: "monthly" as const,
      priority: "0.5",
    }));
  });

  await safe(async () => {
    const { fetchSchoolCompetitions } = await import("@/lib/competitions");
    const competitions = await fetchSchoolCompetitions();
    return competitions.map((c) => ({
      path: `/sastezaniya-i-olimpiadi/${c.id}`,
      changefreq: "monthly" as const,
      priority: "0.5",
    }));
  });

  return entries;
}

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const dynamic = await dynamicEntries();
        const entries: SitemapEntry[] = [
          ...STATIC_ROUTES,
          ...NVO_PAGES.map((page) => ({
            path: `/nvo-i-dzi/${encodeURIComponent(page)}`,
            changefreq: "monthly" as const,
            priority: "0.5",
          })),
          ...dynamic,
        ];

        const urls = entries.map((e) =>
          [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`,
          ]
            .filter(Boolean)
            .join("\n"),
        );

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
