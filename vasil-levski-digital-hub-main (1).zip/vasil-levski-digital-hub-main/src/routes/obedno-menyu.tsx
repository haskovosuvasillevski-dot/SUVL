import { createFileRoute } from "@tanstack/react-router";
import { UtensilsCrossed } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { AutoIframe } from "@/components/AutoIframe";
const banner = "/assets/obyad.webp";

const title = "Обедно меню – СУ „Васил Левски“ Хасково";
const description =
  "Седмично обедно меню за учениците на СУ „Васил Левски“ – град Хасково.";

export const Route = createFileRoute("/obedno-menyu")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LunchMenuPage,
});

function LunchMenuPage() {
  return (
    <PageShell
      title="Обедно меню"
      image={banner}
      icon={<UtensilsCrossed className="h-7 w-7" />}
    >
      <section className="mx-auto max-w-7xl px-2 py-10 lg:px-8">
        <AutoIframe src="/obedno-menyu.html" title="Обедно меню" whiteBackground />
      </section>
    </PageShell>
  );
}
