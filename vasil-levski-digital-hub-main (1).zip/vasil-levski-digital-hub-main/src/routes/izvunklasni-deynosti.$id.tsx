import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Clock,
  User,
  Timer,
  LayoutList,
  Users,
  Globe,
  Award,
  GraduationCap,
} from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Lightbox } from "@/components/Lightbox";
import {
  fetchClubs,
  driveImage,
  driveId,
  youtubeId,
  splitLines,
  parseMediaEntry,
  type Club,
} from "@/lib/clubs";

export const Route = createFileRoute("/izvunklasni-deynosti/$id")({
  head: () => ({
    meta: [
      { title: "Клуб – СУ „Васил Левски“ Хасково" },
      {
        name: "description",
        content:
          "Информация за извънкласния клуб: ръководител, програма, участници и издания.",
      },
      { property: "og:title", content: "Клуб – СУ „Васил Левски“ Хасково" },
      {
        property: "og:description",
        content: "Информация за извънкласния клуб в СУ „Васил Левски“ – град Хасково.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ClubDetail,
});

const TABS = [
  { key: "overview", label: "Преглед" },
  { key: "editions", label: "Издания на клуба" },
  { key: "leader", label: "Ръководител" },
] as const;

/** Google Drive елемент, за който не е ясно дали е снимка или видео. */
function DriveMedia({
  id,
  caption,
  onOpen,
}: {
  id: string;
  caption: string;
  onOpen?: () => void;
}) {
  const [asVideo, setAsVideo] = useState(false);
  if (asVideo)
    return (
      <iframe
        src={`https://drive.google.com/file/d/${id}/preview`}
        title={caption || "Видео от Google Drive"}
        allow="autoplay; fullscreen"
        allowFullScreen
        scrolling="no"
        className="h-[300px] w-full overflow-hidden rounded-lg border-0 bg-card"
      />
    );
  return (
    <img
      src={`https://lh3.googleusercontent.com/d/${id}=w2000`}
      alt={caption || "Материал от клуба"}
      loading="lazy"
      referrerPolicy="no-referrer"
      onError={() => setAsVideo(true)}
      onClick={onOpen}
      className="h-[300px] w-full cursor-zoom-in rounded-lg bg-card object-contain"
    />
  );
}

function MediaBlock({ value }: { value: string }) {
  const items = useMemo(() => splitLines(value).map(parseMediaEntry), [value]);

  const isVideoEntry = (e: { url: string; text: string }) =>
    Boolean(youtubeId(e.url)) ||
    /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(e.url) ||
    (e.url.includes("cloudinary.com") && /\/video\//i.test(e.url)) ||
    e.text.toLowerCase() === "video";

  const videos = useMemo(() => items.filter(isVideoEntry), [items]);
  const imageEntries = useMemo(() => items.filter((e) => !isVideoEntry(e)), [items]);
  const photos = useMemo(
    () => imageEntries.map((e) => (driveId(e.url) ? driveImage(e.url) : e.url)),
    [imageEntries],
  );

  const [lightbox, setLightbox] = useState<number | null>(null);
  if (!items.length)
    return <p className="text-muted-foreground">Няма добавени материали.</p>;

  return (
    <>
      {videos.length > 0 && (
        <div className="mb-10 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {videos.map((entry, i) => {
            const yid = youtubeId(entry.url);
            const did = driveId(entry.url);
            const caption =
              entry.text && entry.text.toLowerCase() !== "video" ? entry.text : "";
            const src = yid
              ? `https://www.youtube.com/embed/${yid}`
              : did
                ? `https://drive.google.com/file/d/${did}/preview`
                : "";
            return (
              <figure key={`v${i}`} className="min-w-0">
                {src ? (
                  <iframe
                    src={src}
                    title={caption || "Видео"}
                    allow="autoplay; fullscreen"
                    allowFullScreen
                    scrolling="no"
                    className="aspect-video h-auto w-full overflow-hidden rounded-lg border-0 bg-black"
                  />
                ) : (
                  <video
                    src={entry.url}
                    controls
                    className="aspect-video w-full rounded-lg bg-black"
                  />
                )}
                {caption && (
                  <figcaption className="mt-2 text-sm leading-snug text-muted-foreground">
                    {caption}
                  </figcaption>
                )}
              </figure>
            );
          })}
        </div>
      )}

      {imageEntries.length > 0 && (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {imageEntries.map((entry, i) => {
            const did = driveId(entry.url);
            const caption = entry.text;
            return (
              <figure key={`p${i}`} className="min-w-0">
                {did ? (
                  <DriveMedia id={did} caption={caption} onOpen={() => setLightbox(i)} />
                ) : (
                  <img
                    src={entry.url}
                    alt={caption || "Материал от клуба"}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    onClick={() => setLightbox(i)}
                    className="h-[300px] w-full cursor-zoom-in rounded-lg bg-card object-contain"
                  />
                )}
                {caption && (
                  <figcaption className="mt-2 text-sm leading-snug text-muted-foreground">
                    {caption}
                  </figcaption>
                )}
              </figure>
            );
          })}
        </div>
      )}

      {lightbox !== null && photos.length > 0 && (
        <Lightbox
          images={photos}
          index={lightbox}
          onClose={() => setLightbox(null)}
          onChange={setLightbox}
        />
      )}
    </>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof User;
  label: string;
  value: string;
}) {
  if (!value) return null;
  return (
    <div className="grid grid-cols-[28px_1fr_auto] items-center gap-3 border-t border-border py-4 text-[15px]">
      <Icon className="h-5 w-5 text-primary" />
      <span className="font-medium text-foreground">{label}</span>
      <span className="text-right text-muted-foreground">{value}</span>
    </div>
  );
}

function ClubDetail() {
  const { id } = Route.useParams();
  const [club, setClub] = useState<Club | null>(null);
  const [others, setOthers] = useState<Club[]>([]);
  const [status, setStatus] = useState<"loading" | "ready" | "error" | "missing">("loading");
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("overview");

  useEffect(() => {
    let active = true;
    fetchClubs()
      .then((clubs) => {
        if (!active) return;
        const found = clubs.find((c) => c.id.trim() === id.trim());
        if (!found) return setStatus("missing");
        setClub(found);
        const rest = clubs.filter((c) => c.id.trim() !== id.trim());
        for (let i = rest.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [rest[i], rest[j]] = [rest[j]!, rest[i]!];
        }
        setOthers(rest.slice(0, 3));
        setStatus("ready");
      })
      .catch(() => active && setStatus("error"));
    return () => {
      active = false;
    };
  }, [id]);

  const editions = useMemo(
    () => (club ? splitLines(club.editions).map(parseMediaEntry) : []),
    [club],
  );
  const editionImages = useMemo(
    () => editions.map((e) => driveImage(e.url)),
    [editions],
  );
  const [editionLightbox, setEditionLightbox] = useState<number | null>(null);

  /* Минимално, но гарантирано разстояние между картата/съдържанието и „Други клубове“. */
  const asideRef = useRef<HTMLElement | null>(null);
  const markerRef = useRef<HTMLDivElement | null>(null);
  const [spacer, setSpacer] = useState(40);

  useLayoutEffect(() => {
    const MIN = 40;
    const measure = () => {
      const aside = asideRef.current;
      const marker = markerRef.current;
      if (!marker) return;
      const markerTop = marker.getBoundingClientRect().top;
      const asideBottom = aside ? aside.getBoundingClientRect().bottom : markerTop;
      setSpacer(Math.max(MIN, asideBottom - markerTop + MIN));
    };
    measure();
    const id = window.setTimeout(measure, 300);
    window.addEventListener("resize", measure);
    return () => {
      window.clearTimeout(id);
      window.removeEventListener("resize", measure);
    };
  }, [club, tab, others.length]);

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        {status !== "ready" || !club ? (
          <p className="py-24 text-center text-lg text-muted-foreground">
            {status === "loading"
              ? "Зареждане..."
              : status === "missing"
                ? "Клубът не е намерен."
                : "Грешка при зареждане на информацията."}
          </p>
        ) : (
          <>
            <section className="relative z-20 bg-secondary/40">
              <div className="relative mx-auto max-w-7xl px-4 pb-10 pt-12 lg:px-8">
                <div>
                  <div className="md:w-[calc(100%-430px)] lg:w-[calc(100%-490px)]">
                    <h1 className="font-display text-3xl font-bold leading-tight text-foreground sm:text-5xl">
                      {club.title}
                    </h1>
                    <div className="mt-6 flex flex-wrap items-center gap-6 text-base text-muted-foreground">
                      {club.leader && (
                        <span className="flex items-center gap-3">
                          <User className="h-6 w-6 text-primary" />
                          {club.leader}
                        </span>
                      )}
                      {club.leader && (club.subtitle || club.levels) && (
                        <span className="hidden h-7 w-px bg-border sm:block" />
                      )}
                      {(club.subtitle || club.levels) && (
                        <span className="flex items-center gap-3">
                          <GraduationCap className="h-6 w-6 text-primary" />
                          {club.subtitle || club.levels}
                        </span>
                      )}
                    </div>
                  </div>

                  <aside ref={asideRef} className="mt-8 rounded-xl border border-border bg-card p-7 shadow-[var(--shadow-soft)] md:absolute md:right-4 md:top-5 md:z-30 md:mt-0 md:w-[370px] lg:w-[430px] lg:px-8">
                    <div className="overflow-hidden rounded-lg bg-card">
                      <img
              loading="lazy"
              decoding="async"
                        src={driveImage(club.image)}
                        alt={club.title}
                        referrerPolicy="no-referrer"
                        className="block w-full object-contain"
                      />
                    </div>
                    <h2 className="mb-4 mt-7 font-display text-2xl font-bold text-primary">
                      Информация:
                    </h2>
                    <InfoRow icon={User} label="Ръководител:" value={club.leader} />
                    <InfoRow icon={Timer} label="Продължителност:" value={club.duration} />
                    <InfoRow icon={LayoutList} label="Занятия:" value={club.lessons} />
                    <InfoRow icon={Users} label="Участници:" value={club.participants} />
                    <InfoRow icon={Globe} label="Език:" value={club.language} />
                    <InfoRow icon={Award} label="Сертификат:" value={club.certificate} />
                    {club.contact && (
                      <a
                        href={club.contact}
                        className="mt-6 block rounded-lg bg-primary px-5 py-4 text-center font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
                      >
                        Контакт за заявка
                      </a>
                    )}
                  </aside>
                </div>
              </div>
            </section>

            <section className="mx-auto max-w-7xl px-4 py-12 lg:px-8">
              <div className="flex overflow-x-auto border-b border-border">
                {TABS.map((t) => (
                  <button
                    key={t.key}
                    type="button"
                    onClick={() => setTab(t.key)}
                    className={`relative whitespace-nowrap px-6 py-4 text-lg font-semibold transition-colors ${
                      tab === t.key ? "text-primary" : "text-muted-foreground"
                    }`}
                  >
                    {t.label}
                    {tab === t.key && (
                      <span className="absolute inset-x-0 -bottom-px h-[3px] bg-accent" />
                    )}
                  </button>
                ))}
              </div>

              {tab === "overview" && (
                <div className="mt-8 space-y-10">
                  {club.description && (
                    <div className="md:pr-[400px] lg:pr-[470px]">
                      <h2 className="mb-4 font-display text-2xl font-bold text-primary">
                        Описание
                      </h2>
                      <p className="whitespace-pre-line text-lg leading-relaxed">
                        {club.description}
                      </p>
                    </div>
                  )}
                  {club.students && (
                    <div className="md:pr-[400px] lg:pr-[470px]">
                      <h2 className="mb-4 font-display text-2xl font-bold text-primary">
                        Участници
                      </h2>
                      <p className="whitespace-pre-line text-lg leading-relaxed">
                        {club.students}
                      </p>
                    </div>
                  )}
                  {club.program && (
                    <div className="md:pr-[400px] lg:pr-[470px]">
                      <h2 className="mb-4 font-display text-2xl font-bold text-primary">
                        Програма
                      </h2>
                      <p className="whitespace-pre-line text-lg leading-relaxed">
                        {club.program}
                      </p>
                    </div>
                  )}
                  <div>
                    <h2 className="mb-4 font-display text-2xl font-bold text-primary">
                      Материали
                    </h2>
                    <MediaBlock value={club.links} />
                  </div>
                </div>
              )}

              {tab === "editions" && (
                <div className="mt-8 md:pr-[400px] lg:pr-[470px]">
                  {editions.length === 0 ? (
                    <p className="text-muted-foreground">Няма добавени издания.</p>
                  ) : (
                    <div className="grid grid-cols-2 gap-7 sm:grid-cols-3">
                      {editions.map((e, i) => (
                        <article key={i} className="text-center">
                          <img
                            src={driveImage(e.url)}
                            alt={e.text || "Издание на клуба"}
                            loading="lazy"
                            referrerPolicy="no-referrer"
                            onClick={() => setEditionLightbox(i)}
                            className="mx-auto h-[125px] w-full cursor-zoom-in rounded-lg bg-card object-contain"
                          />
                          {e.text && (
                            <p className="mt-3 text-[15px] leading-relaxed">{e.text}</p>
                          )}
                        </article>
                      ))}
                    </div>
                  )}
                  {editionLightbox !== null && editionImages.length > 0 && (
                    <Lightbox
                      images={editionImages}
                      index={editionLightbox}
                      onClose={() => setEditionLightbox(null)}
                      onChange={setEditionLightbox}
                    />
                  )}
                </div>
              )}

              {tab === "leader" && (
                <div className="mt-8 grid gap-8 sm:grid-cols-[270px_1fr] md:pr-[400px] lg:pr-[470px]">
                  {club.leaderImage && (
                    <img
              loading="lazy"
              decoding="async"
                      src={driveImage(club.leaderImage)}
                      alt={club.leader}
                      referrerPolicy="no-referrer"
                      className="w-full max-w-[270px] rounded-xl bg-card object-cover"
                    />
                  )}
                  <div>
                    <h2 className="mb-4 font-display text-2xl font-bold text-primary">
                      {club.leader}
                    </h2>
                    <p className="whitespace-pre-line text-lg leading-relaxed">
                      {club.leaderDescription}
                    </p>
                  </div>
                </div>
              )}

            </section>

            <div ref={markerRef} style={{ height: spacer }} aria-hidden />

            {others.length > 0 && (
              <section className="mx-auto max-w-7xl px-4 pb-16 lg:px-8">
                <h2 className="mb-10 text-center font-display text-3xl font-bold text-primary">
                  Други клубове
                </h2>
                <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                  {others.map((o) => (
                    <article
                      key={o.id}
                      className="group relative h-full overflow-hidden rounded-xl border border-border bg-card shadow-[var(--shadow-soft)]"
                    >
                      <div className="relative flex h-60 w-full items-center justify-center overflow-hidden bg-card">
                        <img
                          src={driveImage(o.image)}
                          alt={o.title}
                          loading="lazy"
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-contain"
                        />
                        {o.time && (
                          <span className="absolute right-3 top-3 z-10 inline-flex items-center gap-1.5 rounded-md bg-accent px-2.5 py-1.5 text-sm font-medium text-primary-foreground">
                            <Clock className="h-4 w-4" />
                            {o.time}
                          </span>
                        )}
                      </div>
                      <div className="min-h-[170px] p-8">
                        <span className="inline-block rounded bg-secondary px-3 py-1.5 text-sm text-primary">
                          {o.levels || "Всички нива"}
                        </span>
                        <h3 className="mt-5 font-display text-xl font-bold leading-snug text-primary">
                          <Link to="/izvunklasni-deynosti/$id" params={{ id: o.id }}>
                            {o.title}
                          </Link>
                        </h3>
                        <div className="mt-4 text-base font-medium text-foreground">{o.price}</div>
                      </div>
                    </article>
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}