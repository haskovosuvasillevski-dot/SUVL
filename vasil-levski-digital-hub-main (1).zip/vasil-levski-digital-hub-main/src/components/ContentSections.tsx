import { useEffect, useState } from "react";
import { Reveal } from "@/components/Reveal";
import { Lightbox } from "@/components/Lightbox";
import { fetchSections, isFileVideo, type HistorySection } from "@/lib/history";

function Paragraphs({ text }: { text: string }) {
  const blocks = text.split(/\n\s*\n/).filter((b) => b.trim());
  return (
    <div className="space-y-4">
      {blocks.map((block, i) => (
        <p key={i} className="whitespace-pre-line text-base leading-relaxed text-foreground/90">
          {block.trim()}
        </p>
      ))}
    </div>
  );
}

function SectionBlock({
  section,
  onOpen,
}: {
  section: HistorySection;
  onOpen: (images: string[], index: number) => void;
}) {
  const large = section.images.slice(0, 2);
  const rest = section.images.slice(2);

  return (
    <section className="rounded-2xl border border-border/70 bg-card p-6 shadow-[var(--shadow-soft)] sm:p-8">
      <h2 className="font-display text-2xl font-bold leading-snug text-primary sm:text-3xl">
        {section.title}
      </h2>
      <div className="mt-3 mb-6 h-[3px] w-24 rounded-full bg-gold" />

      <Paragraphs text={section.content} />

      {large.length > 0 && (
        <div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-2">
          {large.map((src, i) => (
            <button
              key={src + i}
              type="button"
              onClick={() => onOpen(section.images, i)}
              className="group overflow-hidden rounded-xl border border-border/60 bg-muted"
            >
              <img
                src={src}
                alt={section.title}
                loading="lazy"
                className="h-64 w-full object-cover transition-transform duration-700 group-hover:scale-105 sm:h-80"
              />
            </button>
          ))}
        </div>
      )}

      {rest.length > 0 && (
        <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-6">
          {rest.map((src, i) => (
            <button
              key={src + i}
              type="button"
              onClick={() => onOpen(section.images, i + 2)}
              className="group overflow-hidden rounded-lg border border-border/60 bg-muted"
            >
              <img
                src={src}
                alt={section.title}
                loading="lazy"
                className="aspect-square w-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
            </button>
          ))}
        </div>
      )}

      {section.video && (
        <div className="mt-6 aspect-video w-full overflow-hidden rounded-xl border border-border/60 bg-muted">
          {isFileVideo(section.video) ? (
            <video
              src={section.video}
              controls
              playsInline
              preload="metadata"
              className="h-full w-full object-contain"
            />
          ) : (
            <iframe
              src={section.video}
              title={`Видео – ${section.title}`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
              allowFullScreen
              loading="lazy"
              className="h-full w-full border-0"
            />
          )}
        </div>
      )}
    </section>
  );
}

/** Секции от Google Sheet (заглавие, съдържание, снимки, видео) с галерия. */
export function ContentSections({ sheetId }: { sheetId: string }) {
  const [sections, setSections] = useState<HistorySection[] | null>(null);
  const [error, setError] = useState(false);
  const [box, setBox] = useState<{ images: string[]; index: number } | null>(null);

  useEffect(() => {
    let active = true;
    setSections(null);
    setError(false);
    fetchSections(sheetId)
      .then((items) => active && setSections(items))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, [sheetId]);

  return (
    <>
      {error && (
        <p className="text-center text-destructive">
          Възникна грешка при зареждане на съдържанието.
        </p>
      )}
      {!error && !sections && (
        <p className="py-8 text-center text-muted-foreground">Зареждане...</p>
      )}

      <div className="space-y-14">
        {sections?.map((section) => (
          <Reveal key={section.id}>
            <SectionBlock
              section={section}
              onOpen={(images, index) => setBox({ images, index })}
            />
          </Reveal>
        ))}
      </div>

      {box && (
        <Lightbox
          images={box.images}
          index={box.index}
          onClose={() => setBox(null)}
          onChange={(i) => setBox({ images: box.images, index: i })}
        />
      )}
    </>
  );
}
