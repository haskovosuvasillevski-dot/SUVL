import { useEffect, useRef, useState, type ReactNode } from "react";

export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  /* След края на анимацията махаме transform, за да не чупи position: fixed
     на наследници (напр. модал във вграден iframe). */
  const [settled, setSettled] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!visible) return;
    const timer = window.setTimeout(() => setSettled(true), 1300 + delay);
    return () => window.clearTimeout(timer);
  }, [visible, delay]);

  return (
    <div
      ref={ref}
      className={`transition-all duration-[1200ms] ease-out ${className}`}
      style={{
        opacity: visible ? 1 : 0,
        transform: settled ? undefined : visible ? "translateY(0)" : "translateY(40px)",
        transitionDelay: `${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

export function SectionHeading({
  title,
  subtitle,
  eyebrow,
  icon,
  invert = false,
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  icon: ReactNode;
  invert?: boolean;
}) {
  return (
    <Reveal className="mb-12 text-center">
      {eyebrow && (
        <p
          className={`mb-3 text-xs font-semibold uppercase tracking-[0.28em] ${
            invert ? "text-gold" : "text-brand-green"
          }`}
        >
          {eyebrow}
        </p>
      )}
      <h2
        className={`font-display text-3xl font-bold tracking-tight sm:text-4xl lg:text-[2.75rem] ${
          invert ? "text-primary-foreground" : "text-primary"
        }`}
      >
        {title}
      </h2>
      {subtitle && (
        <p
          className={`mx-auto mt-4 max-w-2xl text-base leading-relaxed ${
            invert ? "text-primary-foreground/80" : "text-muted-foreground"
          }`}
        >
          {subtitle}
        </p>
      )}
      <div className="mx-auto mt-5 flex w-44 items-center justify-center">
        <span className={`h-[2px] flex-1 ${invert ? "bg-primary-foreground" : "bg-gold"}`} />
        <span className={`px-3 ${invert ? "text-primary-foreground" : "text-primary"}`}>
          {icon}
        </span>
        <span className={`h-[2px] flex-1 ${invert ? "bg-primary-foreground" : "bg-gold"}`} />
      </div>
    </Reveal>
  );
}
