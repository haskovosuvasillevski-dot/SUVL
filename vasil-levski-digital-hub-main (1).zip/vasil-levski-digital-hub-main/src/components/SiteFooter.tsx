import { MapPin, Phone, Mail, Facebook, Youtube } from "lucide-react";
const logoAsset = "/assets/logo-footer.png";
const logo = logoAsset;

const QUICK_LINKS = [
  { label: "Новини", href: "/novini" },
  { label: "Седмично разписание", href: "/sedmichno-razpisanie" },
  { label: "Извънкласни дейности", href: "/izvunklasni-deynosti" },
  { label: "Стипендии", href: "/stipendii" },
  { label: "Обедно меню", href: "/obedno-menyu" },
  { label: "Бисквитки", href: "/biskvitki" },
  { label: "Поверителност", href: "/poveritelnost" },
  { label: "Общи условия", href: "/obshti-usloviya" },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 text-xs sm:grid-cols-2 sm:gap-8 sm:py-8 sm:text-[13px] lg:grid-cols-3 lg:gap-10 lg:px-8 lg:py-10">
        <div className="min-w-0">
          <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-gold sm:mb-3 sm:text-[11px]">
            Бързи връзки
          </p>
          <ul className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-primary-foreground/80">
            {QUICK_LINKS.map((l) => (
              <li key={l.label}>
                <a href={l.href} className="transition-colors hover:text-gold">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="order-last flex flex-col items-center justify-center gap-2 text-center sm:col-span-2 sm:gap-3 lg:order-none lg:col-span-1">
          <img
              loading="lazy"
              decoding="async"
            src={logo}
            alt="Лого на СУ „Васил Левски“"
            className="h-16 w-auto shrink-0 object-contain sm:h-24 lg:h-28"
          />
          <div>
            <p className="font-display text-sm font-bold sm:text-base">СУ „Васил Левски“</p>
            <p className="text-[11px] text-primary-foreground/75 sm:text-[13px]">град Хасково</p>
          </div>
          <div className="flex items-center gap-3">
            <a
              href="https://www.facebook.com/soulevski/?locale=bg_BG"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook страница на училището"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-primary-foreground/30 transition-colors hover:border-gold hover:text-gold"
            >
              <Facebook className="h-4 w-4" />
            </a>
            <a
              href="https://www.youtube.com/@SUVasilLevskiHaskovoOfficial/featured"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube канал на училището"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-primary-foreground/30 transition-colors hover:border-gold hover:text-gold"
            >
              <Youtube className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div className="min-w-0">
          <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-gold sm:mb-3 sm:text-[11px]">
            Връзка с нас
          </p>
          <ul className="space-y-2.5 text-primary-foreground/80">
            <li className="flex gap-2.5">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
              <span className="min-w-0">
                ул. „Стара планина“ № 2, гр. Хасково
                <a
                  href="https://maps.google.com/?q=СУ+Васил+Левски+Хасково"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-0.5 block w-fit border-b border-primary-foreground/40 hover:text-gold"
                >
                  Вижте на картата
                </a>
              </span>
            </li>
            <li className="flex gap-2.5">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
              <span className="min-w-0">
                <span className="block font-semibold text-primary-foreground">
                  Връзка с училището
                </span>
                <a href="tel:038664316" className="hover:text-gold">
                  038 / 66 43 16
                </a>
              </span>
            </li>
            <li className="flex gap-2.5">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
              <span className="min-w-0">
                <span className="block font-semibold text-primary-foreground">
                  Медицински специалист
                </span>
                <a href="tel:0884978766" className="hover:text-gold">
                  0884 978 766
                </a>
              </span>
            </li>
            <li className="flex gap-2.5">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
              <a
                href="mailto:info-2601025@edu.mon.bg"
                className="break-all hover:text-gold"
              >
                info-2601025@edu.mon.bg
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-primary-foreground/15 py-3 text-center text-xs text-primary-foreground/70">
        © {new Date().getFullYear()} СУ „Васил Левски“ – град Хасково
      </div>
    </footer>
  );
}
