import { BookMarked } from "lucide-react";
import { Reveal, SectionHeading } from "@/components/Reveal";
const plan = "/assets/%D1%83%D1%87%D0%B5%D0%B1%D0%B5%D0%BD_%D0%BF%D0%BB%D0%B0%D0%BD.jpg";
const books = "/assets/%D1%83%D1%87%D0%B5%D0%B1%D0%BD%D0%B8%D1%86%D0%B8.jpg";
const consult = "/assets/%D0%9A%D0%BE%D0%BD%D1%81%D1%83%D0%BB%D1%82%D0%B0%D1%86%D0%B8%D0%B8.jpg";
const projects = "/assets/12083728_Wavy_Bus-37_Single-10.jpg";
const pattern = "/assets/polezna-info-pattern.png";

const ITEMS = [
  { img: plan, title: "Учебни планове", href: "/uchebni-planove" },
  { img: books, title: "Учебници", href: "/uchebnitsi" },
  { img: consult, title: "Консултации", href: "/grafitsi" },
  { img: projects, title: "Проекти", href: "#" },
];

export function UsefulInfoSection() {
  return (
    <section className="relative isolate overflow-hidden bg-white py-16 sm:py-20 lg:py-24">
      {/* Декоративен фон: бледи училищни иконки върху бял фон, видими в празното пространство (картите ги покриват) */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{ backgroundImage: `url(${pattern})`, backgroundRepeat: "repeat", backgroundSize: "560px auto" }}
      />
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <SectionHeading
          title="Полезна информация"
          subtitle="Основните насоки и ресурси за успешен учебен процес"
          icon={<BookMarked className="h-6 w-6" />}
        />
        <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
          {ITEMS.map((item, i) => (
            <Reveal key={item.title} delay={i * 150}>
              <a
                href={item.href}
                className="flex h-full flex-col rounded-2xl border border-border/60 bg-card p-5 text-center shadow-[var(--shadow-soft)] transition-all duration-500 hover:-translate-y-1.5"
              >
                <div className="mx-auto mb-4 flex h-32 items-center justify-center overflow-hidden rounded-lg">
                  <img
                    src={item.img}
                    alt={item.title}
                    loading="lazy"
                    className="h-full w-full object-contain"
                  />
                </div>
                <h3 className="inline-block border-b-4 border-gold pb-1 font-display text-base font-bold text-primary sm:text-lg">
                  {item.title}
                </h3>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
