import type { ReactNode } from "react";
import { Landmark } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

/**
 * Единен банер за целия сайт — еднакво разположение на иконата,
 * двете линии и еднакъв размер на заглавието (както в „История“).
 */
export function PageHero({
  title,
  image,
  icon,
  imagePosition = "center",
}: {
  title: string;
  image: string;
  icon?: ReactNode;
  imagePosition?: string | undefined;
}) {
  return (
    <div
      className="relative flex h-[220px] w-full items-center justify-center bg-cover sm:h-[320px]"
      style={{ backgroundImage: `url(${image})`, backgroundPosition: imagePosition }}
    >
      <div className="absolute inset-0 bg-primary/65" />
      <div className="relative z-10 flex flex-col items-center gap-4 px-6 text-center">
        <h1 className="font-display text-3xl uppercase tracking-[0.2em] text-primary-foreground drop-shadow sm:text-5xl">
          {title}
        </h1>
        <div className="flex w-48 items-center justify-center sm:w-56">
          <span className="h-[2px] flex-1 bg-primary-foreground/70" />
          <span className="px-3 text-primary-foreground [&_svg]:h-7 [&_svg]:w-7">
            {icon ?? <Landmark className="h-7 w-7" />}
          </span>
          <span className="h-[2px] flex-1 bg-primary-foreground/70" />
        </div>
      </div>
    </div>
  );
}

export function PageShell({
  title,
  image,
  icon,
  imagePosition,
  children,
}: {
  title: string;
  image: string;
  icon?: ReactNode;
  imagePosition?: string | undefined;
  children: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <PageHero title={title} image={image} icon={icon} imagePosition={imagePosition} />
        {children}
      </main>
      <SiteFooter />
    </div>
  );
}

export function Pagination({
  page,
  totalPages,
  onChange,
}: {
  page: number;
  totalPages: number;
  onChange: (p: number) => void;
}) {
  if (totalPages <= 1) return null;
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1);
  return (
    <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
      <button
        type="button"
        disabled={page === 1}
        onClick={() => onChange(page - 1)}
        className="rounded-md border border-border px-4 py-2 text-sm font-semibold text-primary transition disabled:opacity-40"
      >
        Предишна
      </button>
      {pages.map((p) => (
        <button
          key={p}
          type="button"
          onClick={() => onChange(p)}
          className={`h-10 w-10 rounded-md border text-sm font-semibold transition ${
            p === page
              ? "border-accent bg-accent text-accent-foreground"
              : "border-border text-primary hover:bg-secondary"
          }`}
        >
          {p}
        </button>
      ))}
      <button
        type="button"
        disabled={page === totalPages}
        onClick={() => onChange(page + 1)}
        className="rounded-md border border-border px-4 py-2 text-sm font-semibold text-primary transition disabled:opacity-40"
      >
        Следваща
      </button>
    </div>
  );
}
