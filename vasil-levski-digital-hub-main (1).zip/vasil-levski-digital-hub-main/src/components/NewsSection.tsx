import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Newspaper } from "lucide-react";
import { Reveal, SectionHeading } from "@/components/Reveal";
import { fetchNews, type NewsItem } from "@/lib/news";
import { driveImgProps } from "@/lib/imgProps";

export function NewsSection() {
  const [news, setNews] = useState<NewsItem[] | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    fetchNews()
      .then((items) => active && setNews(items.slice(0, 4)))
      .catch(() => active && setError(true));
    return () => {
      active = false;
    };
  }, []);

  return (
    <section className="bg-background py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <SectionHeading
          title="Новини"
          subtitle="Бъдете информирани за най-важните събития и постижения в училището ни."
          icon={<Newspaper className="h-6 w-6" />}
        />

        {error && (
          <p className="text-center text-destructive">
            Възникна грешка при зареждане на новините.
          </p>
        )}
        {!error && !news && (
          <p className="py-6 text-center text-muted-foreground">Зареждане на новини...</p>
        )}
        {news && news.length === 0 && (
          <p className="text-center text-muted-foreground">Няма налични новини.</p>
        )}

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {news?.map((item, i) => (
            <Reveal key={item.id} delay={i * 150}>
              <Link
                to="/novini/$id"
                params={{ id: String(item.id) }}
                className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border/70 bg-card shadow-[var(--shadow-soft)] transition-all duration-500 hover:-translate-y-1.5 hover:border-brand-green/40"
              >
                <div className="h-52 overflow-hidden bg-muted">
                  <img
                    {...driveImgProps(
                      item.imageUrl,
                      "(min-width:1024px) 25vw, (min-width:640px) 50vw, 100vw",
                    )}
                    alt={item.title}
                    loading="lazy"
                    decoding="async"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    {item.rawDate}
                  </div>
                  <h3 className="mt-2 font-display text-lg font-bold leading-snug text-primary transition-colors duration-500 group-hover:text-brand-green">
                    {item.title}
                  </h3>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
