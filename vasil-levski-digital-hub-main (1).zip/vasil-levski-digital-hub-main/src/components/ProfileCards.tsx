import { useEffect, useRef, useState } from "react";

export type ProfileCard = { title: string; body: string };

/** Две карти, които се събират при скролване до секцията и се раздалечават при подминаване. */
export function ProfileCards({
  cards,
  renderBody,
}: {
  cards: ProfileCard[];
  renderBody: (value: string) => React.ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [together, setTogether] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => {
      const rect = el.getBoundingClientRect();
      const vh = window.innerHeight;
      const center = rect.top + rect.height / 2;
      setTogether(center > vh * 0.15 && center < vh * 0.85);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  return (
    <div ref={ref} className="mx-auto grid w-[min(1500px,92%)] gap-8 lg:grid-cols-2">
      {cards.map((card, i) => (
        <article
          key={card.title + i}
          style={{
            transform: together
              ? "translateX(0) scale(1)"
              : `translateX(${i === 0 ? "-14%" : "14%"}) scale(0.96)`,
            opacity: together ? 1 : 0.55,
          }}
          className={`relative flex h-full min-h-[280px] flex-col justify-center overflow-hidden rounded-[28px] p-10 pt-14 shadow-[0_10px_30px_rgba(0,0,0,0.08)] transition-all duration-[1100ms] ease-out ${
            i === 0 ? "bg-[#fdf7ea]" : "bg-[#f0e8f8]"
          }`}
        >
          <span className="pointer-events-none absolute inset-x-6 top-4 flex justify-between">
            {Array.from({ length: 14 }).map((_, dot) => (
              <span key={dot} className="h-2.5 w-2.5 rounded-full bg-background/90" />
            ))}
          </span>
          <h2 className="font-display text-3xl font-bold leading-tight text-[#2f2a3a]">
            {card.title}
          </h2>
          <div className="mt-4 text-[17px] leading-8 text-[#4a4458]">{renderBody(card.body)}</div>
        </article>
      ))}
    </div>
  );
}