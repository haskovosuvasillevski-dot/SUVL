import { useEffect, useState } from "react";
import { fetchAdmissionProgress, type ProgressRecord } from "@/lib/priem";

export function AdmissionProgress({ id }: { id: number }) {
  const [record, setRecord] = useState<ProgressRecord | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [width, setWidth] = useState(0);
  const [showNotif, setShowNotif] = useState(false);

  useEffect(() => {
    let active = true;
    fetchAdmissionProgress(id)
      .then((r) => {
        if (!active) return;
        setRecord(r);
        setState(r ? "ready" : "error");
      })
      .catch(() => active && setState("error"));
    return () => {
      active = false;
    };
  }, [id]);

  useEffect(() => {
    if (!record) return;
    const t1 = setTimeout(() => setWidth(record.percent), 300);
    const t2 = setTimeout(() => setShowNotif(true), 1900);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [record]);

  return (
    <section className="flex w-full flex-col items-center overflow-hidden bg-[#0b228b] px-5 py-14 text-center">
      <h1 className="mx-auto mb-4 w-full max-w-[1100px] px-4 font-display text-3xl font-extrabold tracking-wide text-white sm:text-[40px]">
        {state === "loading" ? "Зареждане..." : (record?.title ?? "Прием")}
      </h1>
      {record?.subtitle && (
        <h2 className="mx-auto mb-6 w-full max-w-[1100px] px-4 text-xl font-bold text-[#3ef054] sm:text-[28px]">
          {record.subtitle}
        </h2>
      )}

      <div className="relative mx-auto mb-9 flex h-12 w-full max-w-[950px] items-center overflow-hidden rounded-3xl bg-white shadow-[0_4px_15px_rgba(0,0,0,0.25)]">
        <div
          className="flex h-full items-center whitespace-nowrap rounded-l-3xl bg-[#79ff42] pl-6 transition-[width] duration-[1500ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
          style={{ width: `${width}%` }}
        >
          <span className="text-[15px] font-bold text-black">ЗАПИСАНИ УЧЕНИЦИ</span>
        </div>
        <span className="absolute right-6 z-[2] text-base font-bold text-black">
          {record?.percent ?? 0}%
        </span>
      </div>

      {record?.notifTitle && (
        <div
          className={`mx-auto flex w-full max-w-[1100px] items-start gap-4 rounded-2xl bg-[#ffd6d6] px-7 py-5 text-left shadow-[0_4px_15px_rgba(0,0,0,0.2)] transition-all duration-[600ms] ${
            showNotif ? "scale-100 opacity-100" : "scale-95 opacity-0"
          }`}
        >
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-black font-serif text-lg italic font-bold text-white">
            i
          </span>
          <div>
            <p className="mb-1.5 text-[15px] font-bold leading-snug text-[#111]">
              {record.notifTitle}
            </p>
            {record.notifSubtitle && (
              <p className="text-sm leading-snug text-[#333]">{record.notifSubtitle}</p>
            )}
          </div>
        </div>
      )}
    </section>
  );
}