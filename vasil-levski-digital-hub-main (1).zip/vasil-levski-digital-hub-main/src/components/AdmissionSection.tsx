import { BookOpen } from "lucide-react";
import { Reveal, SectionHeading } from "@/components/Reveal";
const priem1 = "/assets/priem1klas.png";
const priem5 = "/assets/priem5klas.png";
const priem8 = "/assets/priem8klas.png";
const svobodni = "/assets/svobodni.png";

const ITEMS: { img: string; title: string; text: string; href: string; zoom?: string }[] = [
  {
    img: priem1,
    title: "Прием в I клас",
    text: "Начало на знанието и развитието",
    href: "/priem-1-klas",
    zoom: "scale-[1.35]",
  },
  {
    img: priem5,
    title: "Прием в V клас",
    text: "Мост към нови знания и самостоятелност",
    href: "/priem-5-klas",
  },
  {
    img: priem8,
    title: "Прием в VIII клас",
    text: "За нови предизвикателства и успехи",
    href: "/priem-8-klas",
  },
  {
    img: svobodni,
    title: "Свободни места",
    text: "Възможности за всеки ученик",
    href: "/svobodni-mesta",
  },
];

export function AdmissionSection() {
  return (
    <section className="bg-primary py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <SectionHeading
          title="Информация за прием"
          subtitle="Всичко необходимо за кандидатстване в първи, пети и осми клас, както и текущите свободни места."
          icon={<BookOpen className="h-6 w-6" />}
          invert
        />
        <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
          {ITEMS.map((item, i) => (
            <Reveal key={item.title} delay={i * 150}>
              <a
                href={item.href}
                className="flex h-full flex-col rounded-2xl border border-primary-foreground/15 bg-primary-foreground/5 p-6 text-center backdrop-blur transition-all duration-500 hover:-translate-y-1.5 hover:border-gold/60 hover:bg-primary-foreground/10"
              >
                <div className="mx-auto mb-5 flex h-24 w-24 items-center justify-center overflow-hidden">
                  <img
                    src={item.img}
                    alt={item.title}
                    loading="lazy"
                    width={512}
                    height={512}
                    className={`h-full w-full object-contain ${item.zoom ?? ""}`}
                  />
                </div>
                <h3 className="font-display text-base font-bold text-primary-foreground sm:text-lg">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-primary-foreground/75">{item.text}</p>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
