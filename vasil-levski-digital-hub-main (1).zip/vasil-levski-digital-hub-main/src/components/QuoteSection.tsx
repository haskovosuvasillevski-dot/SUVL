import { useEffect, useRef, useState } from "react";
import { fetchQuote } from "@/lib/quote";
import { driveImage } from "@/lib/clubs";

const LINES = [
  "Традиции, изграждани поколения наред.",
  "История, която вдъхновява.",
  "Иновации, които подготвят за бъдещето.",
];

const BODY =
  "СУ „Васил Левски“ – Хасково съчетава богатото наследство на най-старото училище в града със съвременно образование, което развива знания, умения и увереност за успех в един динамичен свят.";

export function QuoteSection() {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);
  const [lines, setLines] = useState<string[]>(LINES);
  const [body, setBody] = useState(BODY);
  const [image, setImage] = useState("");

  useEffect(() => {
    let active = true;
    fetchQuote()
      .then((data) => {
        if (!active || !data) return;
        if (data.lines.length) setLines(data.lines);
        if (data.body) setBody(data.body);
        if (data.image) setImage(driveImage(data.image));
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.25 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={ref}
      className={`relative overflow-hidden py-16 sm:py-28 ${image ? "bg-primary" : "bg-secondary/60"}`}
    >
      {image ? (
        <>
          <div
            aria-hidden
            className="absolute inset-0 bg-cover bg-no-repeat bg-center"
            style={{ backgroundImage: `url(${image})` }}
          />
          <div aria-hidden className="absolute inset-0 bg-primary/35" />
        </>
      ) : null}
      <div className="relative z-10 mx-auto max-w-4xl px-4 lg:px-8">
        <blockquote className="relative text-center">
          <span
            aria-hidden
            className="pointer-events-none block font-display text-6xl leading-none text-gold transition-all duration-[1200ms] ease-out sm:text-7xl"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "scale(1)" : "scale(0.8)",
            }}
          >
            „
          </span>

          {lines.map((line, i) => (
            <p
              key={line}
              className={`font-display text-xl font-bold transition-all duration-[1200ms] ease-out sm:text-3xl ${
                image ? "text-primary-foreground" : "text-primary"
              }`}
              style={{
                opacity: visible ? 1 : 0,
                transform: visible ? "translateY(0)" : "translateY(24px)",
                transitionDelay: `${250 + i * 320}ms`,
              }}
            >
              {line}
            </p>
          ))}

          <span
            className="mx-auto mt-6 block h-1 rounded-full bg-brand-green transition-all duration-[1600ms] ease-out"
            style={{
              width: visible ? "6rem" : "0rem",
              transitionDelay: "1200ms",
            }}
          />

          <p
            className={`mt-6 text-base leading-relaxed transition-all duration-[1200ms] ease-out sm:text-lg ${
              image ? "text-primary-foreground/90" : "text-muted-foreground"
            }`}
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(24px)",
              transitionDelay: "1500ms",
            }}
          >
            {body}
          </p>
        </blockquote>
      </div>
    </section>
  );
}
