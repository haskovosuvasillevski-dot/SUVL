import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Cookie } from "lucide-react";

const STORAGE_KEY = "cookie-consent-v1";

/** Банер за съгласие с бисквитки – показва се веднъж до избор на потребителя. */
export function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      if (!localStorage.getItem(STORAGE_KEY)) setVisible(true);
    } catch {
      setVisible(true);
    }
  }, []);

  const choose = (value: "accepted" | "rejected") => {
    try {
      localStorage.setItem(STORAGE_KEY, value);
    } catch {
      /* ignore */
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-live="polite"
      aria-label="Съгласие за бисквитки"
      className="fixed inset-x-0 bottom-0 z-[10000] border-t border-border bg-card shadow-[0_-8px_30px_rgba(0,0,0,0.18)]"
    >
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 py-4 sm:flex-row sm:gap-6 sm:px-8">
        <div className="flex items-start gap-3">
          <Cookie className="mt-0.5 h-6 w-6 shrink-0 text-gold" aria-hidden="true" />
          <p className="text-sm leading-relaxed text-foreground/90">
            Този сайт използва бисквитки, за да осигури правилната си работа и да
            запомни Вашите предпочитания. Научете повече в нашата{" "}
            <Link to="/biskvitki" className="font-semibold text-primary underline">
              Политика за бисквитки
            </Link>
            .
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-3">
          <button
            type="button"
            onClick={() => choose("rejected")}
            className="rounded-full border border-border px-5 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:bg-secondary"
          >
            Само необходимите
          </button>
          <button
            type="button"
            onClick={() => choose("accepted")}
            className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Приемам
          </button>
        </div>
      </div>
    </div>
  );
}
