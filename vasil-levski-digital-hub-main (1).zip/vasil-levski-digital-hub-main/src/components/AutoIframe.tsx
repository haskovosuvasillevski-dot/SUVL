import { useEffect, useRef, useState } from "react";

/** Вгражда статична HTML страница и я преоразмерява спрямо съдържанието ѝ. */
export function AutoIframe({
  src,
  title,
  minHeight = 300,
  whiteBackground = false,
  css,
}: {
  src: string;
  title: string;
  minHeight?: number;
  whiteBackground?: boolean;
  css?: string;
}) {
  const ref = useRef<HTMLIFrameElement>(null);
  const [height, setHeight] = useState(minHeight);
  const [overlay, setOverlay] = useState(false);

  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      const data = e.data as { type?: string; open?: boolean } | null;
      if (data && data.type === "sabshteniya-modal") setOverlay(!!data.open);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  useEffect(() => {
    if (!overlay) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [overlay]);

  useEffect(() => {
    const frame = ref.current;
    if (!frame) return;
    let observer: ResizeObserver | null = null;

    const sync = () => {
      const doc = frame.contentDocument;
      if (!doc?.body) return;
      const modalActive = doc.body.classList.contains("modal-active");
      if (whiteBackground && !modalActive) {
        doc.documentElement.style.background = "#ffffff";
        doc.body.style.background = "#ffffff";
      } else if (modalActive) {
        doc.documentElement.style.background = "transparent";
        doc.body.style.background = "transparent";
      }
      doc.documentElement.style.minHeight = "0";
      doc.body.style.minHeight = "0";
      if (css && !doc.getElementById("auto-iframe-css")) {
        const style = doc.createElement("style");
        style.id = "auto-iframe-css";
        style.textContent = css;
        doc.head.appendChild(style);
      }
      setHeight(Math.max(minHeight, doc.body.scrollHeight + 24));
      if (!observer) {
        observer = new ResizeObserver(() =>
          setHeight(Math.max(minHeight, doc.body.scrollHeight + 24)),
        );
        observer.observe(doc.body);
      }
    };

    frame.addEventListener("load", sync);
    sync();
    const timer = window.setInterval(sync, 1500);
    return () => {
      frame.removeEventListener("load", sync);
      observer?.disconnect();
      window.clearInterval(timer);
    };
  }, [src, minHeight, whiteBackground, css]);

  return (
    <>
      {/* Докато модалът е отворен, iframe-ът става фиксиран на цял екран;
          запазваме височината му с пласьор, за да не скача съдържанието отдолу. */}
      {overlay && <div style={{ height }} aria-hidden="true" />}
      <iframe
        ref={ref}
        src={src}
        title={title}
        scrolling="no"
        style={overlay ? undefined : { height }}
        className={`border-0 ${whiteBackground && !overlay ? "bg-white" : ""} ${
          overlay ? "fixed inset-0 z-[9999] h-screen w-screen" : "w-full"
        }`}
      />
    </>
  );
}
