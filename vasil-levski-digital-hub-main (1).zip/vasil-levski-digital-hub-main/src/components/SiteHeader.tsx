import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X, ChevronDown, ChevronRight, ChevronLeft, BookOpen } from "lucide-react";
const logoAsset = "/assets/logo-transparent.png";
const logo = logoAsset;

type NavItem = { label: string; href?: string; children?: string[] };

const DIARY_URL = "https://www.shkolo.bg/";

/** Линкове към вече изградените страници. */
const LINKS: Record<string, string> = {
  "Начало": "/",
  "История": "/istoriya",
  "Патрон": "/patrona",
  "Новини": "/novini",
  "Проекти": "/proekti",
  "Галерия": "/galeria",
  "Графици": "/grafitsi",
  "Седмично разписание": "/sedmichno-razpisanie",
  "Учебници": "/uchebnitsi",
  "Права и задължения": "/prava-i-zadalzheniya",
  "Прием в I клас": "/priem-1-klas",
  "Прием в V клас": "/priem-5-klas",
  "Прием в VIII клас": "/priem-8-klas",
  "Свободни места": "/svobodni-mesta",
  "Извънкласни дейности": "/izvunklasni-deynosti",
  "Състезания и олимпиади": "/sastezaniya-i-olimpiadi",
  "Документи": "/dokumenti",
  "Бюджет": "/byudzhet",
  "НВО и ДЗИ": "/nvo-i-dzi",
  "Стипендии": "/stipendii",
  "Учебни планове": "/uchebni-planove",
  "Обедно меню": "/obedno-menyu",
  "Административни услуги": "/administrativni-uslugi",
  "Електронни ресурси": "/elektronni-resursi",
  "Алманах и летописна книга": "/almanah-i-letopis",
  "Материална база": "/materialna-baza",
  "Профил на купувача": "/profil-na-kupuvacha",
  "Форма на обучение": "/forma-na-obuchenie",
  "Онлайн обучение": "/onlain-obuchenie",
  "Екип": "/ekip",
  "Контакти": "/kontakti",
};

const NAV: NavItem[] = [
  { label: "Начало" },
  {
    label: "Училището",
    children: [
      "История",
      "Патрон",
      "Алманах и летописна книга",
      "Екип",
      "Материална база",
      "Документи",
      "Бюджет",
      "Административни услуги",
      "Профил на купувача",
    ],
  },
  {
    label: "За учениците",
    children: [
      "Седмично разписание",
      "Учебни планове",
      "Извънкласни дейности",
      "Права и задължения",
      "Графици",
      "Учебници",
      "Електронни ресурси",
      "Състезания и олимпиади",
      "НВО и ДЗИ",
      "Стипендии",
      "Форма на обучение",
      "Онлайн обучение",
      "Обедно меню",
    ],
  },
  {
    label: "Прием",
    children: [
      "Прием в I клас",
      "Прием в V клас",
      "Прием в VIII клас",
      "Свободни места",
    ],
  },
  { label: "Новини" },
  { label: "Проекти" },
  { label: "Галерия" },
  { label: "Контакти" },
];

const DESKTOP_ORDER = [
  "Начало",
  "Училището",
  "За учениците",
  "Прием",
  "Новини",
  "Проекти",
  "Галерия",
  "Контакти",
];

const NAV_ITEMS: NavItem[] = DESKTOP_ORDER.map(
  (label) => NAV.find((n) => n.label === label) ?? { label },
);

function labelForPath(pathname: string): string {
  if (pathname.startsWith("/novini")) return "Новини";
  if (pathname.startsWith("/proekti")) return "Проекти";
  if (pathname.startsWith("/galeria")) return "Галерия";
  if (pathname.startsWith("/priem-") || pathname.startsWith("/svobodni-mesta"))
    return "Прием";
  if (pathname.startsWith("/kontakti")) return "Контакти";
  if (pathname.startsWith("/sastezaniya-i-olimpiadi")) return "За учениците";
  if (
    pathname.startsWith("/istoriya") ||
    pathname.startsWith("/patrona") ||
    pathname.startsWith("/administrativni-uslugi") ||
    pathname.startsWith("/almanah-i-letopis") ||
    pathname.startsWith("/materialna-baza") ||
    pathname.startsWith("/dokumenti") ||
    pathname.startsWith("/byudzhet") ||
    pathname.startsWith("/profil-na-kupuvacha") ||
    pathname.startsWith("/ekip")
  )
    return "Училището";
  if (
    pathname.startsWith("/grafitsi") ||
    pathname.startsWith("/sedmichno-razpisanie") ||
    pathname.startsWith("/uchebnitsi") ||
    pathname.startsWith("/elektronni-resursi") ||
    pathname.startsWith("/izvunklasni-deynosti") ||
    pathname.startsWith("/prava-i-zadalzheniya") ||
    pathname.startsWith("/stipendii") ||
    pathname.startsWith("/uchebni-planove") ||
    pathname.startsWith("/obedno-menyu") ||
    pathname.startsWith("/forma-na-obuchenie") ||
    pathname.startsWith("/onlain-obuchenie") ||
    pathname.startsWith("/nvo-i-dzi")
  )
    return "За учениците";
  return "Начало";
}

function DiaryButton({ className = "" }: { className?: string }) {
  return (
    <a
      href={DIARY_URL}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center gap-2 rounded-full bg-[#1d4ed8] px-5 py-2.5 font-semibold text-white shadow-sm transition-colors duration-300 hover:bg-[#1e40af] ${className}`}
    >
      <BookOpen className="h-5 w-5 shrink-0" />
      <span>Е-дневник</span>
    </a>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [submenu, setSubmenu] = useState<NavItem | null>(null);
  const [mounted, setMounted] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const active = labelForPath(pathname);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);

  /* Затваряне при смяна на страницата */
  useEffect(() => {
    setOpen(false);
    setSubmenu(null);
  }, [pathname]);

  const closeMenu = () => {
    setOpen(false);
    setSubmenu(null);
  };

  const mobileMenu = (
    <div className="fixed inset-0 z-[9999] flex flex-col overflow-y-auto bg-black lg:hidden">
      <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
        <DiaryButton className="text-base" />
        <button
          type="button"
          aria-label="Затвори менюто"
          onClick={closeMenu}
          className="rounded-md p-2 text-white"
        >
          <X className="h-9 w-9" />
        </button>
      </div>

      <nav className="mx-auto w-full max-w-[520px] px-6 py-6">
        {!submenu && (
          <ul className="flex flex-col divide-y divide-white/10">
            {NAV_ITEMS.map((item) => (
              <li key={item.label}>
                {item.children ? (
                  <button
                    type="button"
                    aria-expanded={false}
                    onClick={() => setSubmenu(item)}
                    className="flex w-full items-center justify-between gap-4 px-2 py-5 text-left text-2xl font-semibold text-white"
                  >
                    <span>{item.label}</span>
                    <ChevronDown className="h-7 w-7 shrink-0 text-white/70" />
                  </button>
                ) : (
                  <Link
                    to={LINKS[item.label] ?? "/"}
                    onClick={closeMenu}
                    className={`block px-2 py-5 text-2xl font-semibold ${
                      active === item.label ? "text-[#fbbf24]" : "text-white"
                    }`}
                  >
                    {item.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>
        )}

        {submenu && (
          <div>
            <button
              type="button"
              onClick={() => setSubmenu(null)}
              className="mb-4 flex w-full items-center gap-4 border-b border-white/15 px-2 pb-4 text-left"
            >
              <ChevronLeft className="h-8 w-8 shrink-0 text-white/70" />
              <span className="text-2xl font-semibold text-white">{submenu.label}</span>
            </button>
            <ul className="flex flex-col divide-y divide-white/10">
              {submenu.children?.map((child) => (
                <li key={child}>
                  <Link
                    to={LINKS[child] ?? "/"}
                    onClick={closeMenu}
                    className={`flex items-center justify-between gap-4 px-2 py-4 text-xl ${
                      pathname === (LINKS[child] ?? "/")
                        ? "font-semibold text-[#fbbf24]"
                        : "text-white/90"
                    }`}
                  >
                    <span>{child}</span>
                    <ChevronRight className="h-6 w-6 shrink-0 text-white/50" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </nav>
    </div>
  );

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
      <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 lg:flex lg:gap-6 lg:px-8">
        <a href="/" className="flex min-w-0 shrink-0 items-center gap-3">
          <img
            src={logo}
            alt="Герб на СУ „Васил Левски“ Хасково"
            width={72}
            height={72}
            className="h-16 w-24 shrink-0 object-contain sm:h-20 sm:w-32 lg:h-16 lg:w-28"
          />
          <span className="min-w-0">
            <span className="block truncate font-display text-base font-bold leading-tight text-primary sm:text-lg">
              СУ „Васил Левски“
            </span>
            <span className="block truncate text-xs uppercase tracking-widest text-muted-foreground">
              град Хасково
            </span>
          </span>
        </a>

        <nav className="hidden flex-1 items-stretch justify-end gap-0 lg:flex">
          {NAV_ITEMS.map((item) => (
            <div key={item.label} className="group relative">
              <Link
                to={LINKS[item.label] ?? "/"}
                className={`relative flex items-center gap-1 whitespace-nowrap px-1.5 py-4 text-[13px] font-semibold transition-colors duration-500 xl:px-2 ${
                  active === item.label
                    ? "text-primary"
                    : "text-muted-foreground hover:text-primary"
                }`}
              >
                {item.label}
                {item.children && <ChevronDown className="h-4 w-4" />}
                <span
                  className={`pointer-events-none absolute inset-x-2 bottom-1 h-[3px] rounded-full bg-accent transition-opacity duration-500 ${
                    active === item.label
                      ? "opacity-100"
                      : "opacity-0 group-hover:opacity-40"
                  }`}
                />
              </Link>
              {item.children && (
                <div className="invisible absolute right-0 top-full z-50 min-w-60 rounded-md border border-border bg-popover py-2 opacity-0 shadow-[var(--shadow-soft)] transition-all duration-500 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                  {item.children.map((child) => (
                    <Link
                      key={child}
                      to={LINKS[child] ?? "/"}
                      className={`block border-l-2 border-transparent px-4 py-2 text-sm transition-colors duration-500 hover:border-accent hover:bg-secondary ${
                        pathname === (LINKS[child] ?? "/")
                          ? "border-accent bg-secondary font-semibold text-primary"
                          : "text-muted-foreground hover:text-primary"
                      }`}
                    >
                      {child}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
          <div className="ml-3 flex items-center">
            <DiaryButton className="text-sm" />
          </div>
        </nav>

        <div className="flex items-center gap-2 lg:hidden">
          <DiaryButton className="px-3 py-2 text-sm" />
          <button
            type="button"
            aria-label="Меню"
            aria-expanded={open}
            onClick={() => {
              setOpen(true);
              setSubmenu(null);
            }}
            className="rounded-md border border-border p-2 text-primary"
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </div>

      {open && mounted && createPortal(mobileMenu, document.body)}
    </header>
  );
}
