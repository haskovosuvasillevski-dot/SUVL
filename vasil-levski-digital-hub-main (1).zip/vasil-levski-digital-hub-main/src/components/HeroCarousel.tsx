import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Volume2, VolumeX } from "lucide-react";
import { fetchHeroSlides, type HeroSlide } from "@/lib/hero";

const IMAGE_DURATION = 10000;

export function HeroCarousel() {
  const [slides, setSlides] = useState<HeroSlide[]>([]);
  const [index, setIndex] = useState(0);
  const [muted, setMuted] = useState(true);
  const paused = false;
  const [progress, setProgress] = useState(0);

  const iframeRefs = useRef<Record<string, HTMLIFrameElement | null>>({});
  const videoRefs = useRef<Record<string, HTMLVideoElement | null>>({});
  const resumeTimes = useRef<Record<string, number>>({});

  useEffect(() => {
    let active = true;
    fetchHeroSlides()
      .then((data) => active && setSlides(data))
      .catch(() => active && setSlides([]));
    return () => {
      active = false;
    };
  }, []);

  const count = slides.length;
  const current = slides[index];

  const go = useCallback(
    (dir: number) => {
      setProgress(0);
      setIndex((i) => (count ? (i + dir + count) % count : 0));
    },
    [count],
  );

  const goTo = (i: number) => {
    setProgress(0);
    setIndex(i);
  };

  /* ---------- Изображения: 10 секунди прогрес ---------- */
  useEffect(() => {
    if (!current || current.type !== "image" || paused) return;
    let raf = 0;
    let last = performance.now();
    let elapsed = progress * IMAGE_DURATION;
    const tick = (now: number) => {
      elapsed += now - last;
      last = now;
      const p = Math.min(elapsed / IMAGE_DURATION, 1);
      setProgress(p);
      if (p >= 1) {
        go(1);
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, current?.type, paused, count]);

  /* ---------- Cloudinary / HTML5 видео ---------- */
  useEffect(() => {
    Object.entries(videoRefs.current).forEach(([id, el]) => {
      if (!el) return;
      if (current?.id === id && current.type === "video") {
        const saved = resumeTimes.current[id];
        if (saved && Math.abs(el.currentTime - saved) > 0.3) el.currentTime = saved;
        el.muted = muted;
        if (paused) el.pause();
        else void el.play().catch(() => undefined);
      } else {
        if (!el.paused) resumeTimes.current[id] = el.currentTime;
        el.pause();
      }
    });
  }, [index, paused, muted, current?.id, current?.type, slides.length]);

  /* ---------- YouTube команди ---------- */
  const ytCommand = useCallback(
    (slideId: string, func: string, args: unknown[] = []) => {
      iframeRefs.current[slideId]?.contentWindow?.postMessage(
        JSON.stringify({ event: "command", func, args }),
        "*",
      );
    },
    [],
  );

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (typeof event.data !== "string" || !event.data.includes("infoDelivery")) return;
      let data: { info?: { currentTime?: number; duration?: number; playerState?: number } };
      try {
        data = JSON.parse(event.data);
      } catch {
        return;
      }
      const info = data.info;
      if (!info || current?.type !== "youtube") return;
      if (typeof info.currentTime === "number") {
        resumeTimes.current[current.id] = info.currentTime;
        if (info.duration && info.duration > 0) {
          setProgress(Math.min(info.currentTime / info.duration, 1));
        }
      }
      if (info.playerState === 0) go(1);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [current?.id, current?.type, go]);

  useEffect(() => {
    slides.forEach((slide) => {
      if (slide.type !== "youtube") return;
      iframeRefs.current[slide.id]?.contentWindow?.postMessage(
        JSON.stringify({ event: "listening" }),
        "*",
      );
      if (slide.id === current?.id) {
        const saved = resumeTimes.current[slide.id];
        if (saved && saved > 0.5) ytCommand(slide.id, "seekTo", [saved, true]);
        if (paused) ytCommand(slide.id, "pauseVideo");
        else ytCommand(slide.id, "playVideo");
      } else {
        ytCommand(slide.id, "pauseVideo");
      }
    });
  }, [index, paused, slides, current?.id, ytCommand]);

  const toggleSound = () => {
    const next = !muted;
    setMuted(next);
    if (current?.type === "youtube") {
      ytCommand(current.id, next ? "mute" : "unMute");
      if (!next) ytCommand(current.id, "setVolume", [100]);
    }
    const el = current ? videoRefs.current[current.id] : null;
    if (el) el.muted = next;
  };

  const hasVideo = current?.type === "youtube" || current?.type === "video";

  return (
    <section className="relative h-[calc(100svh-5.5rem)] min-h-[320px] w-full overflow-hidden bg-black lg:h-[calc(100svh-7rem)]">
      {slides.map((slide, i) => {
        // Тежките медии (YouTube/видео) се монтират само за активния
        // и съседните слайдове — не се теглят всички наведнъж.
        const isActive = i === index;
        const isNear =
          count > 1 &&
          (i === (index + 1) % count || i === (index - 1 + count) % count);
        const renderMedia = slide.type === "image" || isActive || isNear;

        return (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-[1200ms] ease-in-out ${
            isActive ? "opacity-100" : "pointer-events-none opacity-0"
          }`}
        >
          {!renderMedia ? null : slide.type === "youtube" ? (
            <div className="pointer-events-none absolute inset-0 select-none overflow-hidden">
              <iframe
                ref={(el) => {
                  iframeRefs.current[slide.id] = el;
                }}
                title={slide.title || "Видео представяне на училището"}
                className="pointer-events-none absolute left-1/2 top-1/2 h-[56.25vw] min-h-full w-[177.77vh] min-w-full -translate-x-1/2 -translate-y-1/2 border-0 object-cover object-center"
                src={`https://www.youtube-nocookie.com/embed/${slide.videoId}?autoplay=1&mute=1&controls=0&loop=0&playsinline=1&rel=0&modestbranding=1&iv_load_policy=3&disablekb=1&fs=0&showinfo=0&cc_load_policy=0&enablejsapi=1`}
                allow="autoplay; encrypted-media"
                tabIndex={-1}
              />
            </div>
          ) : slide.type === "video" ? (
            <video
              ref={(el) => {
                videoRefs.current[slide.id] = el;
              }}
              className="pointer-events-none h-full w-full object-cover object-center"
              src={slide.src}
              autoPlay
              muted
              playsInline
              preload={isActive ? "auto" : "metadata"}
              onTimeUpdate={(e) => {
                const el = e.currentTarget;
                resumeTimes.current[slide.id] = el.currentTime;
                if (isActive && el.duration > 0) {
                  setProgress(Math.min(el.currentTime / el.duration, 1));
                }
              }}
              onEnded={() => {
                resumeTimes.current[slide.id] = 0;
                if (isActive) go(1);
              }}
            />
          ) : (
            <img
              src={slide.src}
              alt={slide.title || "СУ „Васил Левски“ – Хасково"}
              loading={i === 0 ? "eager" : "lazy"}
              fetchPriority={i === 0 ? "high" : "auto"}
              decoding="async"
              className="h-full w-full object-cover object-center"
            />
          )}

          {(slide.title || slide.subtitle) && (
            <div className="absolute inset-x-0 bottom-16 z-20 mx-auto max-w-4xl px-6 text-center drop-shadow-lg">
              {slide.title && (
                <h2 className="font-display text-2xl font-bold text-primary-foreground sm:text-4xl">
                  {slide.title}
                </h2>
              )}
              {slide.subtitle && (
                <p className="mt-2 text-sm text-primary-foreground/85 sm:text-base">
                  {slide.subtitle}
                </p>
              )}
            </div>
          )}
        </div>
        );
      })}

      {count > 1 && (
        <>
          <button
            type="button"
            aria-label="Предишен слайд"
            onClick={() => go(-1)}
            className="absolute left-3 top-1/2 z-20 -translate-y-1/2 rounded-full border border-primary-foreground/40 bg-primary/40 p-3 text-primary-foreground backdrop-blur transition hover:bg-primary/70 sm:left-6"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            type="button"
            aria-label="Следващ слайд"
            onClick={() => go(1)}
            className="absolute right-3 top-1/2 z-20 -translate-y-1/2 rounded-full border border-primary-foreground/40 bg-primary/40 p-3 text-primary-foreground backdrop-blur transition hover:bg-primary/70 sm:right-6"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </>
      )}

      {hasVideo && (
        <button
          type="button"
          aria-label={muted ? "Включи звука" : "Изключи звука"}
          onClick={toggleSound}
          className="absolute bottom-16 right-4 z-30 rounded-full border border-primary-foreground/40 bg-primary/50 p-3 text-primary-foreground backdrop-blur transition hover:bg-primary/80 sm:right-8"
        >
          {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
        </button>
      )}

      <div className="absolute bottom-8 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2">
        {slides.map((slide, i) => (
          <button
            key={slide.id}
            type="button"
            aria-label={`Слайд ${i + 1}`}
            onClick={() => goTo(i)}
            className={`h-2.5 overflow-hidden rounded-full transition-all duration-500 ${
              i === index ? "w-14 bg-primary-foreground/30" : "w-2.5 bg-primary-foreground/50"
            }`}
          >
            {i === index && (
              <span
                className="block h-full rounded-full bg-accent"
                style={{ width: `${Math.round(progress * 100)}%` }}
              />
            )}
          </button>
        ))}
      </div>
    </section>
  );
}
