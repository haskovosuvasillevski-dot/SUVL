import { useEffect, useRef, useState } from "react";

/** Мека вълнообразна лента, която се „рисува“ при скролване (като на 125su.com). */

const PERIOD = 360;
const REPEATS = 4;
const WIDTH = PERIOD * REPEATS;
const MID = 100;
const AMP = 46;
const THICKNESS = 52;

function buildWave(): string {
  const d: string[] = [`M 0 ${MID}`];
  for (let i = 0; i < REPEATS; i++) {
    const x0 = i * PERIOD;
    const dir = i % 2 === 0 ? -1 : 1;
    const cy = MID + dir * AMP;
    d.push(`C ${x0 + PERIOD / 3} ${cy}, ${x0 + (PERIOD * 2) / 3} ${cy}, ${x0 + PERIOD} ${MID}`);
  }
  return d.join(" ");
}

const WAVE = buildWave();

export function RiverSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [drawn, setDrawn] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setDrawn(true);
          io.disconnect();
        }
      },
      { threshold: 0.25 },
    );
    io.observe(node);
    return () => io.disconnect();
  }, []);

  return (
    <section
      aria-hidden="true"
      ref={ref}
      className="relative w-full overflow-hidden bg-background py-4 sm:py-6"
    >
      <div className="h-16 w-full sm:h-24 lg:h-28">
        <svg
          viewBox={`0 ${MID - AMP - THICKNESS / 2} ${WIDTH} ${(AMP + THICKNESS / 2) * 2}`}
          preserveAspectRatio="none"
          className="block h-full w-full"
        >
          <path
            d={WAVE}
            fill="none"
            stroke="var(--river-soft)"
            strokeWidth={THICKNESS}
            strokeLinecap="round"
            pathLength={1}
            style={{
              strokeDasharray: 1,
              strokeDashoffset: drawn ? 0 : 1,
              transition: "stroke-dashoffset 3.2s ease-in-out",
            }}
          />
        </svg>
      </div>
    </section>
  );
}
