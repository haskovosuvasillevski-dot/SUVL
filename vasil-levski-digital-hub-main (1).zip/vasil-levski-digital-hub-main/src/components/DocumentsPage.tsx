import { useEffect, useState } from "react";
import { Download, X, type LucideIcon } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Reveal } from "@/components/Reveal";
import { PageHero } from "@/components/PageShell";
import { getDownloadUrl, getPreviewUrl } from "@/lib/adminServices";
import { fetchDocSheet, groupByYear, type DocGroup, type DocItem } from "@/lib/docsSheets";

function DocModal({ doc, onClose }: { doc: DocItem | null; onClose: () => void }) {
  useEffect(() => {
    if (!doc) return;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      document.removeEventListener("keydown", onKey);
    };
  }, [doc, onClose]);

  if (!doc) return null;

  return (
    <div
      className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/78 p-0 sm:p-6"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-white shadow-2xl sm:h-[92vh] sm:w-[95vw] sm:max-w-5xl sm:rounded">
        <div className="flex min-h-[58px] items-center justify-between gap-4 bg-primary px-3 py-2 text-primary-foreground sm:min-h-[64px] sm:px-5">
          <div className="min-w-0 flex-1 truncate text-sm font-medium sm:text-lg">
            {doc.title}
          </div>
          <div className="flex items-center gap-2">
            <a
              href={getDownloadUrl(doc.file)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-9 items-center justify-center gap-2 rounded-sm bg-white px-3 text-xs font-semibold text-primary hover:bg-secondary sm:h-10 sm:px-4 sm:text-sm"
            >
              <Download className="h-4 w-4" />
              Изтегляне
            </a>
            <button
              type="button"
              aria-label="Затвори"
              onClick={onClose}
              className="flex h-9 w-9 items-center justify-center rounded-sm bg-white/10 hover:bg-white/25 sm:h-10 sm:w-10"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        <iframe
          title="Преглед на документа"
          src={getPreviewUrl(doc.file)}
          className="min-h-0 w-full flex-1 border-0 bg-secondary"
        />
      </div>
    </div>
  );
}

function DocRow({
  doc,
  onOpen,
  delay,
}: {
  doc: DocItem;
  onOpen: (d: DocItem) => void;
  delay: number;
}) {
  const hasFile = Boolean(doc.file);
  return (
    <Reveal delay={delay}>
      <article className="mb-10 flex w-full items-start">
        <div
          role={hasFile ? "button" : undefined}
          tabIndex={hasFile ? 0 : -1}
          onClick={() => hasFile && onOpen(doc)}
          onKeyDown={(e) => {
            if (hasFile && (e.key === "Enter" || e.key === " ")) onOpen(doc);
          }}
          title={hasFile ? "Преглед и изтегляне" : undefined}
          className={`mr-6 flex h-[76px] w-[76px] flex-none items-center justify-center rounded-full bg-primary sm:mr-10 ${
            hasFile
              ? "cursor-pointer transition-transform duration-200 hover:scale-[1.06] hover:bg-primary/90"
              : ""
          }`}
        >
          <Download className="h-8 w-8 text-primary-foreground" />
        </div>
        <div className="min-w-0 flex-1 pt-4 sm:pt-5">
          {hasFile ? (
            <button
              type="button"
              onClick={() => onOpen(doc)}
              className="inline-block text-left text-lg font-medium leading-relaxed text-primary underline decoration-1 underline-offset-4 transition-colors hover:text-primary/80 sm:text-xl"
            >
              {doc.title}
            </button>
          ) : (
            <span className="inline-block text-lg font-medium leading-relaxed text-primary sm:text-xl">
              {doc.title}
            </span>
          )}
          {doc.information && (
            <div className="mt-2.5 max-w-3xl text-sm leading-relaxed text-muted-foreground sm:text-base">
              {doc.information}
            </div>
          )}
        </div>
      </article>
    </Reveal>
  );
}

export function DocumentsPage({
  heading,
  heroUrl,
  sheetId,
  groupYears = false,
  icon: Icon,
}: {
  heading: string;
  heroUrl: string;
  sheetId: string;
  groupYears?: boolean;
  icon?: LucideIcon;
}) {
  const [items, setItems] = useState<DocItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [active, setActive] = useState<DocItem | null>(null);

  useEffect(() => {
    let alive = true;
    fetchDocSheet(sheetId)
      .then((data) => alive && setItems(data))
      .catch((err) => alive && setError(err?.message || "Неуспешно зареждане."));
    return () => {
      alive = false;
    };
  }, [sheetId]);

  const groups: DocGroup[] | null = items
    ? groupYears
      ? groupByYear(items)
      : [{ year: "", items }]
    : null;

  return (
    <div className="min-h-screen bg-background font-body">
      <SiteHeader />
      <main id="main-content">
        <PageHero title={heading} image={heroUrl} icon={Icon ? <Icon /> : undefined} />

        <div className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-20">
          {!items && !error && (
            <p className="w-full py-11 text-center text-base text-muted-foreground">
              Зареждане...
            </p>
          )}

          {error && (
            <Reveal>
              <div className="mx-auto max-w-2xl rounded border border-border bg-secondary/40 p-6 text-center leading-relaxed text-muted-foreground">
                <strong className="text-primary">Неуспешно зареждане на данните.</strong>
                <br />
                <br />
                {error}
              </div>
            </Reveal>
          )}

          {items && items.length === 0 && !error && (
            <p className="w-full py-11 text-center text-base text-muted-foreground">
              Няма налични документи.
            </p>
          )}

          {groups?.map((group) => (
            <section key={group.year || "all"}>
              {groupYears && group.year && (
                <Reveal>
                  <h2 className="mb-8 mt-2 text-center font-display text-2xl font-bold uppercase tracking-wide text-primary sm:text-3xl">
                    {group.year}
                  </h2>
                </Reveal>
              )}
              {group.items.map((doc, i) => (
                <DocRow
                  key={`${group.year}-${doc.id || doc.title}-${i}`}
                  doc={doc}
                  onOpen={setActive}
                  delay={Math.min(i * 60, 400)}
                />
              ))}
            </section>
          ))}
        </div>
      </main>
      <SiteFooter />

      <DocModal doc={active} onClose={() => setActive(null)} />
    </div>
  );
}
