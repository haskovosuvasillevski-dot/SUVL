import { useEffect, useRef, useState } from "react";
const circleBlue = "/assets/output-onlinepngtools2.png";
const circleGold = "/assets/output-onlinepngtools1.png";
const circleMixed = "/assets/output-onlinepngtools.png";
import { fetchStats, FALLBACK_STATS, type StatItem } from "@/lib/stats";

type Stat = {
  target: number;
  prefix?: string;
  delimiter?: string;
  label: string;
  circle: string;
};

const CIRCLES = [circleBlue, circleGold, circleMixed, circleGold, circleBlue];

const toStats = (items: StatItem[]): Stat[] =>
  items.map((item, i) => {
    const stat: Stat = {
      target: item.value,
      prefix: item.prefix,
      label: item.label.replace(/\s+/, "\n"),
      circle: CIRCLES[i % CIRCLES.length] as string,
    };
    if (item.value >= 10000) stat.delimiter = " ";
    return stat;
  });

const format = (n: number, delimiter?: string) =>
  delimiter ? n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, delimiter) : String(n);

export function CountUpSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [started, setStarted] = useState(false);
  const [stats, setStats] = useState<Stat[]>(() => toStats(FALLBACK_STATS));
  const [values, setValues] = useState<number[]>(() => FALLBACK_STATS.map(() => 0));

  useEffect(() => {
    let active = true;
    fetchStats()
      .then((items) => {
        if (!active) return;
        setStats(toStats(items));
        setValues(items.map(() => 0));
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setStarted(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    const duration = 3000;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      setValues(stats.map((s) => Math.ceil(s.target * p)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, stats]);

  return (
    <section ref={sectionRef} className="bg-background pb-8 pt-14 sm:pb-10 sm:pt-20">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <h1 className="relative mx-auto w-fit pb-5 text-center font-display text-3xl font-bold text-primary sm:text-5xl">
          За СУ „Васил Левски“
          <span className="pointer-events-none absolute inset-x-0 bottom-0 h-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 550 40"
              preserveAspectRatio="none"
              className="block h-full w-full overflow-visible"
            >
              <path
                d="M3,20 C50,5 100,35 150,20 C200,5 250,35 300,20 C350,5 400,35 450,20 C500,5 530,25 550,20"
                fill="none"
                stroke="var(--brand-green)"
                strokeWidth={5}
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeDasharray={600}
                strokeDashoffset={started ? 0 : 600}
                style={{ transition: "stroke-dashoffset 3s ease-in-out" }}
              />
            </svg>
          </span>
        </h1>

        <div className="mt-12 flex flex-wrap justify-center gap-y-6">
          {stats.map((stat, i) => (
            <div
              key={stat.label}
              className="flex w-1/3 justify-center px-1 sm:px-3 lg:w-1/5"
            >
              <div
                className="flex aspect-square w-full max-w-[180px] items-center justify-center bg-contain bg-center bg-no-repeat"
                style={{ backgroundImage: `url(${stat.circle})` }}
              >
                <div className="flex flex-col items-center justify-center text-center">
                  <div className="flex items-baseline justify-center text-[1.35rem] leading-tight text-foreground sm:text-[2.2rem]">
                    {stat.prefix}
                    {format(values[i] ?? 0, stat.delimiter)}
                  </div>
                  <span className="mt-1 whitespace-pre-line text-[0.8rem] leading-tight text-muted-foreground sm:text-base">
                    {stat.label}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}