import { useEffect, useState } from "react";
import { Images, Play } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { Lightbox } from "@/components/Lightbox";
import { fetchAdmissionMedia, type MediaItem } from "@/lib/priem";

export function AdmissionGallery({ page, title = "Галерия" }: { page: string; title?: string }) {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [video, setVideo] = useState<string | null>(null);
  const [lightbox, setLightbox] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    fetchAdmissionMedia(page)
      .then((data) => active && setItems(data))
      .catch(() => active && setItems([]));
    return () => {
      active = false;
    };
  }, [page]);

  const images = items.filter((i) => i.type === "image").map((i) => i.src);

  if (items.length === 0) return null;

  return (
    <section className="bg-secondary/50 py-14">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {items.map((item, i) => (
            <Reveal key={item.id} delay={(i % 2) * 120}>
              <button
                type="button"
                onClick={() =>
                  item.type === "youtube"
                    ? setVideo(item.src)
                    : setLightbox(images.indexOf(item.src))
                }
                className="group relative block aspect-[4/3] w-full overflow-hidden rounded-xl border border-border bg-black shadow-[var(--shadow-soft)]"
              >
                <img
                  src={
                    item.type === "youtube"
                      ? `https://img.youtube.com/vi/${item.src}/hqdefault.jpg`
                      : item.src
                  }
                  alt={title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <span className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/25 opacity-0 transition-opacity duration-500 group-hover:opacity-100">
                  <span className="rounded-full bg-white/90 p-3 text-primary">
                    {item.type === "youtube" ? (
                      <Play className="h-6 w-6" />
                    ) : (
                      <Images className="h-6 w-6" />
                    )}
                  </span>
                </span>
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      {lightbox !== null && images.length > 0 && (
        <Lightbox
          images={images}
          index={lightbox}
          onChange={setLightbox}
          onClose={() => setLightbox(null)}
        />
      )}

      {video && (
        <div
          className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/90 p-4"
          onClick={() => setVideo(null)}
          role="dialog"
          aria-modal="true"
        >
          <div className="aspect-video w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
            <iframe
              src={`https://www.youtube.com/embed/${video}?autoplay=1&rel=0`}
              title="Видео"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="h-full w-full rounded-xl"
            />
          </div>
        </div>
      )}
    </section>
  );
}