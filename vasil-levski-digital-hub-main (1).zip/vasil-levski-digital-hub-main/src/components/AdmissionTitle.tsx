/**
 * Заглавие с подчертан текст. Думата от колона G се оцветява в златно,
 * а двете линии подчертават само нея (разтеглят се до цялата ѝ ширина).
 */
export function AdmissionTitle({
  title,
  highlightWord,
  academicYear,
}: {
  title: string;
  highlightWord: string;
  academicYear?: string;
}) {
  const word = highlightWord?.trim() ?? "";
  const hasHighlight = word.length > 0 && title.includes(word);
  const index = hasHighlight ? title.indexOf(word) : -1;
  const before = hasHighlight ? title.slice(0, index) : title;
  const after = hasHighlight ? title.slice(index + word.length) : "";

  const underline = (
    <svg
      className="pointer-events-none absolute -bottom-3 left-0 h-[22px] w-full overflow-visible"
      viewBox="0 0 200 20"
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <path className="admission-underline" d="M 2,5 Q 100,1 198,4" />
      <path className="admission-underline" d="M 2,13 Q 100,9 198,12" />
    </svg>
  );

  return (
    <div className="mb-10 font-display text-[32px] font-extrabold leading-[1.35] text-primary sm:text-[42px]">
      <span className={hasHighlight ? "" : "relative inline-block max-w-full"}>
        <span>{before}</span>
        {hasHighlight && (
          <span className="relative inline-block text-gold">
            {word}
            {underline}
          </span>
        )}
        <span>{after}</span>
        {academicYear && <span className="ml-2">{academicYear}</span>}
        {!hasHighlight && underline}
      </span>
    </div>
  );
}
