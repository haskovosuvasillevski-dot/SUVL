import { useEffect, useState } from "react";

/**
 * Начален екран за зареждане с анимирана книга.
 * Показва се при първо зареждане, изчезва плавно след window.load
 * (мин. ~1s, макс. 3.5s failsafe). Не влияе на останалите ефекти.
 */
export function PageLoader() {
  const [fading, setFading] = useState(false);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    const start = Date.now();
    let fadeTimer = 0;

    const finish = () => {
      const wait = Math.max(0, 1000 - (Date.now() - start));
      fadeTimer = window.setTimeout(() => setFading(true), wait);
    };

    if (document.readyState === "complete") {
      finish();
    } else {
      window.addEventListener("load", finish, { once: true });
    }
    const failsafe = window.setTimeout(() => setFading(true), 3500);

    return () => {
      window.removeEventListener("load", finish);
      window.clearTimeout(fadeTimer);
      window.clearTimeout(failsafe);
    };
  }, []);

  useEffect(() => {
    if (!fading) return;
    const t = window.setTimeout(() => setGone(true), 750);
    return () => window.clearTimeout(t);
  }, [fading]);

  if (gone) return null;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-[99998] flex flex-col items-center justify-center gap-8 bg-background transition-opacity duration-700 ${
        fading ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
    >
      <div className="pl-book" role="presentation">
        <span className="pl-side pl-left" />
        <span className="pl-side pl-right" />
        <span className="pl-page" style={{ animationDelay: "0s" }} />
        <span className="pl-page" style={{ animationDelay: "0.35s" }} />
        <span className="pl-page" style={{ animationDelay: "0.7s" }} />
        <span className="pl-page" style={{ animationDelay: "1.05s" }} />
      </div>
      <div className="flex flex-col items-center gap-2 px-6 text-center">
        <p className="font-display text-lg font-bold tracking-wide text-primary sm:text-xl">
          СУ „Васил Левски“ – Хасково
        </p>
        <p className="pl-dots text-sm font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          Зареждане
        </p>
      </div>
    </div>
  );
}
