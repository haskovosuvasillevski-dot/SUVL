import { parseCSV } from "@/lib/news";
import { fetchSheetText } from "@/lib/sheetCache";

export type StatItem = {
  key: string;
  value: number;
  prefix: string;
  label: string;
};

const SPREADSHEET_ID = "1OPscKFlR-jzwQ5LwQblFeOVGxcNVWjCNf8XMSG59bPs";
export const STATS_CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv`;

export const FALLBACK_STATS: StatItem[] = [
  { key: "years_experience", value: 180, prefix: "", label: "години опит" },
  { key: "teachers", value: 79, prefix: "", label: "учители" },
  { key: "subjects", value: 110, prefix: "+", label: "предмети" },
  { key: "students", value: 757, prefix: "+", label: "ученици" },
  { key: "hours", value: 50000, prefix: "+", label: "учебни часове" },
];

function normalizePrefix(raw: string): string {
  const v = (raw || "").trim().toLowerCase();
  if (!v || v === "(празно)" || v === "-") return "";
  if (v === "plus" || v === "+") return "+";
  if (v === "minus") return "-";
  return raw.trim();
}

export async function fetchStats(): Promise<StatItem[]> {
  const rows = parseCSV(await fetchSheetText(STATS_CSV_URL)).slice(1);

  const items = rows
    .map((row) => ({
      key: (row[0] || "").trim(),
      value: parseInt((row[1] || "").replace(/[^\d-]/g, ""), 10),
      prefix: normalizePrefix(row[2] || ""),
      label: (row[3] || "").trim(),
    }))
    .filter((s) => s.key && s.label && !Number.isNaN(s.value));

  return items.length ? items : FALLBACK_STATS;
}