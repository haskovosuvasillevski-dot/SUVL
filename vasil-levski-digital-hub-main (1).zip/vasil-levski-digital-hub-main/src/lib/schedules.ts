import { fetchSheetText } from "@/lib/sheetCache";

export type ScheduleItem = {
  title: string;
  term: string;
  classes: string;
  link: string;
};

const SPREADSHEET_ID = "184C8LbUw1sj7AeQzfovPGbmUyTB-hZU0coF6xzkea34";
const GVIZ_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:json`;

function cellValue(cell: { f?: unknown; v?: unknown } | null | undefined): string {
  if (!cell) return "";
  if (cell.f !== undefined && cell.f !== null) return String(cell.f).trim();
  if (cell.v !== undefined && cell.v !== null) return String(cell.v).trim();
  return "";
}

export function getDriveFileId(url: string): string | null {
  const u = (url || "").trim();
  if (!u) return null;
  const m1 = u.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (m1?.[1]) return m1[1];
  const m2 = u.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (m2?.[1]) return m2[1];
  if (/^[a-zA-Z0-9_-]+$/.test(u)) return u;
  return null;
}

export function getPreviewUrl(url: string): string {
  const id = getDriveFileId(url);
  return id ? `https://drive.google.com/file/d/${id}/preview` : url;
}

export function getDownloadUrl(url: string): string {
  const id = getDriveFileId(url);
  return id ? `https://drive.google.com/uc?export=download&id=${id}` : url;
}

export async function fetchSchedules(): Promise<ScheduleItem[]> {
  const text = await fetchSheetText(GVIZ_URL);
  const json = JSON.parse(text.substring(text.indexOf("{"), text.lastIndexOf("}") + 1));
  const rows = (json?.table?.rows ?? []) as { c?: ({ f?: unknown; v?: unknown } | null)[] }[];

  return rows
    .map((row) => {
      const c = row.c ?? [];
      return {
        title: cellValue(c[0]),
        term: cellValue(c[1]),
        classes: cellValue(c[2]),
        link: cellValue(c[3]),
      };
    })
    .filter((item) => item.link && (item.title || item.classes));
}