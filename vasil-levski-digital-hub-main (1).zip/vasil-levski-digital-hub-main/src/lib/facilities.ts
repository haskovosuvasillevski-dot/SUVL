import { parseCSV } from "@/lib/news";
import { imageUrl, splitList } from "@/lib/projects";
import { fetchSheetText } from "@/lib/sheetCache";

export type Facility = {
  id: string;
  title: string;
  image: string;
  content: string;
  images: string[];
  videos: string[];
};

const SPREADSHEET_ID = "1F0zULtFPuLZMKicCQzzw5JfdkJmNe7YA8IwTnlwlrG0";
const CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv`;

export async function fetchFacilities(): Promise<Facility[]> {
  const rows = parseCSV(await fetchSheetText(CSV_URL)).slice(1);

  return rows
    .map((row, index) => ({
      id: String(index + 1),
      title: (row[0] || "").trim(),
      image: imageUrl(row[1] || ""),
      content: row[2] || "",
      images: splitList(row[3] || "").map(imageUrl),
      videos: splitList(row[4] || ""),
    }))
    .filter((f) => f.title);
}
