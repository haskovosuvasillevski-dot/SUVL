/** Помощни функции и заявки за страниците „Прием“. */
import { fetchSheetText } from "@/lib/sheetCache";

export type ProgressRecord = {
  id: number;
  title: string;
  subtitle: string;
  percent: number;
  notifTitle: string;
  notifSubtitle: string;
};

export type MediaItem = { type: "image" | "youtube"; src: string; id: string };

const PROGRESS_SHEET = "1NPU3ks83FYn5ujUmvGqQl2wp6dG7-qfQsxKhCO10ssE";
const GALLERY_SHEET = "1vvJ7Tt4jb_e0iC1xhCkdwjCjOWQkQRIBEJUM63V2y5c";

type Cell = { v?: unknown; f?: unknown } | null | undefined;
type GRow = { c: Cell[] };

export function cellText(cell: Cell): string {
  if (!cell) return "";
  if (cell.v !== undefined && cell.v !== null) return String(cell.v).trim();
  return "";
}

export async function gvizRows(sheetId: string): Promise<GRow[]> {
  const text = await fetchSheetText(
    `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:json`,
  );
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("Невалиден отговор от Google Sheets");
  const json = JSON.parse(text.substring(start, end + 1));
  return (json?.table?.rows ?? []) as GRow[];
}

export function driveFileId(url: string): string {
  const raw = (url || "").trim();
  const m =
    raw.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/) ||
    raw.match(/[?&]id=([a-zA-Z0-9_-]{10,})/);
  return m?.[1] ?? "";
}

export function driveImageUrl(url: string): string {
  const id = driveFileId(url);
  return id ? `https://lh3.googleusercontent.com/d/${id}=w2000` : (url || "").trim();
}

export function youtubeId(url: string): string {
  const raw = (url || "").trim();
  const m =
    raw.match(/[?&]v=([a-zA-Z0-9_-]{11})/) ||
    raw.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/) ||
    raw.match(/youtube\.com\/(?:embed|shorts|live)\/([a-zA-Z0-9_-]{11})/);
  return m?.[1] ?? "";
}

function toMedia(url: string, key: string): MediaItem | null {
  const raw = (url || "").trim();
  if (!raw) return null;
  const yt = youtubeId(raw);
  if (yt) return { type: "youtube", src: yt, id: key };
  const img = driveImageUrl(raw);
  return img ? { type: "image", src: img, id: key } : null;
}

/** Ред 1 = Прием 1 клас, 2 = Прием 5 клас, 3 = Прием 8 клас. */
export async function fetchAdmissionProgress(id: number): Promise<ProgressRecord | null> {
  const rows = await gvizRows(PROGRESS_SHEET);
  for (const row of rows) {
    const c = row?.c ?? [];
    if (Number(cellText(c[0])) !== id) continue;
    return {
      id,
      title: cellText(c[1]),
      subtitle: cellText(c[2]),
      percent: Math.max(0, Math.min(100, Number(cellText(c[3])) || 0)),
      notifTitle: cellText(c[4]),
      notifSubtitle: cellText(c[5]),
    };
  }
  return null;
}

/** Взима медията (колони B и C) за дадена страница от колона A. */
export async function fetchAdmissionMedia(pageName: string): Promise<MediaItem[]> {
  const rows = await gvizRows(GALLERY_SHEET);
  const wanted = pageName.trim().toLowerCase();
  const items: MediaItem[] = [];
  rows.forEach((row, i) => {
    const c = row?.c ?? [];
    if (cellText(c[0]).toLowerCase() !== wanted) return;
    [1, 2].forEach((col) => {
      const media = toMedia(cellText(c[col]), `${i}-${col}`);
      if (media) items.push(media);
    });
  });
  return items;
}