import { cellText, driveFileId, gvizRows } from "@/lib/priem";

const EXAM_SHEET = "1wIF2289RA2SPEBdI_37-CS50huzdb-neKnSJO6moN7A";

export type ExamPage = {
  title: string;
  description: string;
  images: Array<{ view: string; download: string }>;
  files: Array<{ preview: string; download: string }>;
};

export const EXAM_PAGES = [
  "НВО 4 КЛАС",
  "НВО 7 КЛАС",
  "НВО 10 КЛАС",
  "ДЗИ 12 КЛАС",
] as const;

export async function fetchExamPage(pageName: string): Promise<ExamPage | null> {
  const rows = await gvizRows(EXAM_SHEET);
  const wanted = pageName.trim().toLowerCase();
  const matched = rows.filter((row) => {
    const name = cellText(row?.c?.[0]).toLowerCase();
    return name === wanted || name.startsWith(wanted);
  });
  if (matched.length === 0) return null;

  const page: ExamPage = {
    title: cellText(matched[0]?.c?.[1]) || pageName,
    description: "",
    images: [],
    files: [],
  };

  for (const row of matched) {
    const c = row?.c ?? [];
    if (!page.description) page.description = cellText(c[2]);

    /* Няколко изображения се отделят със запетая. */
    cellText(c[3])
      .split(",")
      .map((part) => driveFileId(part))
      .filter(Boolean)
      .forEach((imageId) => {
        page.images.push({
          view: `https://lh3.googleusercontent.com/d/${imageId}=w1600`,
          download: `https://drive.google.com/uc?export=download&id=${imageId}`,
        });
      });

    cellText(c[4])
      .split(",")
      .map((f) => driveFileId(f))
      .filter(Boolean)
      .forEach((id) => {
        page.files.push({
          preview: `https://drive.google.com/file/d/${id}/preview`,
          download: `https://drive.google.com/uc?export=download&id=${id}`,
        });
      });
  }

  if (!page.title || page.title === "null") page.title = pageName;
  return page;
}
