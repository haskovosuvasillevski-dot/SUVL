import { fetchSheetText } from "@/lib/sheetCache";

export type QuoteData = { lines: string[]; body: string; image: string };

const SHEET_ID = "1IjXbzGcJLbruQTk_AChB6m1At4_JkBUam72vDvAfb5k";

export async function fetchQuote(): Promise<QuoteData | null> {
  const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json`;
  const text = await fetchSheetText(url);
  const data = JSON.parse(text.substring(text.indexOf("{"), text.lastIndexOf("}") + 1));
  const rows: { c: ({ v: unknown } | null)[] }[] = data?.table?.rows ?? [];
  const row = rows[1];
  if (!row) return null;
  const g = (i: number) => {
    const cell = row.c?.[i];
    return cell && cell.v != null ? String(cell.v).trim() : "";
  };
  const lines = g(0)
    .split(/\n+/)
    .map((l) => l.trim())
    .filter(Boolean);
  return { lines, body: g(1), image: g(2) };
}
