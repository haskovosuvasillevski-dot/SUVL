import { parseCSV } from "@/lib/news";
import { driveId, driveImage } from "@/lib/clubs";
import { fetchSheetText } from "@/lib/sheetCache";

export type Olympiad = {
  id: number;
  title: string;
  image: string;
  rawDate: string;
  place: string;
  content: string;
  link: string;
  doc: string;
};

export type SchoolCompetition = {
  id: number;
  image: string;
  title: string;
  rawDate: string;
  date: Date;
  gallery: string[];
  content: string;
  author: string;
};

const OLYMPIADS_ID = "1eLWR61hPR3DitTl1ww1FP_Rz9q2GWLek01B8hJ89oQ4";
const SCHOOL_ID = "1enXZrVvQ7jGapGMYV8sF_LZEL8ondldM6aX7Bzb1Z2Y";

const csv = (id: string) =>
  `https://docs.google.com/spreadsheets/d/${id}/export?format=csv`;

function media(url: string): string {
  const raw = String(url || "").trim();
  if (!raw) return "";
  return raw.includes("drive.google.com") ? driveImage(raw) : raw;
}

/** Преглед на документ (Drive или директен линк). */
export function docUrl(url: string): string {
  const raw = String(url || "").trim();
  if (!raw) return "";
  const id = driveId(raw);
  return id && raw.includes("drive.google.com")
    ? `https://drive.google.com/file/d/${id}/view`
    : raw;
}

function parseDate(value: string): Date {
  const v = (value || "").trim();
  if (!v) return new Date(0);
  const parts = v.split(/[/.-]/);
  if (parts.length === 3) {
    const [d, m, y] = parts.map((p) => parseInt(p, 10));
    if (d && m && y) return new Date(y, m - 1, d);
  }
  const parsed = Date.parse(v);
  return isNaN(parsed) ? new Date(0) : new Date(parsed);
}

export async function fetchOlympiads(): Promise<Olympiad[]> {
  return parseCSV(await fetchSheetText(csv(OLYMPIADS_ID)))
    .slice(1)
    .map((row, index) => ({
      id: index,
      title: (row[0] || "").trim(),
      image: media(row[1] || ""),
      rawDate: (row[2] || "").trim(),
      place: (row[3] || "").trim(),
      content: row[4] || "",
      link: (row[5] || "").trim(),
      doc: (row[6] || "").trim(),
    }))
    .filter((o) => o.title);
}

export async function fetchSchoolCompetitions(): Promise<SchoolCompetition[]> {
  return parseCSV(await fetchSheetText(csv(SCHOOL_ID)))
    .slice(1)
    .map((row, index) => ({
      id: index,
      image: media(row[0] || ""),
      title: (row[1] || "").trim(),
      rawDate: (row[2] || "").trim(),
      date: parseDate(row[2] || ""),
      gallery: (row[3] || "")
        .split(/[\n,]+/)
        .map((s) => media(s))
        .filter(Boolean),
      content: row[4] || "",
      author: (row[5] || "").trim(),
    }))
    .filter((c) => c.title)
    .sort((a, b) => b.date.getTime() - a.date.getTime());
}
