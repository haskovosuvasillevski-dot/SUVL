import { fetchSheetText } from "@/lib/sheetCache";

export type NewsItem = {
  id: number;
  imageUrl: string;
  title: string;
  rawDate: string;
  gallery: string[];
  content: string;
  author: string;
  date: Date;
};

const SPREADSHEET_ID = "1K_6XZ4C4Ce-b3FosXO_Nz9tczTkBn7mH0HLz-qkc7Mo";
export const NEWS_CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv`;

export function fixDriveUrl(url: string): string {
  const u = (url || "").trim();
  if (!u) return "";
  const m1 = u.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (u.includes("drive.google.com") && m1) {
    return `https://lh3.googleusercontent.com/d/${m1[1]}`;
  }
  const m2 = u.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (u.includes("drive.google.com") && m2) {
    return `https://lh3.googleusercontent.com/d/${m2[1]}`;
  }
  return u;
}

/** RFC4180-compatible parser: keeps newlines inside quoted fields. */
export function parseCSV(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  const src = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");

  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (inQuotes) {
      if (c === '"') {
        if (src[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ",") {
      row.push(field);
      field = "";
    } else if (c === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += c;
    }
  }
  row.push(field);
  rows.push(row);
  return rows;
}

function parseDate(value: string): Date {
  if (!value) return new Date(0);
  const parts = value.trim().split(/[/.-]/);
  if (parts.length === 3) {
    const nums = parts.map((p) => parseInt(p, 10));
    const d = nums[0] ?? NaN;
    const m = nums[1] ?? NaN;
    const y = nums[2] ?? NaN;
    if (!isNaN(d) && !isNaN(m) && !isNaN(y)) return new Date(y, m - 1, d);
  }
  const parsed = Date.parse(value);
  return isNaN(parsed) ? new Date(0) : new Date(parsed);
}

export async function fetchNews(): Promise<NewsItem[]> {
  const rows = parseCSV(await fetchSheetText(NEWS_CSV_URL)).slice(1);

  return rows
    .map((row, index) => {
      const gallery = (row[3] || "")
        .split(",")
        .map((s) => fixDriveUrl(s))
        .filter(Boolean);
      return {
        id: index,
        imageUrl: fixDriveUrl(row[0] || ""),
        title: (row[1] || "").trim(),
        rawDate: (row[2] || "").trim(),
        gallery,
        content: row[4] || "",
        author: (row[5] || "").trim(),
        date: parseDate(row[2] || ""),
      };
    })
    .filter((n) => n.title !== "")
    .sort((a, b) => b.date.getTime() - a.date.getTime());
}