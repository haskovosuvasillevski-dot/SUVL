import { getFileUrl } from "@/lib/adminServices";
import { fetchSheetText } from "@/lib/sheetCache";

export type DocItem = {
  id: string;
  title: string;
  file: string;
  information: string;
  date: string;
};

export type DocGroup = { year: string; items: DocItem[] };

type Cell = { v?: unknown; f?: unknown } | null | undefined;

function cellValue(cell: Cell): string {
  if (!cell) return "";
  if (cell.f !== undefined && cell.f !== null) return String(cell.f).trim();
  if (cell.v !== undefined && cell.v !== null) return String(cell.v).trim();
  return "";
}

function findColumn(headers: string[], names: string[]) {
  for (const name of names) {
    const wanted = name.toLowerCase().trim();
    const index = headers.findIndex((h) => String(h).toLowerCase().trim() === wanted);
    if (index !== -1) return index;
  }
  return -1;
}

export async function fetchDocSheet(sheetId: string): Promise<DocItem[]> {
  const text = await fetchSheetText(
    `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:json`,
  );
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("Невалиден отговор от Google Sheets.");
  const json = JSON.parse(text.substring(start, end + 1));
  const table = json?.table;
  if (!table?.rows) throw new Error("В таблицата няма данни.");

  const headers: string[] = (table.cols ?? []).map((c: { label?: string }) =>
    (c.label || "").trim(),
  );
  const idIndex = findColumn(headers, ["ID", "id"]);
  const titleIndex = findColumn(headers, ["Заглавие", "Име", "Title"]);
  const fileIndex = findColumn(headers, ["Файл", "PDF", "File"]);
  const dateIndex = findColumn(headers, ["Дата", "Година", "Date"]);
  const infoIndex = findColumn(headers, [
    "Допълнителна информация",
    "Информация",
    "Описание",
    "Description",
  ]);
  if (titleIndex === -1) throw new Error("Не е намерена колоната „Заглавие“.");

  const items: DocItem[] = [];
  (table.rows as Array<{ c: Cell[] }>).forEach((row) => {
    const cells = row?.c ?? [];
    const title = cellValue(cells[titleIndex]);
    if (!title) return;
    items.push({
      id: idIndex !== -1 ? cellValue(cells[idIndex]) : title,
      title,
      file: fileIndex !== -1 ? getFileUrl(cellValue(cells[fileIndex])) : "",
      information: infoIndex !== -1 ? cellValue(cells[infoIndex]) : "",
      date: dateIndex !== -1 ? cellValue(cells[dateIndex]) : "",
    });
  });
  return items;
}

/** Извлича година (4 цифри) от текст на дата. */
export function yearOf(value: string): string {
  const m = String(value || "").match(/(\d{4})/);
  return m?.[1] ?? "";
}

/** Сортира по дата (най-новите отгоре) в рамките на всяка година. */
function dateValue(value: string): number {
  const m = String(value || "").match(/(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})/);
  if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1])).getTime();
  const y = yearOf(value);
  return y ? new Date(Number(y), 0, 1).getTime() : 0;
}

/** Групира документите по година, като най-новата година е най-отгоре. */
export function groupByYear(items: DocItem[]): DocGroup[] {
  const map = new Map<string, DocItem[]>();
  for (const item of items) {
    const year = yearOf(item.date) || "Без година";
    const list = map.get(year) ?? [];
    list.push(item);
    map.set(year, list);
  }
  return [...map.entries()]
    .sort((a, b) => {
      if (a[0] === "Без година") return 1;
      if (b[0] === "Без година") return -1;
      return Number(b[0]) - Number(a[0]);
    })
    .map(([year, list]) => ({
      year,
      items: [...list].sort((a, b) => dateValue(b.date) - dateValue(a.date)),
    }));
}
