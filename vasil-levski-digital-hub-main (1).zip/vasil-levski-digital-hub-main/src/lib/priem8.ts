import { parseCSV } from "@/lib/news";
import { driveImageUrl } from "@/lib/priem";
import { fetchSheetText } from "@/lib/sheetCache";

const SHEET_ID = "1CYsJWGwfHrJHfeIx9zfz4p0Oyzqu4Q0CpVQgAp3YQWU";

export const SPECIALTY_ALIASES: Record<string, string> = {
  "природни науки": "Природни науки",
  "хуманитарни науки": "Хуманитарни науки",
};

const INVALID = new Set([
  "",
  "не",
  "няма",
  "няма снимка",
  "няма съдържание",
  "-",
  "—",
  "n/a",
  "na",
  "null",
]);

export type SheetRow = { values: string[]; headers: Record<string, string>; sheetRow: number };

const COLUMN_INDEX: Record<string, number> = {
  A: 0, B: 1, C: 2, D: 3, E: 4, F: 5, G: 6, H: 7, I: 8,
  J: 9, K: 10, L: 11, M: 12, N: 13, O: 14, P: 15, Q: 16, R: 17,
};

const LEGACY_SECTION_ROWS: Record<string, Record<number, number>> = {
  "Природни науки": { 5: 6, 7: 8, 8: 9 },
  "Хуманитарни науки": { 5: 14, 7: 16, 8: 17 },
};

export function clean(value: unknown): string {
  return String(value ?? "").trim();
}

export function isEmpty(value: unknown): boolean {
  return INVALID.has(clean(value).toLowerCase());
}

function normalizeHeader(value: string): string {
  return clean(value).toLowerCase().replace(/\s+/g, " ").replace(/[–—]/g, "-").trim();
}

function normalizeSpecialty(value: string): string {
  return clean(value)
    .toLowerCase()
    .replace(/[\u00a0\u2007\u202f]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function getValue(row: SheetRow | null, column: string, ...aliases: string[]): string {
  if (!row) return "";
  const index = COLUMN_INDEX[column.toUpperCase()];
  const cell = index === undefined ? "" : clean(row.values[index]);
  if (!isEmpty(cell)) return cell;
  const wanted = aliases.map(normalizeHeader);
  for (const key of Object.keys(row.headers)) {
    if (wanted.includes(normalizeHeader(key))) return clean(row.headers[key]);
  }
  return "";
}

export function resolveSpecialty(requested: string): string {
  const raw = clean(requested) || "Природни науки";
  return SPECIALTY_ALIASES[raw.toLowerCase()] ?? raw;
}

export function findSection(
  rows: SheetRow[],
  specialty: string,
  sectionNumber: number,
): SheetRow | null {
  const wanted = normalizeSpecialty(specialty);
  const exact = rows.find((row) => {
    const rowSpecialty = normalizeSpecialty(getValue(row, "B", "Специалност"));
    const rowSection = clean(getValue(row, "A", "Секция")).match(/\d+/)?.[0] ?? "";
    const matches =
      rowSpecialty === wanted ||
      (rowSpecialty !== "" && (rowSpecialty.includes(wanted) || wanted.includes(rowSpecialty)));
    return matches && rowSection === String(sectionNumber);
  });
  if (exact) return exact;

  const canonical = Object.values(SPECIALTY_ALIASES).find(
    (name) => normalizeSpecialty(name) === wanted,
  );
  const mappedRow = canonical ? LEGACY_SECTION_ROWS[canonical]?.[sectionNumber] : undefined;
  if (mappedRow) return rows.find((row) => row.sheetRow === mappedRow) ?? null;
  return null;
}

export async function fetchProfileRows(): Promise<SheetRow[]> {
  const text = await fetchSheetText(
    `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv`,
  );
  const raw = parseCSV(text).filter((row) => row.some((c) => clean(c) !== ""));
  if (raw.length === 0) return [];
  const headerRow = (raw[0] ?? []).map(clean);
  return raw.slice(1).map((row, i) => {
    const headers: Record<string, string> = {};
    headerRow.forEach((h, index) => {
      headers[h] = clean(row[index] ?? "");
    });
    return { values: row.map(clean), headers, sheetRow: i + 2 };
  });
}

/** Приема директен URL, Drive линк или локално име на файл. */
export function imageSrc(value: string): string {
  const raw = clean(value);
  if (isEmpty(raw)) return "";
  if (raw.includes("drive.google.com")) return driveImageUrl(raw);
  if (/^https?:\/\//i.test(raw)) return raw;
  return "";
}

export function splitDescription(value: string): [string, string] {
  const text = clean(value);
  if (isEmpty(text)) return ["", ""];
  if (text.includes("||")) {
    const parts = text.split("||").map((p) => p.trim()).filter(Boolean);
    return [parts[0] ?? "", parts.slice(1).join(" ").trim()];
  }
  const lines = text.split(/\r?\n+/).map((l) => l.trim()).filter(Boolean);
  if (lines.length >= 2) {
    const middle = Math.ceil(lines.length / 2);
    return [lines.slice(0, middle).join("\n"), lines.slice(middle).join("\n")];
  }
  return [text, ""];
}