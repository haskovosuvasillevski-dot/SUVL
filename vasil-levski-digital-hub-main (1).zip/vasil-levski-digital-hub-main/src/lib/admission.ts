import { fetchSheetText } from "@/lib/sheetCache";

export type AdmissionRecord = {
  academicYear: string;
  title: string;
  content: string;
  buttonText: string;
  pdfUrl: string;
  highlightWord: string;
};

function cellValue(cell: { v?: unknown; f?: unknown } | null | undefined): string {
  if (!cell) return "";
  if (cell.f !== undefined && cell.f !== null) return String(cell.f).trim();
  if (cell.v !== undefined && cell.v !== null) return String(cell.v).trim();
  return "";
}

export function directDriveUrl(url: string): string {
  if (!url) return "#";
  const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/);
  if (match?.[1]) return `https://drive.google.com/uc?export=download&id=${match[1]}`;
  return url;
}

export async function fetchAdmission(sheetId: string): Promise<AdmissionRecord | null> {
  const url = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:json&gid=0`;
  const text = await fetchSheetText(url);
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("Google Sheets не върна валиден JSON.");
  const json = JSON.parse(text.substring(start, end + 1));
  const rows: Array<{ c: Array<{ v?: unknown; f?: unknown } | null> }> = json?.table?.rows ?? [];
  for (const row of rows) {
    const cells = row?.c ?? [];
    const active = cellValue(cells[5]).toLowerCase();
    if (["true", "1", "да", "yes"].includes(active)) {
      return {
        academicYear: cellValue(cells[0]),
        title: cellValue(cells[1]),
        content: cellValue(cells[2]),
        buttonText: cellValue(cells[3]),
        pdfUrl: cellValue(cells[4]),
        highlightWord: cellValue(cells[6]),
      };
    }
  }
  return null;
}
