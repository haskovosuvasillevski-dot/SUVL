import { parseCSV } from "@/lib/news";
import { driveId } from "@/lib/clubs";
import { fetchSheetText } from "@/lib/sheetCache";

export type Project = {
  id: string;
  title: string;
  image: string;
  rawDate: string;
  date: Date;
  content: string;
  /** Снимки, които се редуват с текста. */
  inlineImages: string[];
  /** Изображения в галерия под текста. */
  galleryImages: string[];
  videos: string[];
};

const SPREADSHEET_ID = "12hMvWLMUITOOoK4YgR5NPPTU4A5TL8tDJWvGnX9s9T0";
const CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv`;

/** Директен CDN линк за Google Drive; други линкове (GitHub, Cloudinary) минават без промяна. */
export function imageUrl(url: string): string {
  const raw = String(url || "").trim();
  if (!raw) return "";
  const id = driveId(raw);
  if (id && raw.includes("drive.google.com")) {
    return `https://lh3.googleusercontent.com/d/${id}=w2000`;
  }
  return raw;
}

export function splitList(value: string): string[] {
  return String(value || "")
    .replace(/\r/g, "")
    .split(/\n+|\s*[,;]\s*(?=https?:\/\/)/i)
    .map((s) => s.trim())
    .filter(Boolean);
}

function parseDate(value: string): Date {
  const v = (value || "").trim();
  if (!v) return new Date(0);
  const parts = v.split(/[/.-]/);
  if (parts.length === 3) {
    const [d, m, y] = parts.map((p) => parseInt(p, 10));
    if (d && m && y) return new Date(y, m - 1, d);
  }
  const parsed = Date.parse(v);
  return isNaN(parsed) ? new Date(0) : new Date(parsed);
}

export async function fetchProjects(): Promise<Project[]> {
  const rows = parseCSV(await fetchSheetText(CSV_URL)).slice(1);

  return rows
    .map((row) => ({
      id: (row[0] || "").trim(),
      title: (row[1] || "").trim(),
      image: imageUrl(row[2] || ""),
      rawDate: (row[3] || "").trim(),
      date: parseDate(row[3] || ""),
      content: row[4] || "",
      inlineImages: splitList(row[5] || "").map(imageUrl),
      galleryImages: splitList(row[6] || "").map(imageUrl),
      videos: splitList(row[7] || ""),
    }))
    .filter((p) => p.id && p.title)
    .sort((a, b) => b.date.getTime() - a.date.getTime());
}
