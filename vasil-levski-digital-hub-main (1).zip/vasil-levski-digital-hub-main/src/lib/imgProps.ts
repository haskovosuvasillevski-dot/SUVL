/**
 * Responsive изображения за снимки от Google Drive.
 * Генерира srcSet през проксито /api/public/img (което заобикаля ORB
 * блокировката на lh3.googleusercontent.com) с няколко ширини, така че
 * мобилните устройства теглят малки файлове.
 */

const WIDTHS = [400, 800, 1200, 1600];

function extractDriveId(url: string): string {
  const u = String(url || "");
  const m =
    u.match(/googleusercontent\.com\/d\/([\w-]+)/) ||
    u.match(/\/file\/d\/([\w-]+)/) ||
    u.match(/[?&]id=([\w-]+)/);
  return m?.[1] ?? "";
}

export type ImgProps = {
  src: string;
  srcSet?: string;
  sizes?: string;
};

export function driveImgProps(url: string, sizes: string, fallbackWidth = 800): ImgProps {
  const id = extractDriveId(url);
  if (!id) return { src: url };
  const enc = encodeURIComponent(id);
  return {
    src: `/api/public/img?id=${enc}&w=${fallbackWidth}`,
    srcSet: WIDTHS.map((w) => `/api/public/img?id=${enc}&w=${w} ${w}w`).join(", "),
    sizes,
  };
}

/** Пълноразмерен вариант през проксито (за лайтбокс). */
export function driveImgFull(url: string): string {
  const id = extractDriveId(url);
  if (!id) return url;
  return `/api/public/img?id=${encodeURIComponent(id)}&w=2000`;
}
