import { parseCSV } from "@/lib/news";
import { fetchSheetText } from "@/lib/sheetCache";

export type TextbookItem = {
  cls: string;
  category: string;
  subject: string;
  number: number;
  title: string;
  link: string;
};

const SPREADSHEET_ID = "1HtaxPmRSKH2nI2E1KbkqRIiysAEh3uK3no4o_yFtRw4";
export const TEXTBOOKS_CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv`;

export async function fetchTextbooks(): Promise<TextbookItem[]> {
  const rows = parseCSV(await fetchSheetText(TEXTBOOKS_CSV_URL)).slice(1);

  return rows
    .filter((r) => (r[0] || "").trim() !== "" && r.length >= 5)
    .map((r) => ({
      cls: (r[0] || "").trim(),
      category: (r[1] || "").trim(),
      subject: (r[2] || "").trim(),
      number: Number(r[3]) || 1,
      title: (r[4] || "").trim(),
      link: (r[5] || "").trim(),
    }));
}

/** Гъвкаво съвпадение „Учебник“/„Учебници“. */
export function matches(item: TextbookItem, cls: string, category: string): boolean {
  const itemCat = item.category.toLowerCase();
  const target = category.toLowerCase();
  return (
    item.cls.toLowerCase() === cls.toLowerCase() &&
    (itemCat === target || itemCat.startsWith(target.slice(0, -1)))
  );
}

export function normalizeLink(url: string): string | null {
  const u = (url || "").trim();
  if (!u) return null;
  if (u.startsWith("www")) return `https://${u}`;
  if (u.startsWith("http")) return u;
  return null;
}
