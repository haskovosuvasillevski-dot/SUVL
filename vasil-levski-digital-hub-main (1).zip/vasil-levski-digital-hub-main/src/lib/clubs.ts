import { fetchSheetText } from "@/lib/sheetCache";

export type Club = {
  id: string;
  title: string;
  image: string;
  time: string;
  price: string;
  levels: string;
  subtitle: string;
  leader: string;
  duration: string;
  lessons: string;
  participants: string;
  language: string;
  certificate: string;
  contact: string;
  description: string;
  students: string;
  program: string;
  links: string;
  editions: string;
  leaderImage: string;
  leaderDescription: string;
};

const SHEET_ID = "15HVdLYCBYpDQRk0HYCw8kXD35-RY3bsUb1y8gKyyKuc";
const SHEET_NAME = "Клубове";

export function driveId(url: string): string {
  const s = String(url || "");
  const m = s.match(/\/d\/([a-zA-Z0-9_-]+)/) || s.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  return m?.[1] ?? "";
}

/** Директен CDN линк – без лупа и без интерфейса на Google Drive. */
export function driveImage(url: string): string {
  const id = driveId(url);
  return id ? `https://lh3.googleusercontent.com/d/${id}=w2000` : String(url || "");
}

export function youtubeId(url: string): string {
  const s = String(url || "");
  const m =
    s.match(/[?&]v=([^&]+)/) ||
    s.match(/youtu\.be\/([^?]+)/) ||
    s.match(/youtube\.com\/embed\/([^?]+)/);
  return m?.[1] ?? "";
}

export function splitLines(value: string): string[] {
  const raw = String(value || "").replace(/\r/g, "").trim();
  if (!raw) return [];
  return raw
    .split(/\n+|\s*[;,]\s*(?=https?:\/\/)/i)
    .map((x) => x.trim())
    .filter(Boolean);
}

export type MediaEntry = { url: string; text: string };

export function parseMediaEntry(line: string): MediaEntry {
  const raw = String(line || "").trim();
  const m = raw.match(/^(https?:\/\/\S+)\s+-\s+(.+)$/i);
  if (m) return { url: (m[1] ?? "").trim(), text: (m[2] ?? "").trim() };
  const parts = raw.split("|");
  return { url: (parts.shift() || "").trim(), text: parts.join("|").trim() };
}

export async function fetchClubs(): Promise<Club[]> {
  const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?sheet=${encodeURIComponent(
    SHEET_NAME,
  )}&tqx=out:json`;
  const text = await fetchSheetText(url);
  const data = JSON.parse(text.substring(text.indexOf("{"), text.lastIndexOf("}") + 1));
  const rows: { c: ({ v: unknown } | null)[] }[] = data?.table?.rows ?? [];
  return rows
    .map((row) => {
      const v = row.c.map((cell) => (cell && cell.v != null ? String(cell.v) : ""));
      const g = (i: number) => v[i] ?? "";
      return {
        id: g(0),
        title: g(1),
        image: g(2),
        time: g(3),
        price: g(4),
        levels: g(5),
        subtitle: g(6),
        leader: g(7),
        duration: g(8),
        lessons: g(9),
        participants: g(10),
        language: g(11),
        certificate: g(12),
        contact: g(13),
        description: g(14),
        students: g(15),
        program: g(16),
        links: g(17),
        editions: g(18),
        leaderImage: g(19),
        leaderDescription: g(20),
      } satisfies Club;
    })
    .filter((c) => c.id && c.title);
}