import { fixDriveUrl, parseCSV } from "@/lib/news";
import { fetchSheetText } from "@/lib/sheetCache";

export type HeroSlide = {
  id: string;
  title: string;
  subtitle: string;
  type: "youtube" | "video" | "image";
  src: string;
  videoId?: string;
};

const SPREADSHEET_ID = "1QZYS5MSmgrJhJWZPOMHMir9Ba_aKFNijdfMPGiWzgE8";
export const HERO_CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv`;

/** Извлича YouTube ID от всякакъв формат линк. */
export function extractYouTubeId(url: string): string | null {
  const u = (url || "").trim();
  if (!u) return null;
  const patterns = [
    /(?:youtube\.com|youtube-nocookie\.com)\/(?:watch\?[^#]*\bv=)([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com|youtube-nocookie\.com)\/(?:embed|v|shorts|live)\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const re of patterns) {
    const m = u.match(re);
    if (m?.[1]) return m[1];
  }
  if (/^[a-zA-Z0-9_-]{11}$/.test(u)) return u;
  return null;
}

/** Разпознава Cloudinary (или друго) видео по URL. */
export function isVideoUrl(url: string): boolean {
  const u = (url || "").trim().toLowerCase();
  if (!u) return false;
  if (/res\.cloudinary\.com\/.+\/video\/upload\//.test(u)) return true;
  return /\.(mp4|webm|ogv|mov|m4v)(\?|#|$)/.test(u);
}

export async function fetchHeroSlides(): Promise<HeroSlide[]> {
  const rows = parseCSV(await fetchSheetText(HERO_CSV_URL)).slice(1);

  return rows
    .map((row, i) => {
      const rawUrl = (row[3] || "").trim();
      const videoId = extractYouTubeId(rawUrl);
      const isVideo = !videoId && isVideoUrl(rawUrl);
      const slide: HeroSlide = {
        id: (row[0] || String(i)).trim() || String(i),
        title: (row[1] || "").trim(),
        subtitle: (row[2] || "").trim(),
        type: videoId ? "youtube" : isVideo ? "video" : "image",
        src: videoId || isVideo ? rawUrl : fixDriveUrl(rawUrl),
      };
      if (videoId) slide.videoId = videoId;
      return slide;
    })
    .filter((s) => Boolean(s.src));
}
