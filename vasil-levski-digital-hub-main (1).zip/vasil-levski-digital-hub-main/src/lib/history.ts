import { parseCSV } from "@/lib/news";
import { driveId, driveImage, youtubeId } from "@/lib/clubs";
import { fetchSheetText } from "@/lib/sheetCache";

export type HistorySection = {
  id: number;
  title: string;
  content: string;
  images: string[];
  video: string;
};

export const HISTORY_SHEET_ID = "1QM9LavkYJxAOQ4JUfbxQDa9rKdU1dfiwN2XfONtfw4Y";
export const PATRON_SHEET_ID = "1oTIElJ-pPG4rjO0fotJxyPVRukCehSoltzpq2gst5RI";

function media(url: string): string {
  const raw = String(url || "").trim();
  if (!raw) return "";
  return raw.includes("drive.google.com") ? driveImage(raw) : raw;
}

/** Превръща YouTube / Google Drive / Cloudinary линк в embed адрес. Празно = няма видео. */
export function videoEmbed(url: string): string {
  const raw = String(url || "").trim();
  if (!raw || !/^https?:\/\//i.test(raw)) return "";
  const yt = youtubeId(raw);
  if (yt) return `https://www.youtube.com/embed/${yt}`;
  if (raw.includes("drive.google.com")) {
    const id = driveId(raw);
    return id ? `https://drive.google.com/file/d/${id}/preview` : "";
  }
  // Cloudinary embed понякога се блокира от браузъра (ORB). Преобразуваме го
  // към same-origin видео ресурс, който работи надеждно с нативния <video>.
  if (/player\.cloudinary\.com\/embed/i.test(raw)) {
    try {
      const playerUrl = new URL(raw);
      const cloudName = playerUrl.searchParams.get("cloud_name")?.trim();
      const publicId = playerUrl.searchParams.get("public_id")?.trim();
      if (!cloudName || !publicId) return "";
      const params = new URLSearchParams({ cloud: cloudName, id: publicId });
      return `/api/public/cloudinary-video?${params.toString()}`;
    } catch {
      return "";
    }
  }
  // Cloudinary: пряк видео файл от res.cloudinary.com → <video>
  if (/res\.cloudinary\.com\/.+\/video\/upload\//i.test(raw)) return raw;
  if (/\.(mp4|webm|ogv|mov|m4v)(\?.*)?$/i.test(raw)) return raw;
  if (raw.includes("vimeo.com")) {
    const id = raw.match(/vimeo\.com\/(?:video\/)?(\d+)/)?.[1];
    return id ? `https://player.vimeo.com/video/${id}` : "";
  }
  return "";
}

/** Дали адресът е директен видео файл (рендерира се с <video>). */
export function isFileVideo(url: string): boolean {
  if (url.startsWith("/api/public/cloudinary-video?")) return true;
  if (/\.(mp4|webm|ogv|mov|m4v)(\?.*)?$/i.test(url)) return true;
  return /res\.cloudinary\.com\/.+\/video\/upload\//i.test(url);
}

export async function fetchSections(sheetId: string): Promise<HistorySection[]> {
  const text = await fetchSheetText(
    `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`,
  );
  return parseCSV(text)
    .slice(1)
    .map((row, index) => ({
      id: index,
      title: (row[0] || "").trim(),
      content: (row[1] || "").replace(/\r/g, ""),
      images: (row[2] || "")
        .split(",")
        .map((s) => media(s))
        .filter(Boolean),
      video: videoEmbed(row[3] || ""),
    }))
    .filter((s) => s.title || s.content);
}

export async function fetchHistory(): Promise<HistorySection[]> {
  return fetchSections(HISTORY_SHEET_ID);
}
