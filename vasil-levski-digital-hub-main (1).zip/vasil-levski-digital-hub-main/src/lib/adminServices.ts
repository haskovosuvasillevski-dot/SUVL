import { fetchSheetText } from "@/lib/sheetCache";

const SPREADSHEET_ID = "1YmUeSY9AJvkMMsXCZqiy15iMUHTGWLzyDkh9cQYs21w";
const SHEET_GID = "0";
const SHEET_URL =
  `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?gid=${SHEET_GID}&headers=1`;

export type AdminService = {
  id: string;
  title: string;
  file: string;
  information: string;
};

function isEmpty(value: unknown) {
  return value === null || value === undefined || String(value).trim() === "";
}

function parseGoogleResponse(text: string) {
  const start = text.indexOf("(");
  const end = text.lastIndexOf(")");
  if (start === -1 || end === -1) {
    throw new Error("Невалиден отговор от Google Sheets.");
  }
  return JSON.parse(text.substring(start + 1, end));
}

function cellValue(cell: any): string {
  if (!cell) return "";
  if (cell.f !== undefined && cell.f !== null) return String(cell.f).trim();
  if (cell.v !== undefined && cell.v !== null) return String(cell.v).trim();
  return "";
}

function findColumn(headers: string[], names: string[]) {
  for (const name of names) {
    const wanted = name.toLowerCase().trim();
    const index = headers.findIndex(
      (header) => String(header).toLowerCase().trim() === wanted,
    );
    if (index !== -1) return index;
  }
  return -1;
}

export function getFileUrl(value: string): string {
  if (isEmpty(value)) return "";
  const url = String(value).trim();

  let match = url.match(/drive\.google\.com\/file\/d\/([^/]+)/i);
  if (match && match[1]) {
    return `https://drive.google.com/file/d/${match[1]}/view`;
  }

  match = url.match(/[?&]id=([^&]+)/i);
  if (match && match[1] && url.includes("drive.google.com")) {
    return `https://drive.google.com/file/d/${match[1]}/view`;
  }

  return url;
}

function getDriveFileId(url: string): string {
  if (isEmpty(url)) return "";
  let match = String(url).match(/\/file\/d\/([^/]+)/i);
  if (match && match[1]) return match[1];
  match = String(url).match(/[?&]id=([^&]+)/i);
  if (match && match[1]) return match[1];
  return "";
}

export function getPreviewUrl(url: string): string {
  const fileId = getDriveFileId(url);
  if (fileId) return `https://drive.google.com/file/d/${fileId}/preview`;
  return url;
}

export function getDownloadUrl(url: string): string {
  const fileId = getDriveFileId(url);
  if (fileId) return `https://drive.google.com/uc?export=download&id=${fileId}`;
  return url;
}

export async function fetchAdminServices(): Promise<AdminService[]> {
  const text = await fetchSheetText(SHEET_URL);
  const result = parseGoogleResponse(text);

  if (result.status && result.status !== "ok") {
    throw new Error("Google Sheets върна грешка.");
  }

  const table = result.table;
  if (!table || !table.rows) {
    throw new Error("В таблицата няма данни.");
  }

  const headers: string[] = table.cols.map((column: any) => (column.label || "").trim());

  const idIndex = findColumn(headers, ["ID", "id"]);
  const titleIndex = findColumn(headers, [
    "Заглавие",
    "Заглавие ",
    "Име",
    "Име на документа",
    "Title",
    "title",
  ]);
  const fileIndex = findColumn(headers, ["Файл", "Файл ", "PDF", "pdf", "File", "file"]);
  const informationIndex = findColumn(headers, [
    "Допълнителна информация",
    "Допълнителна информация ",
    "Информация",
    "Описание",
    "Description",
    "Information",
    "Info",
  ]);

  if (titleIndex === -1) {
    throw new Error("Не е намерена колоната „Заглавие“ в Google Sheets.");
  }

  const services: AdminService[] = [];

  table.rows.forEach((row: any) => {
    const cells = row.c || [];
    const id = idIndex !== -1 ? cellValue(cells[idIndex]) : "";
    const title = cellValue(cells[titleIndex]);
    const file = fileIndex !== -1 ? cellValue(cells[fileIndex]) : "";
    const information = informationIndex !== -1 ? cellValue(cells[informationIndex]) : "";

    if (isEmpty(title)) return;

    services.push({ id, title, file: getFileUrl(file), information });
  });

  return services;
}
