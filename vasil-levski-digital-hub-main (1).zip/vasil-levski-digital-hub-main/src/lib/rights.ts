import { fetchSheetText } from "@/lib/sheetCache";

const SHEET_ID = "1l_2NWoyCPQW8tvRJNOx25OtkNxgeGJRzkQZe-bBAihg";

export type RightsData = {
  schoolName: string;
  academicYear: string;
  studentRights: string;
  parentRights: string;
};

async function loadCell(cell: string): Promise<string> {
  const url =
    `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:json&range=` +
    encodeURIComponent(cell);
  const text = await fetchSheetText(url);
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("Google Sheets не върна валиден JSON.");
  const data = JSON.parse(text.substring(start, end + 1));
  const c = data?.table?.rows?.[0]?.c?.[0];
  if (!c) return "";
  if (c.f !== undefined && c.f !== null) return String(c.f);
  if (c.v !== undefined && c.v !== null) return String(c.v);
  return "";
}

export async function fetchRights(): Promise<RightsData> {
  const [schoolName, academicYear, studentRights, parentRights] = await Promise.all([
    loadCell("B2"),
    loadCell("B3"),
    loadCell("B4"),
    loadCell("B5"),
  ]);
  return { schoolName, academicYear, studentRights, parentRights };
}
