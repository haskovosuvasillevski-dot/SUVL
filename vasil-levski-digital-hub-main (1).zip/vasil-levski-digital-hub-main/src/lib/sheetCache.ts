/**
 * Споделен кеш за текстови отговори от Google Sheets (CSV/gviz).
 * Пази резултатите в паметта и в sessionStorage за 5 минути, така че
 * при навигация между страници една и съща база не се тегли повторно.
 */

const TTL_MS = 5 * 60 * 1000;
const mem = new Map<string, Promise<string>>();

function storageKey(url: string): string {
  return "sheet-cache:" + url;
}

function readSession(url: string): string | null {
  try {
    const raw = sessionStorage.getItem(storageKey(url));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { t?: number; text?: string };
    if (typeof parsed.text !== "string" || typeof parsed.t !== "number") return null;
    if (Date.now() - parsed.t > TTL_MS) return null;
    return parsed.text;
  } catch {
    return null;
  }
}

function writeSession(url: string, text: string): void {
  try {
    sessionStorage.setItem(storageKey(url), JSON.stringify({ t: Date.now(), text }));
  } catch {
    /* пълно хранилище — игнорираме */
  }
}

export function fetchSheetText(url: string): Promise<string> {
  const existing = mem.get(url);
  if (existing) return existing;

  const cached = readSession(url);
  if (cached !== null) {
    const p = Promise.resolve(cached);
    mem.set(url, p);
    return p;
  }

  const p = fetch(url)
    .then((res) => {
      if (!res.ok) throw new Error("Неуспешно зареждане на данните");
      return res.text();
    })
    .then((text) => {
      writeSession(url, text);
      return text;
    });
  mem.set(url, p);
  // При грешка махаме от кеша, за да може повторен опит.
  p.catch(() => {
    if (mem.get(url) === p) mem.delete(url);
  });
  return p;
}
