/* Общ модал за преглед и изтегляне на документи в статичните страници. */
(function () {
  var STYLE = `
  .lv-doc-modal{position:fixed;inset:0;z-index:99999;display:none;background:rgba(0,0,0,.78);padding:0}
  .lv-doc-modal.open{display:flex;align-items:center;justify-content:center}
  .lv-doc-box{background:#fff;width:100%;height:100%;display:flex;flex-direction:column;overflow:hidden}
  @media(min-width:640px){.lv-doc-modal{padding:24px}.lv-doc-box{width:95%;max-width:1000px;height:92vh;border-radius:6px}}
  .lv-doc-head{display:flex;align-items:center;gap:12px;justify-content:space-between;background:#15599b;color:#fff;padding:10px 14px;min-height:58px}
  .lv-doc-title{font:600 15px/1.3 Arial,sans-serif;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .lv-doc-btn{display:inline-flex;align-items:center;gap:6px;border:0;cursor:pointer;font:600 14px Arial,sans-serif;border-radius:4px;padding:9px 14px;text-decoration:none}
  .lv-doc-dl{background:#fff;color:#15599b}
  .lv-doc-close{background:rgba(255,255,255,.15);color:#fff}
  .lv-doc-body{flex:1;min-height:0;background:#f1f1f1}
  .lv-doc-body iframe{width:100%;height:100%;border:0;display:block}
  `;

  function driveId(url) {
    var m = url.match(/\/file\/d\/([^/?#]+)/i) || url.match(/[?&]id=([^&#]+)/i);
    return m ? m[1] : "";
  }
  function realUrl(url) {
    var m = url.match(/[?&]url=([^&]+)/i);
    if (/gview/i.test(url) && m) return decodeURIComponent(m[1]);
    return url;
  }
  function previewUrl(url) {
    var u = realUrl(url);
    var id = driveId(u);
    if (id) return "https://drive.google.com/file/d/" + id + "/preview";
    if (/docs\.google\.com\/(document|spreadsheets|presentation)/i.test(u))
      return u.replace(/\/(edit|view|pub)[^]*$/, "/preview");
    if (/\.pdf(\?|#|$)/i.test(u))
      return "https://docs.google.com/gview?embedded=1&url=" + encodeURIComponent(u);
    return u;
  }
  function downloadUrl(url) {
    var u = realUrl(url);
    var id = driveId(u);
    if (id) return "https://drive.google.com/uc?export=download&id=" + id;
    return u;
  }
  function isDoc(url) {
    var u = realUrl(url);
    return (
      /drive\.google\.com/i.test(u) ||
      /docs\.google\.com/i.test(u) ||
      /\.(pdf|docx?|xlsx?|pptx?)(\?|#|$)/i.test(u)
    );
  }

  var modal, frame, titleEl, dlEl;

  function build() {
    var style = document.createElement("style");
    style.textContent = STYLE;
    document.head.appendChild(style);

    modal = document.createElement("div");
    modal.className = "lv-doc-modal";
    modal.innerHTML =
      '<div class="lv-doc-box">' +
      '<div class="lv-doc-head">' +
      '<div class="lv-doc-title"></div>' +
      '<a class="lv-doc-btn lv-doc-dl" target="_blank" rel="noopener">⬇ Изтегляне</a>' +
      '<button type="button" class="lv-doc-btn lv-doc-close">✕</button>' +
      "</div>" +
      '<div class="lv-doc-body"><iframe title="Преглед на документа" allow="autoplay"></iframe></div>' +
      "</div>";
    document.body.appendChild(modal);
    frame = modal.querySelector("iframe");
    titleEl = modal.querySelector(".lv-doc-title");
    dlEl = modal.querySelector(".lv-doc-dl");
    modal.querySelector(".lv-doc-close").addEventListener("click", close);
    modal.addEventListener("click", function (e) {
      if (e.target === modal) close();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") close();
    });
  }

  function notify(open) {
    document.body.classList.toggle("modal-active", open);
    try {
      window.parent.postMessage({ type: "sabshteniya-modal", open: open }, "*");
    } catch (err) {}
  }

  function open(url, label) {
    if (!modal) build();
    titleEl.textContent = label || "Преглед на документа";
    dlEl.href = downloadUrl(url);
    frame.src = previewUrl(url);
    modal.classList.add("open");
    document.documentElement.style.overflow = "hidden";
    notify(true);
  }

  function close() {
    if (!modal) return;
    modal.classList.remove("open");
    frame.src = "about:blank";
    document.documentElement.style.overflow = "";
    notify(false);
  }

  document.addEventListener(
    "click",
    function (e) {
      var a = e.target.closest && e.target.closest("a[href]");
      if (!a) return;
      var href = a.getAttribute("href") || "";
      if (!href || href.charAt(0) === "#") return;
      if (!isDoc(href)) return;
      e.preventDefault();
      e.stopPropagation();
      open(href, (a.textContent || "").trim());
    },
    true,
  );
})();
