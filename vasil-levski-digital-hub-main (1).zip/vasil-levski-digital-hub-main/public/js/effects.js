/* =========================================================================
   Централизирана система за визуални ефекти
   Google Sheets -> Google Apps Script JSON API -> effects.js -> сайта
   Чист HTML/CSS/JS. Няма зависимости от Lovable или външни библиотеки.
   ========================================================================= */
(function () {
  "use strict";

  /* ------------------------------ КОНФИГУРАЦИЯ ------------------------------ */
  var CONFIG = {
    // Поставете тук URL адреса на публикувания Google Apps Script (Web App):
    // например "https://script.google.com/macros/s/AKfycb....../exec"
    API_URL: "",

    // Резервен източник (публично споделен Google Sheet -> CSV).
    // Използва се автоматично, ако API_URL е празен или недостъпен.
    SHEET_ID: "1I2ZFKwxPrcnXZYpULem5AJoiawPITEInBmIp7tPHqtk",

    // Проверка за промени в настройките (по подразбиране на всеки 5 минути)
    REFRESH_TIME: 5 * 60 * 1000,

    // Часова зона за сравнението на датите (България)
    TIMEZONE: "Europe/Sofia",
  };

  CONFIG.CSV_URL =
    "https://docs.google.com/spreadsheets/d/" + CONFIG.SHEET_ID + "/export?format=csv";

  /* -------------------------------- ПОМОЩНИ -------------------------------- */
  var rnd = function (min, max) {
    return Math.random() * (max - min) + min;
  };
  var rndInt = function (min, max) {
    return Math.floor(rnd(min, max + 1));
  };
  var pick = function (arr) {
    return arr[rndInt(0, arr.length - 1)];
  };
  var isMobile = function () {
    return window.innerWidth < 768;
  };
  var reducedMotion = function () {
    return (
      window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches
    );
  };

  /** Днешната дата по българско време във формат YYYY-MM-DD (без зависимост от браузъра). */
  function todayInBulgaria() {
    try {
      var parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: CONFIG.TIMEZONE,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      }).format(new Date());
      if (/^\d{4}-\d{2}-\d{2}$/.test(parts)) return parts;
    } catch (e) {
      /* fallback по-долу */
    }
    var d = new Date();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    return d.getFullYear() + "-" + m + "-" + day;
  }

  /** Нормализира дата към YYYY-MM-DD (приема и 24.05.2027, 24/05/2027, ISO). */
  function normalizeDate(value) {
    if (!value) return "";
    var s = String(value).trim();
    if (!s) return "";
    var iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) return iso[1] + "-" + iso[2] + "-" + iso[3];
    var eu = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
    if (eu) {
      return (
        eu[3] + "-" + String(eu[2]).padStart(2, "0") + "-" + String(eu[1]).padStart(2, "0")
      );
    }
    var d = new Date(s);
    if (!isNaN(d.getTime())) {
      return (
        d.getFullYear() +
        "-" +
        String(d.getMonth() + 1).padStart(2, "0") +
        "-" +
        String(d.getDate()).padStart(2, "0")
      );
    }
    return "";
  }

  function truthy(value) {
    var s = String(value == null ? "" : value).trim().toLowerCase();
    return s === "1" || s === "true" || s === "да" || s === "yes" || s === "on";
  }

  /** Текущата страница: "/" -> "index", "/novini/5" -> ["novini/5", "novini", "5"] */
  function currentPageKeys() {
    var path = window.location.pathname || "/";
    path = path.replace(/\/+$/, "");
    if (!path || path === "") return ["index", "/", "home", ""];
    var clean = path.replace(/^\/+/, "").replace(/\.html?$/i, "");
    var keys = [clean, "/" + clean, clean + ".html", "/" + clean + ".html"];
    var segments = clean.split("/");
    keys.push(segments[0]);
    if (segments.length > 1) keys.push(segments[segments.length - 1]);
    return keys;
  }

  function pageMatches(pageValue) {
    var raw = String(pageValue == null ? "" : pageValue).trim().toLowerCase();
    if (!raw || raw === "all" || raw === "*" || raw === "всички") return true;
    var keys = currentPageKeys().map(function (k) {
      return String(k).toLowerCase();
    });
    return raw
      .split(/[,;|]/)
      .map(function (p) {
        return p.trim().replace(/\.html?$/i, "").replace(/^\/+|\/+$/g, "");
      })
      .filter(Boolean)
      .some(function (p) {
        if (p === "index" || p === "home") p = "index";
        return keys.indexOf(p) !== -1 || keys.indexOf("/" + p) !== -1;
      });
  }

  /** Приоритет на датите пред enabled. */
  function isEffectActive(row, today) {
    var start = normalizeDate(row.start_date);
    var end = normalizeDate(row.end_date);
    if (start && end) return today >= start && today <= end;
    if (start && !end) return today >= start;
    if (!start && end) return today <= end;
    return truthy(row.enabled);
  }

  function normalizeEffectName(name) {
    return String(name || "")
      .trim()
      .toLowerCase()
      .replace(/[\s_-]+/g, "_");
  }

  /* ----------------------------- ЗАРЕЖДАНЕ НА ДАННИ ----------------------------- */
  function parseCSV(text) {
    var rows = [];
    var row = [];
    var field = "";
    var inQuotes = false;
    var src = String(text).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    for (var i = 0; i < src.length; i++) {
      var c = src[i];
      if (inQuotes) {
        if (c === '"') {
          if (src[i + 1] === '"') {
            field += '"';
            i++;
          } else inQuotes = false;
        } else field += c;
      } else if (c === '"') inQuotes = true;
      else if (c === ",") {
        row.push(field);
        field = "";
      } else if (c === "\n") {
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
      } else field += c;
    }
    row.push(field);
    rows.push(row);
    return rows.filter(function (r) {
      return r.some(function (cell) {
        return String(cell).trim() !== "";
      });
    });
  }

  function rowsFromCSV(text) {
    var table = parseCSV(text);
    if (!table.length) return [];
    var header = table[0].map(function (h) {
      return String(h).trim().toLowerCase();
    });
    var idx = function (name) {
      return header.indexOf(name);
    };
    var iId = idx("id");
    var iEffect = idx("effect");
    var iPage = idx("page");
    var iEnabled = idx("enabled");
    var iStart = idx("start_date");
    var iEnd = idx("end_date");
    return table.slice(1).map(function (r, n) {
      return {
        id: iId >= 0 ? r[iId] : n + 1,
        effect: iEffect >= 0 ? r[iEffect] : r[1],
        page: iPage >= 0 ? r[iPage] : "all",
        enabled: iEnabled >= 0 ? r[iEnabled] : "0",
        start_date: iStart >= 0 ? r[iStart] : "",
        end_date: iEnd >= 0 ? r[iEnd] : "",
      };
    });
  }

  function fetchSettings() {
    var bust = "cacheBust=" + Date.now();
    if (CONFIG.API_URL) {
      var apiUrl = CONFIG.API_URL + (CONFIG.API_URL.indexOf("?") === -1 ? "?" : "&") + bust;
      return fetch(apiUrl, { cache: "no-store" })
        .then(function (r) {
          if (!r.ok) throw new Error("API HTTP " + r.status);
          return r.json();
        })
        .then(function (data) {
          if (!data || !Array.isArray(data.effects)) throw new Error("Невалиден JSON отговор");
          return data.effects;
        })
        .catch(function (err) {
          console.error("[effects] Apps Script API недостъпен:", err);
          return fetchCSV(bust);
        });
    }
    return fetchCSV(bust);
  }

  function fetchCSV(bust) {
    return fetch(CONFIG.CSV_URL + "&" + bust, { cache: "no-store" })
      .then(function (r) {
        if (!r.ok) throw new Error("CSV HTTP " + r.status);
        return r.text();
      })
      .then(rowsFromCSV)
      .catch(function (err) {
        console.error("[effects] Настройките не можаха да се заредят:", err);
        return null; // сайтът продължава да работи нормално
      });
  }

  /* -------------------------------- КОНТЕЙНЕР -------------------------------- */
  var container = null;
  function ensureContainer() {
    if (container && document.body.contains(container)) return container;
    container = document.getElementById("global-effects-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "global-effects-container";
      container.setAttribute("aria-hidden", "true");
    }
    if (!document.body.contains(container)) document.body.appendChild(container);
    return container;
  }

  function makeLayer(name) {
    var layer = document.createElement("div");
    layer.className = "fx-layer fx-layer-" + name;
    ensureContainer().appendChild(layer);
    return layer;
  }

  /* ------------------------------ БАЗОВ SPAWNER ------------------------------ */
  /** Създава частици на интервал, с твърд лимит и автоматично изчистване. */
  function createSpawner(options) {
    var layer = makeLayer(options.name);
    var limit = isMobile() ? options.limitMobile : options.limitDesktop;
    var timer = null;
    var stopped = false;

    function spawn() {
      if (stopped) return;
      if (layer.childElementCount >= limit) return;
      if (document.hidden) return;
      var el = options.create();
      if (!el) return;
      layer.appendChild(el);
      var life = (options.life ? options.life(el) : 12) * 1000;
      window.setTimeout(function () {
        if (el.parentNode) el.parentNode.removeChild(el);
      }, life + 400);
    }

    // първоначално "напълване", за да няма празен екран
    var initial = Math.min(options.initial || 0, limit);
    for (var i = 0; i < initial; i++) window.setTimeout(spawn, i * 220);
    timer = window.setInterval(spawn, options.interval);

    return {
      stop: function () {
        stopped = true;
        window.clearInterval(timer);
        if (layer.parentNode) layer.parentNode.removeChild(layer);
      },
    };
  }

  function baseParticle(className, size) {
    var el = document.createElement("div");
    el.className = "fx-particle " + className;
    el.style.left = rnd(-2, 98).toFixed(2) + "vw";
    el.style.fontSize = size + "px";
    el.style.opacity = rnd(0.45, 0.95).toFixed(2);
    return el;
  }

  /* --------------------------------- SNOW --------------------------------- */
  var SNOW_CHARS = ["❄", "❅", "❆", "✻", "✼", "❉"];
  function startSnow() {
    return createSpawner({
      name: "snow",
      limitDesktop: 140,
      limitMobile: 60,
      initial: isMobile() ? 24 : 55,
      interval: isMobile() ? 260 : 120,
      create: function () {
        var el = baseParticle("fx-snow-flake", rndInt(8, 24));
        var fall = rnd(8, 17);
        el.textContent = pick(SNOW_CHARS);
        // част от снежинките падат почти отвесно, други – силно настрани (вятър)
        var sideways = Math.random() < 0.45;
        var drift = sideways ? rnd(14, 34) * (Math.random() < 0.5 ? -1 : 1) : rnd(-5, 5);
        el.style.setProperty("--fx-drift", drift.toFixed(1) + "vw");
        el.style.setProperty("--fx-spin", rndInt(-360, 360) + "deg");
        el.style.animationDuration = fall + "s, " + rnd(6, 14).toFixed(1) + "s";
        el.dataset.life = String(fall);
        return el;
      },
      life: function (el) {
        return Number(el.dataset.life);
      },
    });
  }

  /* -------------------------------- LEAVES -------------------------------- */
  var LEAF_IMAGES = [
    "/assets/leaves2.png",
    "/assets/leaves3.png",
    "/assets/leaves6.png",
    "/assets/leaves7.png",
    "/assets/leaves8.png",
  ];
  // предварително зареждане, за да няма "мигане" при първите частици
  LEAF_IMAGES.forEach(function (src) {
    var img = new Image();
    img.src = src;
  });

  function startLeaves() {
    return createSpawner({
      name: "leaves",
      limitDesktop: 34,
      limitMobile: 16,
      initial: isMobile() ? 5 : 12,
      interval: isMobile() ? 950 : 520,
      create: function () {
        var wrap = document.createElement("div");
        wrap.className = "fx-particle fx-leaf";
        var size = rndInt(20, 56);
        // малките листа падат по-бавно (по-голямо въздушно съпротивление)
        var fall = rnd(13, 26) * (1 - (size - 20) / 90);
        wrap.style.left = rnd(-6, 100).toFixed(2) + "vw";
        wrap.style.width = size + "px";
        wrap.style.opacity = rnd(0.7, 1).toFixed(2);
        // характерно за листата: широко люлеене настрани, докато падат
        wrap.style.setProperty(
          "--fx-drift",
          (rnd(6, 20) * (Math.random() < 0.5 ? -1 : 1)).toFixed(1) + "vw"
        );
        wrap.style.animationDuration = fall.toFixed(1) + "s";
        wrap.style.animationDelay = "-" + rnd(0, 2).toFixed(2) + "s";

        var img = document.createElement("img");
        img.className = "fx-leaf-img";
        img.src = pick(LEAF_IMAGES);
        img.alt = "";
        img.decoding = "async";
        // бавно въртене около собствената ос + „обръщане“ във въздуха
        img.style.animationDuration =
          rnd(6, 14).toFixed(2) + "s, " + rnd(2.8, 6.5).toFixed(2) + "s";
        img.style.animationDelay = "0s, -" + rnd(0, 3).toFixed(2) + "s";
        img.style.setProperty("--fx-spin", rndInt(-200, 200) + "deg");
        img.style.setProperty("--fx-flutter", rndInt(45, 85) + "deg");
        img.style.animationDirection = Math.random() < 0.5 ? "normal" : "reverse";
        wrap.appendChild(img);
        wrap.dataset.life = String(fall);
        return wrap;
      },
      life: function (el) {
        return Number(el.dataset.life);
      },
    });
  }


  /* -------------------------------- LETTERS -------------------------------- */
  var BG_ALPHABET = [
    "А","Б","В","Г","Д","Е","Ж","З","И","Й",
    "К","Л","М","Н","О","П","Р","С","Т","У",
    "Ф","Х","Ц","Ч","Ш","Щ","Ъ","Ь","Ю","Я",
  ];
  var letterCursor = 0;
  function nextLetter() {
    var ch = BG_ALPHABET[letterCursor % BG_ALPHABET.length];
    letterCursor = (letterCursor + 1) % BG_ALPHABET.length; // цикъл А → Я → А
    return ch;
  }

  // Режим на ефекта: "falling" (по подразбиране) или в бъдеще "message".
  var LETTERS_MODE = "falling";
  var LETTERS_MESSAGE = "ЧЕСТИТ 24 МАЙ";

  /* --- Финален надпис във футъра след 60 секунди на страницата --- */
  var FOOTER_TEXT = "ЧЕСТИТ ПРАЗНИК НА БЪЛГАРСКАТА АЗБУКА";
  var FOOTER_TOTAL = 60 * 1000; // изречението е напълно готово на 60-ата секунда

  function buildFooterGreeting() {
    var host = document.createElement("div");
    host.className = "fx-footer-greeting";
    host.setAttribute("aria-hidden", "true");

    var cells = [];
    FOOTER_TEXT.split(" ").forEach(function (word) {
      var w = document.createElement("span");
      w.className = "fx-fg-word";
      word.split("").forEach(function (ch) {
        var span = document.createElement("span");
        span.className = "fx-fg-letter";
        span.textContent = ch;
        w.appendChild(span);
        cells.push(span);
      });
      host.appendChild(w);
    });

    // случаен ред на появяване – буква по буква, разпределено до 60-ата секунда
    var order = cells.slice();
    for (var i = order.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = order[i];
      order[i] = order[j];
      order[j] = t;
    }
    var step = FOOTER_TOTAL / 1000 / order.length;
    order.forEach(function (span, idx) {
      span.style.animationDelay = (idx * step).toFixed(2) + "s";
    });
    return host;
  }

  function startFooterGreeting() {
    var host = null;
    var timer = window.setTimeout(function () {
      if (document.querySelector(".fx-footer-greeting")) return;
      host = buildFooterGreeting();
      var footer = document.querySelector("footer");
      if (footer) footer.appendChild(host);
      else document.body.appendChild(host);
    }, 300);


    return {
      stop: function () {
        window.clearTimeout(timer);
        if (host && host.parentNode) host.parentNode.removeChild(host);
      },
    };
  }

  function startLetters() {
    var messageCursor = 0;
    var spawner = createSpawner({
      name: "letters",
      limitDesktop: 30,
      limitMobile: 14,
      initial: isMobile() ? 5 : 10,
      interval: isMobile() ? 900 : 520,
      create: function () {
        var el = baseParticle("fx-letter", rndInt(20, 46));
        var fall = rnd(11, 20);
        if (LETTERS_MODE === "message") {
          var msg = LETTERS_MESSAGE.replace(/\s/g, "");
          el.textContent = msg.charAt(messageCursor % msg.length);
          messageCursor++;
        } else {
          el.textContent = nextLetter();
        }
        var variant = rndInt(0, 2);
        if (variant === 1) el.classList.add("fx-letter-alt");
        if (variant === 2) el.classList.add("fx-letter-gold");
        el.style.setProperty("--fx-drift", rnd(-7, 7).toFixed(1) + "vw");
        el.style.animationDuration = fall + "s, " + rnd(3, 7).toFixed(1) + "s";
        el.dataset.life = String(fall);
        return el;
      },
      life: function (el) {
        return Number(el.dataset.life);
      },
    });

    var greeting = startFooterGreeting();
    return {
      stop: function () {
        spawner.stop();
        greeting.stop();
      },
    };
  }

  /* ---------------------------- SPRING BUTTERFLIES ---------------------------- */
  // Реалистични пеперуди: предно + задно крило, жилки, петна, телце и антени.
  var BUTTERFLY_SKINS = [
    { base: "#f4a63a", edge: "#7a3a06", spot: "#fff2cf" }, // монарх
    { base: "#5aa9e6", edge: "#123a63", spot: "#dff1ff" }, // морфо
    { base: "#f5f0e2", edge: "#8a7a4a", spot: "#fffdf6" }, // белянка
    { base: "#e0603f", edge: "#5b1c10", spot: "#ffe6b8" }, // адмирал
    { base: "#c89bf0", edge: "#4b2a70", spot: "#f6ecff" }, // лилава
  ];

  function butterflySVG(skin, uid) {
    return (
      '<svg class="fx-bf-svg" viewBox="0 0 120 100" xmlns="http://www.w3.org/2000/svg">' +
      "<defs>" +
      '<linearGradient id="bfg' + uid + '" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="' + skin.base + '"/>' +
      '<stop offset="70%" stop-color="' + skin.base + '"/>' +
      '<stop offset="100%" stop-color="' + skin.edge + '"/>' +
      "</linearGradient>" +
      "</defs>" +
      // ляво крило
      '<g class="fx-bf-wing fx-bf-left">' +
      '<path d="M58 50 C40 12, 8 6, 6 30 C4 48, 26 52, 58 54 Z" fill="url(#bfg' + uid +
      ')" stroke="' + skin.edge + '" stroke-width="2.4" stroke-linejoin="round"/>' +
      '<path d="M58 54 C34 58, 12 66, 18 84 C24 98, 48 82, 58 62 Z" fill="url(#bfg' + uid +
      ')" stroke="' + skin.edge + '" stroke-width="2.4" stroke-linejoin="round"/>' +
      '<path d="M56 52 L20 28 M56 53 L14 44 M57 57 L24 78" stroke="' + skin.edge +
      '" stroke-width="1.1" opacity=".55" fill="none"/>' +
      '<circle cx="26" cy="30" r="4.2" fill="' + skin.spot + '" opacity=".85"/>' +
      '<circle cx="31" cy="76" r="3" fill="' + skin.spot + '" opacity=".8"/>' +
      "</g>" +
      // дясно крило
      '<g class="fx-bf-wing fx-bf-right">' +
      '<path d="M62 50 C80 12, 112 6, 114 30 C116 48, 94 52, 62 54 Z" fill="url(#bfg' + uid +
      ')" stroke="' + skin.edge + '" stroke-width="2.4" stroke-linejoin="round"/>' +
      '<path d="M62 54 C86 58, 108 66, 102 84 C96 98, 72 82, 62 62 Z" fill="url(#bfg' + uid +
      ')" stroke="' + skin.edge + '" stroke-width="2.4" stroke-linejoin="round"/>' +
      '<path d="M64 52 L100 28 M64 53 L106 44 M63 57 L96 78" stroke="' + skin.edge +
      '" stroke-width="1.1" opacity=".55" fill="none"/>' +
      '<circle cx="94" cy="30" r="4.2" fill="' + skin.spot + '" opacity=".85"/>' +
      '<circle cx="89" cy="76" r="3" fill="' + skin.spot + '" opacity=".8"/>' +
      "</g>" +
      // телце и антени
      '<ellipse cx="60" cy="56" rx="3.6" ry="20" fill="#3a2a1c"/>' +
      '<circle cx="60" cy="35" r="4.6" fill="#2c1f14"/>' +
      '<path d="M58 32 C52 22, 48 18, 44 16 M62 32 C68 22, 72 18, 76 16" stroke="#2c1f14" ' +
      'stroke-width="1.6" fill="none" stroke-linecap="round"/>' +
      '<circle cx="44" cy="16" r="1.8" fill="#2c1f14"/>' +
      '<circle cx="76" cy="16" r="1.8" fill="#2c1f14"/>' +
      "</svg>"
    );
  }

  var bfUid = 0;
  function startButterflies() {
    return createSpawner({
      name: "butterflies",
      limitDesktop: 12,
      limitMobile: 6,
      initial: isMobile() ? 3 : 6,
      interval: isMobile() ? 2600 : 1600,
      create: function () {
        var wrap = document.createElement("div");
        wrap.className = "fx-butterfly";
        wrap.style.fontSize = rndInt(22, 52) + "px";
        wrap.style.opacity = rnd(0.7, 0.95).toFixed(2);
        wrap.style.setProperty("--fx-y0", rnd(2, 55).toFixed(1) + "vh");
        var duration = rnd(16, 30);
        wrap.style.animationDuration = duration + "s";

        var body = document.createElement("div");
        body.className = "fx-butterfly-body";
        body.style.animationDuration = rnd(1.8, 3.2).toFixed(2) + "s";
        body.innerHTML = butterflySVG(pick(BUTTERFLY_SKINS), ++bfUid);
        var flap = rnd(0.2, 0.36).toFixed(2) + "s";
        Array.prototype.forEach.call(body.querySelectorAll(".fx-bf-wing"), function (w) {
          w.style.animationDuration = flap;
        });
        wrap.appendChild(body);
        wrap.dataset.life = String(duration);
        return wrap;
      },
      life: function (el) {
        return Number(el.dataset.life);
      },
    });
  }

  /* -------------------------------- BUBBLES -------------------------------- */
  function startBubbles() {
    return createSpawner({
      name: "bubbles",
      limitDesktop: 40,
      limitMobile: 18,
      initial: isMobile() ? 6 : 12,
      interval: isMobile() ? 800 : 450,
      create: function () {
        var el = document.createElement("div");
        el.className = "fx-bubble";
        var size = rndInt(10, 60);
        var rise = rnd(9, 20);
        el.style.width = size + "px";
        el.style.height = size + "px";
        el.style.left = rnd(-2, 98).toFixed(2) + "vw";
        el.style.setProperty("--fx-drift", rnd(-10, 10).toFixed(1) + "vw");
        el.style.setProperty("--fx-opacity", rnd(0.35, 0.75).toFixed(2));
        el.style.animationDuration = rise + "s";
        el.dataset.life = String(rise);
        return el;
      },
      life: function (el) {
        return Number(el.dataset.life);
      },
    });
  }

  /* ------------------------------- MARTENITSA ------------------------------- */
  // Реални мартеници (Пижо и Пенда, шевици) – снимки от CDN.
  var MARTENITSA_IMAGES = [
    "/assets/mt-pizho-penda-t.png",
    "/assets/mt-pizho-penda2-t.png",
    "/assets/mt-round.png",
    "/assets/mt-diamond.png",
  ];
  MARTENITSA_IMAGES.forEach(function (src) {
    var img = new Image();
    img.src = src;
  });

  function startMartenitsa() {
    return createSpawner({
      name: "martenitsa",
      limitDesktop: 16,
      limitMobile: 8,
      initial: isMobile() ? 3 : 7,
      interval: isMobile() ? 1800 : 1100,
      create: function () {
        var wrap = document.createElement("div");
        wrap.className = "fx-particle fx-martenitsa";
        // по-тежки от лист – падат бавно и равномерно
        var fall = rnd(16, 28);
        wrap.style.left = rnd(-2, 94).toFixed(2) + "vw";
        wrap.style.width = rndInt(30, 58) + "px";
        wrap.style.opacity = rnd(0.9, 1).toFixed(2);
        wrap.style.setProperty("--fx-drift", rnd(-4, 4).toFixed(1) + "vw");
        // само вертикално движение на обвивката; люлеенето е в inner
        wrap.style.animationDuration = fall + "s, " + rnd(3.2, 5.4).toFixed(1) + "s";

        var inner = document.createElement("div");
        inner.className = "fx-martenitsa-inner";
        // бавно, махаловидно люлеене като на закачена мартеница
        inner.style.animationDuration = rnd(2.6, 4.6).toFixed(2) + "s";
        inner.style.animationDelay = "-" + rnd(0, 3).toFixed(2) + "s";

        var img = document.createElement("img");
        img.className = "fx-mt-img";
        img.src = pick(MARTENITSA_IMAGES);
        img.alt = "";
        img.decoding = "async";
        inner.appendChild(img);
        wrap.appendChild(inner);
        wrap.dataset.life = String(fall);
        return wrap;
      },
      life: function (el) {
        return Number(el.dataset.life);
      },
    });
  }


  /* ------------------------------- FIREWORKS ------------------------------- */
  function startFireworks() {
    var layer = makeLayer("fireworks");
    var canvas = document.createElement("canvas");
    canvas.className = "fx-fireworks-canvas";
    layer.appendChild(canvas);
    var ctx = canvas.getContext("2d");
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W = 0;
    var H = 0;

    function resize() {
      W = window.innerWidth;
      H = window.innerHeight;
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener("resize", resize);

    var rockets = [];
    var sparks = [];
    var MAX_SPARKS = isMobile() ? 420 : 1400;
    var COLORS = [
      [255, 86, 86],
      [255, 209, 102],
      [90, 210, 255],
      [179, 136, 255],
      [124, 242, 155],
      [255, 138, 216],
      [255, 247, 220],
    ];
    var raf = 0;
    var lastLaunch = 0;
    var lastTs = 0;
    var launchGap = isMobile() ? 1500 : 780;
    var GRAVITY = 0.028;

    function rgba(c, a) {
      return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + a.toFixed(3) + ")";
    }

    function launch() {
      var color = pick(COLORS);
      rockets.push({
        x: rnd(W * 0.1, W * 0.9),
        y: H + 6,
        vx: rnd(-0.5, 0.5),
        vy: -rnd(H * 0.0115, H * 0.0165),
        target: rnd(H * 0.08, H * 0.42),
        color: color,
        // тип на експлозията
        kind: Math.random() < 0.22 ? "ring" : Math.random() < 0.3 ? "double" : "burst",
        second: Math.random() < 0.45 ? pick(COLORS) : null,
      });
    }

    function addSpark(x, y, vx, vy, color, opts) {
      if (sparks.length > MAX_SPARKS) return;
      opts = opts || {};
      sparks.push({
        x: x,
        y: y,
        px: x,
        py: y,
        vx: vx,
        vy: vy,
        life: 1,
        decay: opts.decay || rnd(0.006, 0.014),
        color: color,
        size: opts.size || rnd(1, 2.2),
        twinkle: opts.twinkle !== undefined ? opts.twinkle : Math.random() < 0.35,
        drag: opts.drag || 0.978,
        glitter: !!opts.glitter,
      });
    }

    function explode(r) {
      var x = r.x;
      var y = r.y;
      var count = isMobile() ? 70 : 150;
      var i;
      var angle;
      var speed;

      if (r.kind === "ring") {
        // равномерен пръстен + вътрешно ядро
        for (i = 0; i < count; i++) {
          angle = (Math.PI * 2 * i) / count;
          speed = rnd(3.4, 4.2);
          addSpark(x, y, Math.cos(angle) * speed, Math.sin(angle) * speed, r.color, {
            decay: rnd(0.006, 0.011),
          });
        }
        for (i = 0; i < count / 3; i++) {
          angle = rnd(0, Math.PI * 2);
          speed = rnd(0.4, 1.8);
          addSpark(x, y, Math.cos(angle) * speed, Math.sin(angle) * speed,
            r.second || r.color, { decay: rnd(0.012, 0.024), size: rnd(0.8, 1.6) });
        }
      } else {
        for (i = 0; i < count; i++) {
          angle = rnd(0, Math.PI * 2);
          speed = Math.pow(Math.random(), 0.5) * rnd(1.4, 5.2);
          var col = r.second && Math.random() < 0.4 ? r.second : r.color;
          addSpark(x, y, Math.cos(angle) * speed, Math.sin(angle) * speed, col, {
            decay: rnd(0.006, 0.017),
            size: rnd(1, 2.4),
          });
        }
      }

      // бели искрящи прашинки (glitter)
      for (i = 0; i < (isMobile() ? 18 : 40); i++) {
        angle = rnd(0, Math.PI * 2);
        speed = rnd(0.6, 4.6);
        addSpark(x, y, Math.cos(angle) * speed, Math.sin(angle) * speed, [255, 255, 245], {
          decay: rnd(0.01, 0.03),
          size: rnd(0.6, 1.3),
          twinkle: true,
          glitter: true,
        });
      }

      // моментна светкавица
      var flash = ctx.createRadialGradient(x, y, 0, x, y, 90);
      flash.addColorStop(0, rgba(r.color, 0.55));
      flash.addColorStop(1, rgba(r.color, 0));
      ctx.fillStyle = flash;
      ctx.beginPath();
      ctx.arc(x, y, 90, 0, Math.PI * 2);
      ctx.fill();
    }

    function frame(ts) {
      raf = window.requestAnimationFrame(frame);
      if (document.hidden) return;
      var dt = lastTs ? Math.min((ts - lastTs) / 16.67, 2.5) : 1;
      lastTs = ts;

      // избледняване вместо изчистване -> следи от искри
      ctx.globalCompositeOperation = "destination-out";
      ctx.fillStyle = "rgba(0,0,0,0.22)";
      ctx.fillRect(0, 0, W, H);
      ctx.globalCompositeOperation = "lighter";

      if (ts - lastLaunch > launchGap && rockets.length < 5) {
        lastLaunch = ts;
        launch();
      }

      var i;
      for (i = rockets.length - 1; i >= 0; i--) {
        var r = rockets[i];
        r.x += r.vx * dt;
        r.y += r.vy * dt;
        r.vy += GRAVITY * 1.6 * dt;

        // огнена опашка
        addSpark(r.x + rnd(-1, 1), r.y + rnd(0, 3), rnd(-0.25, 0.25), rnd(0.2, 0.9),
          [255, rndInt(150, 210), 80], {
            decay: rnd(0.05, 0.1),
            size: rnd(0.8, 1.7),
            drag: 0.94,
            twinkle: false,
          });

        var g = ctx.createRadialGradient(r.x, r.y, 0, r.x, r.y, 9);
        g.addColorStop(0, rgba(r.color, 0.95));
        g.addColorStop(1, rgba(r.color, 0));
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(r.x, r.y, 9, 0, Math.PI * 2);
        ctx.fill();

        if (r.y <= r.target || r.vy >= 0) {
          explode(r);
          rockets.splice(i, 1);
        }
      }

      ctx.lineCap = "round";
      for (var j = sparks.length - 1; j >= 0; j--) {
        var s = sparks[j];
        s.px = s.x;
        s.py = s.y;
        s.x += s.vx * dt;
        s.y += s.vy * dt;
        s.vx *= Math.pow(s.drag, dt);
        s.vy = s.vy * Math.pow(s.drag, dt) + GRAVITY * dt;
        s.life -= s.decay * dt;
        if (s.life <= 0 || s.y > H + 40) {
          sparks.splice(j, 1);
          continue;
        }
        var alpha = Math.max(s.life, 0);
        if (s.twinkle) alpha *= 0.35 + 0.65 * Math.abs(Math.sin(ts * 0.03 + s.x));
        ctx.strokeStyle = rgba(s.color, alpha);
        ctx.lineWidth = s.size * (s.glitter ? 0.8 : 1);
        ctx.beginPath();
        ctx.moveTo(s.px, s.py);
        ctx.lineTo(s.x, s.y);
        ctx.stroke();
      }
      ctx.globalCompositeOperation = "source-over";
      ctx.globalAlpha = 1;
    }
    raf = window.requestAnimationFrame(frame);

    return {
      stop: function () {
        window.cancelAnimationFrame(raf);
        window.removeEventListener("resize", resize);
        rockets = [];
        sparks = [];
        if (layer.parentNode) layer.parentNode.removeChild(layer);
      },
    };
  }

  /* ------------------------------- DISPATCHER ------------------------------- */
  var running = {}; // name -> handle

  function startEffect(name) {
    switch (name) {
      case "snow":
        return startSnow();
      case "leaves":
        return startLeaves();
      case "fireworks":
        return startFireworks();
      case "letters":
        return startLetters();
      case "spring_butterflies":
      case "butterflies":
        return startButterflies();
      case "bubbles":
        return startBubbles();
      case "martenitsa":
        return startMartenitsa();
      default:
        console.error("[effects] Непознат ефект: " + name);
        return null;
    }
  }

  function applyEffects(rows) {
    if (!rows) return;
    var today = todayInBulgaria();
    var wanted = {};

    rows.forEach(function (row) {
      var name = normalizeEffectName(row.effect);
      if (!name) return;
      if (!pageMatches(row.page)) return;
      if (!isEffectActive(row, today)) return;
      wanted[name] = true;
    });

    if (reducedMotion()) wanted = {};

    // спиране на вече неактивните
    Object.keys(running).forEach(function (name) {
      if (!wanted[name]) {
        try {
          running[name].stop();
        } catch (e) {
          console.error("[effects] Грешка при спиране на " + name, e);
        }
        delete running[name];
      }
    });

    // стартиране на новите активни
    Object.keys(wanted).forEach(function (name) {
      if (running[name]) return;
      var handle = startEffect(name);
      if (handle) running[name] = handle;
    });
  }

  var lastRows = null;
  function refresh() {
    return fetchSettings().then(function (rows) {
      if (!rows) return;
      var signature = JSON.stringify(rows);
      if (signature === lastRows && Object.keys(running).length) return;
      lastRows = signature;
      applyEffects(rows);
    });
  }

  function init() {
    ensureContainer();
    refresh();
    window.setInterval(refresh, CONFIG.REFRESH_TIME);
    // при навигация в SPA контейнерът може да бъде премахнат – възстановяваме го
    window.addEventListener("popstate", function () {
      ensureContainer();
      if (lastRows) applyEffects(JSON.parse(lastRows));
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // Публично API (за ръчно тестване от конзолата)
  window.SiteEffects = {
    config: CONFIG,
    refresh: refresh,
    start: function (name) {
      name = normalizeEffectName(name);
      if (running[name]) return;
      var h = startEffect(name);
      if (h) running[name] = h;
    },
    stop: function (name) {
      name = normalizeEffectName(name);
      if (running[name]) {
        running[name].stop();
        delete running[name];
      }
    },
    running: function () {
      return Object.keys(running);
    },
  };
})();

/* =========================================================================
   Автоматични scroll-efекти (fade-up) за страници без собствена Reveal
   анимация. Ако страницата вече използва Reveal (duration-[1200ms]),
   модулът не прави нищо, за да не дублира ефекти.
   ========================================================================= */
(function () {
  "use strict";

  function init() {
    try {
      if (
        window.matchMedia &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches
      ) {
        return;
      }
      /* Страницата вече има собствени scroll анимации -> не се намесваме. */
      if (document.querySelector('[class*="duration-[1200ms]"]')) return;

      var main = document.querySelector("main") || document.body;
      var targets = main.querySelectorAll(
        "section, article, h1, h2, h3, .fx-auto"
      );
      if (!targets.length) return;

      var io = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add("fx-reveal-in");
              io.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.08, rootMargin: "0px 0px -30px 0px" }
      );

      var i = 0;
      targets.forEach(function (el) {
        /* Пропускаме fixed/overlay елементи и вече анимирани. */
        var pos = window.getComputedStyle(el).position;
        if (pos === "fixed" || pos === "sticky") return;
        el.classList.add("fx-reveal");
        /* Леко стъпаловидно закъснение за съседни елементи. */
        el.style.transitionDelay = Math.min((i++ % 6) * 70, 350) + "ms";
        io.observe(el);
      });
    } catch (e) {
      /* Тишко – ефектът е декоративен и не трябва да чупи страницата. */
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      window.setTimeout(init, 400);
    });
  } else {
    window.setTimeout(init, 400);
  }
})();
