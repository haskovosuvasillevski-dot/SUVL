/**
 * Google Apps Script – публично JSON API за визуалните ефекти.
 *
 * КАК ДА ГО ПУБЛИКУВАТЕ:
 * 1. Отворете Google Sheets с таблицата на ефектите.
 * 2. Extensions → Apps Script и поставете този код.
 * 3. Deploy → New deployment → Type: Web app.
 *      Execute as: Me
 *      Who has access: Anyone
 * 4. Копирайте URL адреса (…/exec) и го поставете в /js/effects.js:
 *      const CONFIG = { API_URL: "ТУК", ... }
 *
 * API-то е само за четене – сайтът няма права да променя таблицата.
 */

var SPREADSHEET_ID = '1I2ZFKwxPrcnXZYpULem5AJoiawPITEInBmIp7tPHqtk';
var SHEET_NAME = ''; // празно = първият лист

function doGet() {
  try {
    var ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    var sheet = SHEET_NAME ? ss.getSheetByName(SHEET_NAME) : ss.getSheets()[0];
    var values = sheet.getDataRange().getValues();

    var header = values[0].map(function (h) {
      return String(h).trim().toLowerCase();
    });
    var col = function (name) {
      return header.indexOf(name);
    };

    var effects = [];
    for (var i = 1; i < values.length; i++) {
      var row = values[i];
      var name = String(row[col('effect')] || '').trim();
      if (!name) continue;
      effects.push({
        id: Number(row[col('id')]) || i,
        effect: name,
        page: String(row[col('page')] || 'all').trim() || 'all',
        enabled: isTruthy(row[col('enabled')]),
        start_date: formatDate(row[col('start_date')]),
        end_date: formatDate(row[col('end_date')])
      });
    }

    return json({
      success: true,
      updated: new Date().toISOString(),
      effects: effects
    });
  } catch (err) {
    return json({ success: false, error: String(err), effects: [] });
  }
}

function isTruthy(value) {
  var s = String(value === null || value === undefined ? '' : value).trim().toLowerCase();
  return s === '1' || s === 'true' || s === 'yes' || s === 'да';
}

/** Връща YYYY-MM-DD по българско време (или '' ако е празно). */
function formatDate(value) {
  if (value === null || value === undefined || value === '') return '';
  if (Object.prototype.toString.call(value) === '[object Date]') {
    return Utilities.formatDate(value, 'Europe/Sofia', 'yyyy-MM-dd');
  }
  var s = String(value).trim();
  var iso = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (iso) {
    return iso[1] + '-' + pad(iso[2]) + '-' + pad(iso[3]);
  }
  var eu = s.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
  if (eu) {
    return eu[3] + '-' + pad(eu[2]) + '-' + pad(eu[1]);
  }
  return '';
}

function pad(n) {
  n = String(n);
  return n.length < 2 ? '0' + n : n;
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON
  );
}
